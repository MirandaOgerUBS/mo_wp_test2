<?php
/**
 * Page de réglages administration
 */

if (!defined('ABSPATH')) {
    exit;
}

class ACC_Admin_Settings {
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('wp_ajax_acc_toggle_module', [$this, 'ajax_toggle_module']);
    }
    
    /**
     * Ajoute le menu admin
     */
    public function add_admin_menu() {
        add_options_page(
            'Accessibilité Modulaire',
            'Accessibilité',
            'manage_options',
            'accessibility-modular',
            [$this, 'render_settings_page']
        );
    }
    
    /**
     * Enregistre les paramètres
     */
    public function register_settings() {
        register_setting('acc_settings_group', 'acc_api_key', [
            'sanitize_callback' => 'sanitize_text_field'
        ]);
        
        register_setting('acc_settings_group', 'acc_active_modules', [
            'sanitize_callback' => [$this, 'sanitize_modules']
        ]);
    }
    
    /**
     * Sanitize les modules
     */
    public function sanitize_modules($input) {
        if (!is_array($input)) {
            return [];
        }
        
        return array_map('sanitize_text_field', $input);
    }
    
    /**
     * Affiche la page de réglages
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Sauvegarde des réglages
        if (isset($_POST['acc_save_settings'])) {
            check_admin_referer('acc_settings_nonce');
            
            // Clé API (si nécessaire)
            if (isset($_POST['acc_api_key'])) {
                update_option('acc_api_key', sanitize_text_field($_POST['acc_api_key']));
            }
            
            // Modules actifs
            $selected_modules = isset($_POST['acc_modules']) ? $_POST['acc_modules'] : [];
            update_option('acc_active_modules', $this->sanitize_modules($selected_modules));
            
            echo '<div class="notice notice-success is-dismissible"><p>Réglages sauvegardés avec succès.</p></div>';
        }
        
        $api_key = get_option('acc_api_key', '');
        $active_modules = get_option('acc_active_modules', []);
        $module_registry = ACC_Module_Registry::get_instance();
        $all_modules = $module_registry->get_all_modules();
        
        ?>
        <div class="wrap">
            <h1>
                <span class="dashicons dashicons-universal-access"></span>
                Accessibilité Modulaire
            </h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('acc_settings_nonce'); ?>
                
                <!-- Section Clé API (optionnelle - commentée par défaut) -->
                <!--
                <div class="acc-admin-section">
                    <h2>Configuration de la clé API</h2>
                    <p class="description">
                        Une clé API valide est requise pour activer certaines fonctionnalités avancées.
                        <br>Vous pouvez utiliser une clé Google Translate API ou toute autre clé compatible.
                    </p>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="acc_api_key">Clé API</label>
                            </th>
                            <td>
                                <input 
                                    type="text" 
                                    id="acc_api_key" 
                                    name="acc_api_key" 
                                    value="<?php echo esc_attr($api_key); ?>"
                                    class="regular-text"
                                    placeholder="Entrez votre clé API"
                                />
                                <?php if (empty($api_key)): ?>
                                    <p class="description" style="color: #d63638;">
                                        ⚠️ Certaines fonctionnalités nécessitent une clé API.
                                    </p>
                                <?php else: ?>
                                    <p class="description" style="color: #00a32a;">
                                        ✓ Clé API configurée
                                    </p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>
                -->
                
                <div class="acc-admin-section">
                    <h2>Modules disponibles</h2>
                    <p class="description">
                        Sélectionnez les fonctionnalités d'accessibilité à activer sur votre site.
                        <br>Par défaut, tous les modules sont activés.
                    </p>
                    
                    <?php if (empty($all_modules)): ?>
                        <div class="notice notice-warning">
                            <p>
                                <strong>Aucun module trouvé.</strong><br>
                                Assurez-vous que les modules sont correctement installés dans le dossier <code>modules/</code> 
                                avec les fichiers requis : <code>module.php</code>, <code>config.json</code>, et <code>README.md</code>.
                            </p>
                        </div>
                    <?php else: ?>
                        <div class="acc-modules-grid">
                            <?php
                            // Grouper les modules par catégorie
                            $categories = [];
                            foreach ($all_modules as $module_name => $module_data) {
                                $module_info = $module_registry->get_module_info($module_name);
                                if ($module_info) {
                                    $category = $module_info['category'];
                                    
                                    if (!isset($categories[$category])) {
                                        $categories[$category] = [];
                                    }
                                    $categories[$category][] = $module_info;
                                }
                            }
                            
                            // Labels de catégories
                            $category_labels = [
                                'vision' => 'Vision',
                                'audition' => 'Audition',
                                'mobilite' => 'Mobilité',
                                'cognition' => 'Cognition',
                                'lecture' => 'Lecture',
                                'general' => 'Général'
                            ];
                            
                            // Afficher par catégorie
                            foreach ($categories as $category => $modules):
                            ?>
                                <div class="acc-category-section">
                                    <h3>
                                        <?php echo esc_html($category_labels[$category] ?? ucfirst($category)); ?>
                                        <span class="acc-category-count">(<?php echo count($modules); ?>)</span>
                                    </h3>
                                    <div class="acc-modules-row">
                                        <?php foreach ($modules as $module): 
                                            $is_active = in_array($module['name'], $active_modules);
                                        ?>
                                            <div class="acc-module-card">
                                                <label>
                                                    <input 
                                                        type="checkbox" 
                                                        name="acc_modules[]" 
                                                        value="<?php echo esc_attr($module['name']); ?>"
                                                        <?php checked($is_active); ?>
                                                    />
                                                    <div class="acc-module-content">
                                                        <?php if (!empty($module['icon'])): ?>
                                                            <span class="acc-module-icon">
                                                                <?php echo $module['icon']; ?>
                                                            </span>
                                                        <?php endif; ?>
                                                        <strong><?php echo esc_html($module['title']); ?></strong>
                                                        <p><?php echo esc_html($module['description']); ?></p>
                                                        <span class="acc-module-version">
                                                            v<?php echo esc_html($module['version']); ?>
                                                        </span>
                                                    </div>
                                                </label>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <p class="submit">
                    <button type="submit" name="acc_save_settings" class="button button-primary">
                        <span class="dashicons dashicons-saved" style="margin-top: 3px;"></span>
                        Sauvegarder les réglages
                    </button>
                </p>
            </form>
            
            <div class="acc-admin-section">
                <h2>📚 Documentation</h2>
                
                <h3>Ajouter un nouveau module</h3>
                <ol>
                    <li>Créez un nouveau dossier dans <code>wp-content/plugins/accessibility-modular/modules/votre-module/</code></li>
                    <li>Ajoutez les fichiers requis :
                        <ul style="margin-left: 20px; list-style: disc;">
                            <li><code>module.php</code> - Fichier principal du module</li>
                            <li><code>config.json</code> - Configuration (titre, description, icône, etc.)</li>
                            <li><code>template.php</code> - Interface utilisateur</li>
                            <li><code>README.md</code> - Documentation (avec marqueurs de protection)</li>
                            <li><code>assets/script.js</code> - JavaScript du module</li>
                        </ul>
                    </li>
                    <li>Le module apparaîtra automatiquement dans cette interface</li>
                </ol>
                
                <h3>Structure d'un module</h3>
                <pre style="background: #f6f7f7; padding: 15px; border-radius: 4px; overflow-x: auto;">
modules/votre-module/
├── module.php          # Classe PHP du module
├── config.json         # Configuration JSON
├── template.php        # Interface utilisateur
├── README.md           # Documentation
└── assets/
    └── script.js       # JavaScript</pre>
                
                <h3>Normes RGAA</h3>
                <p>
                    Ce plugin respecte les critères d'accessibilité <strong>RGAA 4.1</strong> et <strong>WCAG 2.1</strong>.
                    <br>Tous les modules doivent être conformes à ces normes pour être acceptés.
                </p>
                
                <h3>Support</h3>
                <p>
                    Pour toute question ou assistance, consultez la documentation complète dans le fichier 
                    <code>README.md</code> du plugin ou contactez le support.
                </p>
            </div>
        </div>
        <?php
    }
    
    /**
     * AJAX pour toggle un module
     */
    public function ajax_toggle_module() {
        check_ajax_referer('acc_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permissions insuffisantes');
        }
        
        $module_name = sanitize_text_field($_POST['module']);
        $action = sanitize_text_field($_POST['action_type']);
        
        $active_modules = get_option('acc_active_modules', []);
        
        if ($action === 'activate') {
            if (!in_array($module_name, $active_modules)) {
                $active_modules[] = $module_name;
            }
        } else {
            $key = array_search($module_name, $active_modules);
            if ($key !== false) {
                unset($active_modules[$key]);
            }
        }
        
        $result = update_option('acc_active_modules', array_values($active_modules));
        
        if ($result) {
            wp_send_json_success([
                'message' => 'Module ' . ($action === 'activate' ? 'activé' : 'désactivé'),
                'active_modules' => $active_modules
            ]);
        } else {
            wp_send_json_error('Erreur lors de la modification du module');
        }
    }
}

// Initialiser
new ACC_Admin_Settings();