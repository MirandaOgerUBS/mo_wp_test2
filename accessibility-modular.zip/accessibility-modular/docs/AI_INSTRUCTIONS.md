# Instructions pour l'IA - Accessibilité Modulaire

**⚠️ LECTURE OBLIGATOIRE POUR TOUTE IA TRAVAILLANT SUR CE PROJET**

Ce document contient des instructions critiques pour garantir la stabilité et la pérennité du plugin. **Vous devez suivre ces règles strictement.**

---

## 🚨 RÈGLES ABSOLUES - NON NÉGOCIABLES

### ❌ INTERDICTIONS STRICTES

1. **NE JAMAIS modifier les modules existants**
   - Les dossiers `modules/text/`, `modules/brightness/`, `modules/button-size/` sont **VERROUILLÉS**
   - Tout fichier contenant les marqueurs `<!-- MODULE_PROTECTION: DO_NOT_MODIFY -->` est **INTOUCHABLE**
   - Les fichiers README.md dans les modules contiennent des checksums - ne les modifiez jamais

2. **NE JAMAIS utiliser localStorage ou sessionStorage**
   - Utilisez **UNIQUEMENT** les cookies via `document.cookie`
   - Les fonctions `window.accWidget.savePreference()` et `getPreference()` gèrent déjà les cookies
   - Raison : localStorage n'est pas compatible avec l'environnement de ce plugin

3. **NE JAMAIS dépasser 3 éléments par ligne**
   - Maximum 3 colonnes dans les grilles CSS
   - Respectez `grid-template-columns: repeat(3, 1fr)` ou moins
   - Plus de 3 éléments = surcharge visuelle (critère RGAA)

4. **NE JAMAIS modifier les fichiers principaux du plugin**
   - `accessibility-modular.php`
   - `class-module-registry.php`
   - `class-api-handler.php`
   - `class-admin-settings.php`
   - Exception : corrections de bugs critiques uniquement

5. **NE JAMAIS ignorer les normes RGAA 4.1**
   - Tous les nouveaux modules doivent être conformes
   - Testez avec des lecteurs d'écran
   - Validez la navigation au clavier

---

## ✅ RÈGLES À SUIVRE ABSOLUMENT

### 1. Création de nouveaux modules

**Structure obligatoire :**

```
modules/nouveau-module/
├── README.md           ← OBLIGATOIRE avec marqueurs de protection
├── config.json         ← OBLIGATOIRE
├── module.php          ← OPTIONNEL (logique PHP)
├── template.php        ← OBLIGATOIRE (interface)
└── assets/
    ├── script.js       ← OPTIONNEL
    └── style.css       ← OPTIONNEL
```

**Marqueurs README.md obligatoires :**

```markdown
<!-- MODULE_PROTECTION: DO_NOT_MODIFY -->
<!-- MODULE_VERSION: 1.0.0 -->
<!-- MODULE_CHECKSUM: [générez un hash unique] -->
<!-- MODULE_CREATED: [date] -->
<!-- MODULE_AUTHOR: [votre nom] -->
```

### 2. Gestion des données utilisateur

**Utilisez UNIQUEMENT les cookies :**

```javascript
// ✅ CORRECT
window.accWidget.savePreference('mon_module_setting', value);
const value = window.accWidget.getPreference('mon_module_setting', defaultValue);

// ❌ INTERDIT
localStorage.setItem('acc_setting', value);
sessionStorage.setItem('acc_setting', value);
```

**Convention de nommage des cookies :**
- Préfixe : `acc_[nom_module]_[parametre]`
- Exemple : `acc_text_font`, `acc_brightness_mode`

### 3. Structure CSS et interface

**Grilles - Maximum 3 colonnes :**

```css
/* ✅ CORRECT */
.acc-modules-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
}

/* ✅ CORRECT - Responsive */
@media (max-width: 768px) {
    .acc-modules-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

/* ❌ INTERDIT */
.acc-modules-grid {
    grid-template-columns: repeat(4, 1fr); /* Plus de 3 ! */
}
```

**Classes CSS réutilisables :**

Utilisez les classes existantes définies dans `frontend.css` :
- `.acc-module` : Conteneur de module
- `.acc-button` : Boutons standards
- `.acc-slider` : Sliders de réglage
- `.acc-control-group` : Groupe de contrôles

### 4. Accessibilité RGAA

**Checklist obligatoire pour chaque nouveau module :**

- [ ] Navigation complète au clavier (Tab, Shift+Tab, flèches)
- [ ] Attributs ARIA appropriés (`aria-label`, `aria-labelledby`, `aria-describedby`)
- [ ] Focus visible sur tous les éléments interactifs
- [ ] Annonces pour les lecteurs d'écran
- [ ] Contrastes suffisants (AA minimum, AAA recommandé)
- [ ] Pas de piège à focus
- [ ] Textes alternatifs pour les images/icônes

**Exemple d'implémentation correcte :**

```html
<button 
    type="button"
    class="acc-button"
    aria-label="Activer le mode nuit"
    aria-pressed="false"
>
    Mode nuit
</button>
```

```javascript
// Annonce pour les lecteurs d'écran
window.accWidget.announce('Mode nuit activé');
```

### 5. Configuration du module (config.json)

**Structure obligatoire :**

```json
{
  "name": "nom-du-module",
  "title": "Titre affiché",
  "description": "Description courte",
  "version": "1.0.0",
  "author": "Votre nom",
  "category": "vision|audition|mobilite|cognition|lecture",
  "icon": "🔷",
  "enabled": true,
  "priority": 10,
  "rgaa_criteria": ["3.2", "10.4"],
  "conformity_level": "AA",
  "cookies": [
    "acc_module_param1",
    "acc_module_param2"
  ],
  "dependencies": []
}
```

**Catégories valides uniquement :**
- `vision` : Pour les modules liés à la vue
- `audition` : Pour les modules audio
- `mobilite` : Pour les troubles moteurs
- `cognition` : Pour les troubles cognitifs
- `lecture` : Pour la dyslexie, etc.

### 6. Code JavaScript

**Pattern obligatoire pour les modules :**

```javascript
(function($) {
    'use strict';

    class MonModule {
        constructor() {
            this.module = $('#acc-module-mon-module');
            this.toggle = $('#acc-mon-module-toggle');
            this.isActive = false;
            this.init();
        }

        init() {
            this.loadSettings();
            this.bindEvents();
            if (this.isActive) {
                this.applySettings();
            }
        }

        loadSettings() {
            this.isActive = window.accWidget.getPreference('mon_module_active', false);
        }

        savePreference(key, value) {
            window.accWidget.savePreference(`mon_module_${key}`, value);
        }

        announce(message) {
            if (window.accWidget) {
                window.accWidget.announce(message);
            }
        }
    }

    $(document).ready(function() {
        if ($('#acc-module-mon-module').length) {
            window.accMonModule = new MonModule();
        }
    });

})(jQuery);
```

---

## 🎨 Standards de code

### Nommage

**Variables et fonctions :**
```javascript
// ✅ CORRECT - camelCase
const myVariable = 'value';
function handleClick() {}

// ❌ INTERDIT
const my_variable = 'value'; // snake_case
```

**Classes CSS :**
```css
/* ✅ CORRECT - kebab-case avec préfixe */
.acc-my-class {}
.acc-module-header {}

/* ❌ INTERDIT */
.myClass {} /* Pas de préfixe */
.my_class {} /* snake_case */
```

**IDs HTML :**
```html
<!-- ✅ CORRECT -->
<div id="acc-module-text"></div>

<!-- ❌ INTERDIT -->
<div id="moduleText"></div>
<div id="module_text"></div>
```

### Commentaires

**Obligatoires pour :**
- Fonctions complexes
- Algorithmes non évidents
- Workarounds pour bugs
- Compatibilité navigateurs

```javascript
/**
 * Calcule le ratio de contraste WCAG
 * 
 * @param {string} color1 - Couleur hex (#RRGGBB)
 * @param {string} color2 - Couleur hex (#RRGGBB)
 * @return {number} Ratio entre 1 et 21
 */
function calculateContrastRatio(color1, color2) {
    // Implémentation...
}
```

---

## 🧪 Tests obligatoires

Avant de soumettre un nouveau module, testez :

### 1. Navigation au clavier

- [ ] Tab parcourt tous les éléments interactifs
- [ ] Shift+Tab fonctionne en sens inverse
- [ ] Enter/Space active les boutons
- [ ] Flèches fonctionnent dans les groupes radio
- [ ] Esc ferme les modales/panneaux
- [ ] Pas de piège à focus

### 2. Lecteurs d'écran

Testez avec au moins un lecteur d'écran :
- **Windows** : NVDA (gratuit)
- **macOS** : VoiceOver (intégré)
- **Linux** : Orca

Vérifiez :
- [ ] Tous les boutons sont annoncés
- [ ] Les changements d'état sont annoncés
- [ ] Les landmarks sont corrects
- [ ] Les formulaires sont compréhensibles

### 3. Navigateurs

Testez dans :
- [ ] Chrome/Edge (Chromium)
- [ ] Firefox
- [ ] Safari
- [ ] Au moins un mobile (iOS ou Android)

### 4. Compatibilité thèmes

Testez avec :
- [ ] Twenty Twenty-Three (thème par défaut)
- [ ] Un thème populaire (Astra, GeneratePress, etc.)
- [ ] Votre thème de production

### 5. Performances

Vérifiez :
- [ ] Temps de chargement < 100ms
- [ ] Pas de reflows excessifs
- [ ] Pas de memory leaks
- [ ] Fonctionne avec 50+ modules actifs

---

## 🔄 Workflow de développement

### Ajout d'un nouveau module

1. **Créez le dossier**
   ```bash
   mkdir -p modules/mon-module/assets
   ```

2. **Créez les fichiers obligatoires**
   - `README.md` avec marqueurs de protection
   - `config.json` avec la configuration
   - `template.php` avec l'interface

3. **Développez le module**
   - Respectez toutes les règles ci-dessus
   - Utilisez les classes CSS existantes
   - Implémentez l'accessibilité complète

4. **Testez exhaustivement**
   - Suivez la checklist de tests

5. **Documentez**
   - README.md complet
   - Commentaires dans le code
   - Exemples d'utilisation

### Correction de bugs dans modules existants

**SI le bug est dans un module protégé :**
1. NE modifiez PAS le module directement
2. Créez un module "patch" séparé
3. Ou proposez la correction pour validation

**SI le bug est dans un fichier principal :**
1. Vérifiez que c'est vraiment un bug
2. Créez une branche git
3. Corrigez le bug
4. Testez exhaustivement
5. Documentez la correction

---

## 📝 Checklist finale avant commit

- [ ] Aucun module existant n'a été modifié
- [ ] Pas de localStorage/sessionStorage utilisé
- [ ] Maximum 3 colonnes partout
- [ ] Tous les critères RGAA sont respectés
- [ ] Les cookies sont préfixés `acc_`
- [ ] Navigation clavier complète
- [ ] Lecteurs d'écran testés
- [ ] README.md créé avec marqueurs
- [ ] config.json valide et complet
- [ ] Code commenté et propre
- [ ] Tests passés dans 3+ navigateurs
- [ ] Aucune erreur console
- [ ] Performances optimales

---

## 🆘 En cas de doute

### Questions à se poser

1. **"Puis-je modifier ce fichier ?"**
   - S'il contient `MODULE_PROTECTION: DO_NOT_MODIFY` → **NON**
   - Sinon → Probablement oui, mais vérifiez deux fois

2. **"Puis-je utiliser localStorage ?"**
   - **NON, JAMAIS**. Utilisez les cookies via `window.accWidget`

3. **"Combien de colonnes maximum ?"**
   - **3 maximum**. C'est une règle d'accessibilité stricte

4. **"Ce module doit-il être accessible ?"**
   - **OUI, TOUJOURS**. Aucune exception

### Ressources

- **RGAA 4.1** : https://www.numerique.gouv.fr/publications/rgaa-accessibilite/
- **WCAG 2.1** : https://www.w3.org/WAI/WCAG21/quickref/
- **MDN Accessibility** : https://developer.mozilla.org/en-US/docs/Web/Accessibility

---

## ⚖️ Principe général

> **"Si vous devez vous demander si vous pouvez faire quelque chose, la réponse est probablement non. Créez plutôt un nouveau module."**

L'architecture de ce plugin est conçue pour l'extensibilité sans modification. Travaillez AVEC le système, pas CONTRE lui.

---

## 📞 Support

Si vous ne comprenez pas une règle ou avez besoin de clarifications :

1. Relisez ce document attentivement
2. Consultez les exemples dans les modules existants
3. Demandez sur le forum/chat de l'équipe

**Ne devinez jamais. Demandez.**

---

**Dernière mise à jour** : 15 janvier 2025  
**Version des instructions** : 1.0.0

**Merci de respecter ces règles pour maintenir la qualité et l'accessibilité du plugin ! ♿**