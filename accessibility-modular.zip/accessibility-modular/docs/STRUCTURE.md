# Architecture du Plugin - Accessibilité Modulaire

Documentation complète de l'architecture et de la structure du plugin WordPress Accessibilité Modulaire.

---

## 📁 Structure des fichiers

```
accessibility-modular/
│
├── 📄 accessibility-modular.php        # Fichier principal du plugin
├── 📄 README.md                        # Documentation principale
├── 📄 INSTALLATION.md                  # Guide d'installation
├── 📄 AI_INSTRUCTIONS.md               # Instructions pour l'IA
├── 📄 STRUCTURE.md                     # Ce fichier
│
├── 📁 includes/                        # Classes PHP principales
│   ├── 📄 class-module-registry.php   # Gestionnaire de modules
│   └── 📄 class-api-handler.php       # Gestionnaire d'API
│
├── 📁 admin/                           # Interface d'administration
│   └── 📄 class-admin-settings.php    # Page de réglages
│
├── 📁 templates/                       # Templates PHP
│   └── 📄 widget.php                  # Template du widget frontend
│
├── 📁 assets/                          # Ressources statiques
│   ├── 📁 css/
│   │   ├── 📄 frontend.css            # Styles frontend
│   │   └── 📄 admin.css               # Styles admin
│   └── 📁 js/
│       ├── 📄 frontend.js             # JavaScript frontend
│       └── 📄 admin.js                # JavaScript admin
│
├── 📁 modules/                         # Modules d'accessibilité
│   ├── 📁 text/                       # Module Texte
│   │   ├── 📄 README.md              # Documentation + protection
│   │   ├── 📄 config.json            # Configuration
│   │   ├── 📄 module.php             # Logique PHP
│   │   ├── 📄 template.php           # Interface
│   │   └── 📁 assets/
│   │       └── 📄 script.js          # JavaScript
│   │
│   ├── 📁 brightness/                 # Module Luminosité
│   │   ├── 📄 README.md
│   │   ├── 📄 config.json
│   │   ├── 📄 module.php
│   │   ├── 📄 template.php
│   │   └── 📁 assets/
│   │       ├── 📄 script.js
│   │       └── 📄 style.css
│   │
│   └── 📁 button-size/                # Module Taille boutons
│       ├── 📄 README.md
│       ├── 📄 config.json
│       ├── 📄 template.php
│       └── 📁 assets/
│           └── 📄 script.js
│
└── 📁 languages/                       # Fichiers de traduction
    └── 📄 accessibility-modular.pot
```

---

## 🏗️ Architecture globale

### Principe MVC adapté

Le plugin utilise une architecture inspirée du pattern MVC :

```
┌─────────────────────────────────────────────┐
│           UTILISATEUR FRONTEND               │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │   Widget Frontend    │ (templates/widget.php)
        │  (Vue utilisateur)   │
        └──────────┬───────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │  JavaScript Modules  │ (assets/js/ + modules/*/assets/)
        │   (Contrôleurs)      │
        └──────────┬───────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │   Module Registry    │ (includes/class-module-registry.php)
        │     (Modèle)         │
        └──────────┬───────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │    Cookies / Data    │
        │  (Persistance)       │
        └──────────────────────┘
```

### Flux d'exécution

#### 1. Initialisation WordPress

```
WordPress charge le plugin
    ↓
accessibility-modular.php
    ↓
Accessibility_Modular_Plugin::get_instance()
    ↓
load_dependencies() + init_hooks() + load_modules()
```

#### 2. Chargement des modules

```
load_modules()
    ↓
Scan du dossier modules/
    ↓
Pour chaque module:
    - Vérifier README.md (protection)
    - Charger config.json
    - Enregistrer dans Module_Registry
    - Inclure module.php
```

#### 3. Affichage frontend

```
Action: wp_footer
    ↓
render_accessibility_widget()
    ↓
Inclure templates/widget.php
    ↓
Pour chaque module actif:
    - Afficher template.php
    - Enqueue script.js + style.css
```

#### 4. Interaction utilisateur

```
Clic sur bouton widget
    ↓
JavaScript: AccessibilityWidget.openWidget()
    ↓
Affichage des catégories
    ↓
Clic sur catégorie
    ↓
Affichage des modules de la catégorie
    ↓
Modification paramètre
    ↓
Module JavaScript applique les changements
    ↓
Sauvegarde dans cookie via window.accWidget.savePreference()
```

---

## 🔧 Composants principaux

### 1. Classe principale (accessibility-modular.php)

**Rôle** : Point d'entrée et orchestrateur principal

**Responsabilités :**
- Initialisation du plugin
- Chargement des dépendances
- Enregistrement des hooks WordPress
- Gestion de l'activation/désactivation

**Pattern** : Singleton

```php
class Accessibility_Modular_Plugin {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
}
```

### 2. Module Registry (class-module-registry.php)

**Rôle** : Registre centralisé de tous les modules

**Responsabilités :**
- Enregistrer les modules
- Valider l'intégrité (via README checksums)
- Gérer l'activation/désactivation
- Fournir les métadonnées des modules

**Pattern** : Registry + Singleton

```php
class ACC_Module_Registry {
    private $registered_modules = [];
    
    public function register_module($name, $path) {
        // Validation + Enregistrement
    }
    
    public function get_active_modules() {
        // Retourne les modules actifs
    }
}
```

### 3. API Handler (class-api-handler.php)

**Rôle** : Gestion de la clé API et des appels externes

**Responsabilités :**
- Valider la clé API
- Effectuer les appels API (Google Translate, etc.)
- Cacher les validations
- Gérer les erreurs

**Pattern** : Singleton + Façade

```php
class ACC_API_Handler {
    public function validate_api_key($api_key) {
        // Validation
    }
    
    public function translate_text($text, $target_lang) {
        // Appel API
    }
}
```

### 4. Admin Settings (class-admin-settings.php)

**Rôle** : Interface d'administration WordPress

**Responsabilités :**
- Page de réglages dans le menu WordPress
- Sauvegarde de la configuration
- Activation/désactivation des modules
- Interface de gestion

**Pattern** : Controller

```php
class ACC_Admin_Settings {
    public function render_settings_page() {
        // Affichage de la page admin
    }
    
    public function register_settings() {
        // Enregistrement des options WP
    }
}
```

---

## 📦 Système de modules

### Structure d'un module

Chaque module est autonome et suit cette structure :

```
modules/nom-du-module/
├── README.md          # Documentation + Marqueurs de protection
├── config.json        # Métadonnées et configuration
├── module.php         # Logique PHP (optionnel)
├── template.php       # Interface utilisateur (requis)
└── assets/
    ├── script.js      # JavaScript (optionnel)
    └── style.css      # CSS (optionnel)
```

### Cycle de vie d'un module

#### Enregistrement

```
1. Plugin scanne modules/
2. Trouve un dossier avec README.md
3. Valide les marqueurs de protection
4. Lit config.json
5. Enregistre dans Module_Registry
6. Include module.php si présent
```

#### Activation

```
1. Admin coche le module
2. Option WordPress mise à jour
3. Module ajouté à acc_active_modules
4. Rechargement de la page
5. Module disponible dans le widget
```

#### Exécution

```
1. Widget s'affiche (wp_footer)
2. Pour chaque module actif:
   - Inclure template.php
   - Enqueue assets si présents
3. JavaScript initialise le module
4. Module charge ses préférences (cookies)
5. Module applique les paramètres sauvegardés
```

### Communication entre modules

Les modules communiquent via des événements jQuery :

```javascript
// Émettre un événement
$(document).trigger('acc:module:changed', {
    module: 'text',
    setting: 'font',
    value: 'Arial'
});

// Écouter un événement
$(document).on('acc:module:changed', function(e, data) {
    console.log('Module changed:', data);
});
```

---

## 💾 Gestion des données

### Options WordPress

Stockées dans `wp_options` :

| Option | Type | Description |
|--------|------|-------------|
| `acc_api_key` | string | Clé API (Google Translate, etc.) |
| `acc_active_modules` | array | Liste des modules activés |

### Cookies utilisateurs

Stockés côté client (durée: 365 jours) :

| Cookie | Module | Description |
|--------|--------|-------------|
| `acc_text_font` | text | Police sélectionnée |
| `acc_text_size` | text | Taille du texte |
| `acc_brightness_mode` | brightness | Mode d'affichage |
| `acc_button_size` | button-size | Taille des boutons |
| ... | ... | ... |

**Convention** : `acc_[module]_[parametre]`

### Transients WordPress

Pour le cache de validation API :

| Transient | Durée | Description |
|-----------|-------|-------------|
| `acc_api_key_validated` | 1 jour | Cache de validation API |
| `acc_api_key_error` | 5 min | Erreur de validation |

---

## 🎨 Système de styles

### Hiérarchie CSS

```
1. frontend.css (styles de base)
    ↓
2. modules/*/assets/style.css (styles spécifiques)
    ↓
3. CSS injecté dynamiquement via JavaScript
```

### Variables CSS

Définies dans `:root` (frontend.css) :

```css
:root {
    --acc-primary: #2563eb;
    --acc-background: #ffffff;
    --acc-text: #1e293b;
    /* ... */
}
```

Utilisables partout :

```css
.mon-element {
    color: var(--acc-primary);
}
```

### Classes utilitaires

Préfixe : `acc-`

| Classe | Usage |
|--------|-------|
| `.acc-module` | Conteneur de module |
| `.acc-button` | Bouton standard |
| `.acc-slider` | Slider de réglage |
| `.acc-control-group` | Groupe de contrôles |
| `.acc-control-label` | Label de contrôle |

---

## 🔌 Hooks et filtres

### Actions WordPress utilisées

```php
// Chargement des scripts
add_action('wp_enqueue_scripts', 'callback');
add_action('admin_enqueue_scripts', 'callback');

// Affichage du widget
add_action('wp_footer', 'callback');

// Activation/Désactivation
register_activation_hook(__FILE__, 'callback');
register_deactivation_hook(__FILE__, 'callback');
```

### Filtres personnalisés

```php
// Ajouter des métadonnées à un module
apply_filters('acc_module_metadata', $metadata, $module_name);

// Valider une clé API en ligne
apply_filters('acc_validate_api_key_online', false);

// Ajouter des classes au body
add_filter('body_class', 'callback');
```

### Hooks JavaScript

```javascript
// Chargement des préférences terminé
$(document).on('acc:preferences:loaded', function() {
    // Code
});

// Module modifié
$(document).on('acc:module:changed', function(e, data) {
    // Code
});
```

---

## 🔒 Système de protection

### Validation des modules

```
1. Vérifier présence de README.md
    ↓
2. Chercher marqueur <!-- MODULE_PROTECTION: DO_NOT_MODIFY -->
    ↓
3. Vérifier <!-- MODULE_VERSION: ... -->
    ↓
4. Vérifier <!-- MODULE_CHECKSUM: ... -->
    ↓
5. Si tous présents → Module valide
6. Sinon → Module rejeté
```

### Checksums

Les checksums dans README.md permettent de détecter les modifications :

```markdown
<!-- MODULE_CHECKSUM: a7f3d9c2b8e1f6a4d5c9e7b3a2f8d1c6 -->
```

Le Module Registry calcule le hash MD5 du README et compare avec le checksum déclaré.

---

## ♿ Accessibilité RGAA

### Critères implémentés

| Critère | Description | Implémentation |
|---------|-------------|----------------|
| 3.2 | Contraste suffisant | Modes de luminosité |
| 10.4 | Taille de texte ajustable | Module texte |
| 10.11 | Personnalisation affichage | Tous les modules |
| 13.9 | Contrôles identifiables | Taille des boutons |
| 2.5.5 | Taille de cible (WCAG) | Minimum 44×44px |

### Navigation clavier

Toutes les fonctionnalités sont accessibles au clavier :

- **Tab** : Navigation vers l'avant
- **Shift+Tab** : Navigation vers l'arrière
- **Enter/Space** : Activation
- **Flèches** : Navigation dans les groupes
- **Esc** : Fermeture

### Lecteurs d'écran

Support complet avec :
- Attributs ARIA appropriés
- Zones live pour les annonces
- Rôles sémantiques
- Labels explicites

---

## 📊 Performance

### Optimisations

1. **Chargement conditionnel**
   - Scripts chargés seulement si clé API présente
   - Modules chargés seulement si actifs

2. **Cache**
   - Validation API mise en cache (transients)
   - CSS généré une seule fois

3. **GPU Acceleration**
   - Utilisation de `transform` plutôt que `width/height`
   - Filtres CSS accélérés par GPU

4. **Minification**
   - CSS et JS peuvent être minifiés en production

### Métriques cibles

- **Poids total** : < 100KB (sans modules)
- **Temps de chargement** : < 100ms
- **First Paint** : Pas d'impact
- **TTI** : Impact < 50ms

---

## 🔐 Sécurité

### Validations

1. **Nonces WordPress**
   ```php
   wp_nonce_field('acc_settings_nonce');
   check_admin_referer('acc_settings_nonce');
   ```

2. **Sanitization**
   ```php
   sanitize_text_field($_POST['acc_api_key']);
   sanitize_modules($input);
   ```

3. **Échappement**
   ```php
   esc_html($text);
   esc_attr($attribute);
   esc_url($url);
   ```

### Permissions

- **Admin** : `manage_options` pour les réglages
- **Frontend** : Aucune permission requise (lecture seule)

---

## 🧪 Tests

### Tests unitaires (recommandés)

Structure pour PHPUnit :

```
tests/
├── test-module-registry.php
├── test-api-handler.php
└── test-admin-settings.php
```

### Tests manuels

Checklist dans chaque module :
- Navigation clavier
- Lecteurs d'écran
- Navigateurs multiples
- Thèmes différents

---

## 📈 Évolution future

### Extensibilité prévue

Le système est conçu pour supporter :

1. **Nouveaux modules** : Ajout illimité sans modification du core
2. **Nouvelles catégories** : Extensible via config.json
3. **Nouveaux types de contrôles** : Widgets personnalisés
4. **Intégrations externes** : APIs tierces
5. **Traductions** : i18n complet

### Roadmap possible

- Support de plus d'APIs (Azure, AWS)
- Statistiques d'utilisation
- Presets d'accessibilité
- Export/Import de configurations
- Mode développeur avec debug

---

## 📚 Ressources complémentaires

- **RGAA 4.1** : https://www.numerique.gouv.fr/publications/rgaa-accessibilite/
- **WordPress Coding Standards** : https://developer.wordpress.org/coding-standards/
- **Accessibilité Web** : https://www.w3.org/WAI/

---

**Dernière mise à jour** : 15 janvier 2025  
**Version** : 1.0.0

**Cette architecture garantit extensibilité, maintenabilité et accessibilité ! 🚀**