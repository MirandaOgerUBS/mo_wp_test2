# Guide d'Installation - Accessibilité Modulaire

Guide complet pour installer et configurer le plugin Accessibilité Modulaire sur votre site WordPress.

---

## 📋 Prérequis

Avant de commencer l'installation, assurez-vous que votre environnement répond aux exigences suivantes :

### Requis

- ✅ **WordPress** : Version 5.8 ou supérieure
- ✅ **PHP** : Version 7.4 ou supérieure
- ✅ **MySQL** : Version 5.7 ou supérieure (ou MariaDB 10.2+)
- ✅ **Clé API** : Clé API Google Translate ou compatible

### Recommandé

- 💡 **HTTPS** : Certificat SSL actif pour la sécurité
- 💡 **Mémoire PHP** : Au moins 64MB (128MB recommandé)
- 💡 **Thème compatible** : Thème WordPress à jour et standard

---

## 🚀 Installation

### Méthode 1 : Installation manuelle (Recommandée)

1. **Téléchargez le plugin**
   - Téléchargez l'archive `accessibility-modular.zip`

2. **Décompressez l'archive**
   ```bash
   unzip accessibility-modular.zip
   ```

3. **Uploadez le dossier**
   - Transférez le dossier `accessibility-modular/` dans `/wp-content/plugins/`
   - Via FTP, SFTP ou le gestionnaire de fichiers de votre hébergeur

4. **Vérifiez les permissions**
   ```bash
   chmod 755 /wp-content/plugins/accessibility-modular
   chmod 644 /wp-content/plugins/accessibility-modular/*.php
   ```

### Méthode 2 : Téléversement via WordPress

1. Connectez-vous à votre tableau de bord WordPress
2. Allez dans **Extensions** → **Ajouter**
3. Cliquez sur **Téléverser une extension**
4. Sélectionnez le fichier `accessibility-modular.zip`
5. Cliquez sur **Installer maintenant**

### Méthode 3 : Ligne de commande (WP-CLI)

```bash
# Naviguez vers le dossier WordPress
cd /path/to/wordpress

# Installez le plugin
wp plugin install /path/to/accessibility-modular.zip

# Activez le plugin
wp plugin activate accessibility-modular
```

---

## 🔧 Activation

1. Allez dans **Extensions** → **Extensions installées**
2. Trouvez **Accessibilité Modulaire**
3. Cliquez sur **Activer**

✅ Le plugin est maintenant actif !

---

## 🔑 Configuration de la clé API

**IMPORTANT** : Le widget ne fonctionnera pas sans une clé API valide.

### Étape 1 : Obtenir une clé API Google

1. **Accédez à Google Cloud Console**
   - Rendez-vous sur https://console.cloud.google.com/

2. **Créez un projet** (si vous n'en avez pas déjà un)
   - Cliquez sur le menu déroulant du projet en haut
   - Cliquez sur **Nouveau projet**
   - Donnez un nom à votre projet (ex: "Mon Site WordPress")
   - Cliquez sur **Créer**

3. **Activez l'API Cloud Translation**
   - Dans le menu, allez dans **APIs & Services** → **Bibliothèque**
   - Recherchez "Cloud Translation API"
   - Cliquez dessus et cliquez sur **Activer**

4. **Créez des identifiants**
   - Allez dans **APIs & Services** → **Identifiants**
   - Cliquez sur **Créer des identifiants** → **Clé API**
   - Votre clé API est générée !
   - **Important** : Copiez-la immédiatement

5. **Sécurisez votre clé** (Recommandé)
   - Cliquez sur votre clé pour la modifier
   - Sous "Restrictions relatives à l'application", choisissez "Référents HTTP"
   - Ajoutez votre domaine : `votresite.com/*`
   - Sous "Restrictions relatives aux API", sélectionnez "Cloud Translation API"
   - Enregistrez

### Étape 2 : Configurer dans WordPress

1. Allez dans **Réglages** → **Accessibilité**
2. Dans le champ **Clé API**, collez votre clé
3. Cliquez sur **Sauvegarder les réglages**

✅ Votre clé API est configurée !

---

## 🎯 Sélection des modules

Par défaut, tous les modules sont activés. Vous pouvez personnaliser :

1. Allez dans **Réglages** → **Accessibilité**
2. Faites défiler jusqu'à **Modules disponibles**
3. **Cochez/Décochez** les modules selon vos besoins :
   - 📝 **Texte** : Personnalisation de la typographie
   - 💡 **Luminosité** : Modes d'affichage et filtres visuels
   - 🔘 **Taille des boutons** : Ajustement de la taille des éléments interactifs
4. Cliquez sur **Sauvegarder les réglages**

### Actions en masse

- **Tout sélectionner** : Active tous les modules d'un coup
- **Tout désélectionner** : Désactive tous les modules

---

## ✅ Vérification de l'installation

### 1. Vérifiez le widget sur le site

1. Visitez la page d'accueil de votre site
2. Vous devriez voir un **bouton flottant** en bas à droite
3. Cliquez dessus pour ouvrir le widget

### 2. Testez un module

1. Ouvrez le widget
2. Cliquez sur une catégorie (ex: Vision)
3. Testez un module (ex: changez la taille du texte)
4. Les modifications doivent s'appliquer immédiatement

### 3. Vérifiez la persistance

1. Modifiez quelques paramètres
2. Fermez le navigateur
3. Revenez sur le site
4. Les paramètres doivent être conservés (cookies)

---

## 🐛 Dépannage

### Le widget n'apparaît pas

**Causes possibles :**

1. ❌ **Pas de clé API configurée**
   - Solution : Configurez une clé API valide

2. ❌ **Conflit JavaScript**
   - Solution : Désactivez temporairement les autres plugins
   - Vérifiez la console du navigateur (F12)

3. ❌ **Cache actif**
   - Solution : Videz le cache du plugin de cache
   - Videz le cache du navigateur (Ctrl+Shift+R)

4. ❌ **Thème incompatible**
   - Solution : Testez avec un thème par défaut (Twenty Twenty-Three)

### Les modules ne fonctionnent pas

1. **Vérifiez que les modules sont activés**
   - Réglages → Accessibilité → Modules disponibles

2. **Vérifiez les conflits CSS**
   - Certains thèmes utilisent `!important` excessivement
   - Inspectez les éléments avec les outils développeur

3. **Vérifiez les cookies**
   - Assurez-vous que les cookies sont autorisés
   - Testez en navigation privée

### Erreurs JavaScript

1. **Ouvrez la console** (F12 → Console)
2. Recherchez les erreurs en rouge
3. Partagez l'erreur sur le forum de support

### Performances ralenties

1. **Désactivez les modules non utilisés**
   - Gardez seulement ce dont vous avez besoin

2. **Optimisez le cache**
   - Utilisez un plugin de cache compatible

3. **Vérifiez l'hébergement**
   - Assurez-vous d'avoir assez de ressources

---

## 🔄 Mise à jour

### Mise à jour manuelle

1. **Désactivez** le plugin (ne le supprimez pas)
2. Supprimez l'ancien dossier `accessibility-modular/`
3. Uploadez la nouvelle version
4. **Activez** le plugin
5. Vérifiez que tout fonctionne

### Avec WP-CLI

```bash
wp plugin update accessibility-modular
```

**Note** : Les paramètres et préférences utilisateurs sont conservés.

---

## 🗑️ Désinstallation

### Désactivation seulement

1. Allez dans **Extensions** → **Extensions installées**
2. Trouvez **Accessibilité Modulaire**
3. Cliquez sur **Désactiver**

Les données sont conservées.

### Suppression complète

1. **Désactivez** d'abord le plugin
2. Cliquez sur **Supprimer**
3. Confirmez la suppression

**Données supprimées :**
- Options WordPress (`acc_api_key`, `acc_active_modules`)
- Cookies utilisateurs (lors de la prochaine visite)

**Données conservées :**
- Aucune donnée n'est conservée après suppression

---

## 📱 Configuration mobile

Le widget est automatiquement responsive et fonctionne sur tous les appareils.

### Optimisations mobiles recommandées

1. **Taille minimale des boutons** : 44x44px (automatique)
2. **Touch-friendly** : Espacement suffisant entre éléments
3. **Viewport** : Assurez-vous que votre thème utilise :
   ```html
   <meta name="viewport" content="width=device-width, initial-scale=1">
   ```

---

## 🌐 Multisite WordPress

Le plugin fonctionne sur WordPress Multisite :

### Installation réseau

1. Uploadez le plugin dans `/wp-content/plugins/`
2. Allez dans **Réseau** → **Extensions**
3. Cliquez sur **Activer sur le réseau**

### Configuration par site

Chaque site du réseau peut :
- Configurer sa propre clé API
- Activer/désactiver ses propres modules
- Les préférences utilisateurs sont par domaine (cookies)

---

## 🔐 Sécurité

### Bonnes pratiques

1. **Protégez votre clé API**
   - Ne la partagez jamais publiquement
   - Utilisez les restrictions de domaine

2. **Mettez à jour régulièrement**
   - Plugin
   - WordPress
   - PHP

3. **Sauvegardez votre site**
   - Avant toute mise à jour majeure

4. **Utilisez HTTPS**
   - Protège les données en transit

---

## 📞 Support

### Ressources

- 📧 **Email** : support@example.com
- 📚 **Documentation** : Consultez les fichiers README.md
- 🐛 **Bugs** : Ouvrez une issue sur GitHub
- 💬 **Forum** : Forum WordPress

### Avant de demander de l'aide

1. Vérifiez la console JavaScript (F12)
2. Testez avec un thème par défaut
3. Désactivez les autres plugins temporairement
4. Videz tous les caches

---

## ✨ Prochaines étapes

Après l'installation :

1. 📖 Lisez le fichier `README.md` principal
2. 🤖 Consultez `AI_INSTRUCTIONS.md` si vous développez
3. 🏗️ Examinez `STRUCTURE.md` pour comprendre l'architecture
4. 🎨 Personnalisez les modules selon vos besoins

---

**Félicitations ! Votre site est maintenant plus accessible ! ♿**

Version : 1.0.0  
Date : 15 janvier 2025