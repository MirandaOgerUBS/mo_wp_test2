<?php
/**
 * Gestionnaire API
 * Vérifie et valide la clé API
 */

if (!defined('ABSPATH')) {
    exit;
}

class ACC_API_Handler {
    
    private static $instance = null;
    private $api_key = null;
    private $api_validated = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->api_key = get_option('acc_api_key', '');
        add_action('update_option_acc_api_key', [$this, 'on_api_key_update'], 10, 2);
    }
    
    /**
     * Vérifie si une clé API est configurée
     * 
     * @return bool
     */
    public function has_api_key() {
        return !empty($this->api_key);
    }
    
    /**
     * Récupère la clé API
     * 
     * @return string
     */
    public function get_api_key() {
        return $this->api_key;
    }
    
    /**
     * Valide la clé API (optionnel selon le service utilisé)
     * 
     * @param string $api_key La clé à valider
     * @return bool|WP_Error
     */
    public function validate_api_key($api_key = null) {
        if (null === $api_key) {
            $api_key = $this->api_key;
        }
        
        if (empty($api_key)) {
            return new WP_Error('no_api_key', 'Aucune clé API fournie');
        }
        
        // Si déjà validée en cache
        if ($this->api_validated === true && $api_key === $this->api_key) {
            return true;
        }
        
        // Validation basique : longueur minimale
        if (strlen($api_key) < 20) {
            return new WP_Error('invalid_api_key', 'La clé API semble invalide (trop courte)');
        }
        
        // Validation du format (exemple pour Google API)
        if (!preg_match('/^[A-Za-z0-9_-]+$/', $api_key)) {
            return new WP_Error('invalid_format', 'Format de clé API invalide');
        }
        
        // Vérification avec le service (optionnel - exemple désactivé par défaut)
        if (apply_filters('acc_validate_api_key_online', false)) {
            $validation_result = $this->validate_api_key_online($api_key);
            if (is_wp_error($validation_result)) {
                return $validation_result;
            }
        }
        
        // Sauvegarde en cache
        $this->api_validated = true;
        set_transient('acc_api_key_validated', true, DAY_IN_SECONDS);
        
        return true;
    }
    
    /**
     * Valide la clé API en ligne (exemple pour Google Translate)
     * 
     * @param string $api_key
     * @return bool|WP_Error
     */
    private function validate_api_key_online($api_key) {
        // Exemple de validation avec Google Translate API
        $test_url = add_query_arg([
            'key' => $api_key,
            'q' => 'test',
            'target' => 'en'
        ], 'https://translation.googleapis.com/language/translate/v2');
        
        $response = wp_remote_get($test_url, [
            'timeout' => 5,
            'headers' => [
                'Content-Type' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            return new WP_Error('api_error', 'Erreur lors de la validation de la clé API');
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200) {
            return true;
        } elseif ($status_code === 400) {
            return new WP_Error('invalid_key', 'Clé API invalide');
        } elseif ($status_code === 403) {
            return new WP_Error('forbidden', 'Clé API sans les permissions nécessaires');
        } else {
            return new WP_Error('unknown_error', 'Erreur inconnue lors de la validation');
        }
    }
    
    /**
     * Hook lors de la mise à jour de la clé API
     */
    public function on_api_key_update($old_value, $new_value) {
        // Réinitialise la validation
        $this->api_validated = null;
        delete_transient('acc_api_key_validated');
        
        // Valide la nouvelle clé
        if (!empty($new_value)) {
            $validation = $this->validate_api_key($new_value);
            
            if (is_wp_error($validation)) {
                // Enregistre l'erreur pour affichage dans l'admin
                set_transient('acc_api_key_error', $validation->get_error_message(), MINUTE_IN_SECONDS * 5);
            }
        }
    }
    
    /**
     * Vérifie si la clé API est valide
     * 
     * @return bool
     */
    public function is_api_key_valid() {
        if (!$this->has_api_key()) {
            return false;
        }
        
        // Vérifie le cache
        if (get_transient('acc_api_key_validated') === true) {
            return true;
        }
        
        $validation = $this->validate_api_key();
        return !is_wp_error($validation);
    }
    
    /**
     * Récupère le message d'erreur de validation s'il existe
     * 
     * @return string|null
     */
    public function get_validation_error() {
        $error = get_transient('acc_api_key_error');
        
        if ($error) {
            delete_transient('acc_api_key_error');
            return $error;
        }
        
        return null;
    }
    
    /**
     * Effectue un appel API (exemple pour traduction)
     * 
     * @param string $text Texte à traduire
     * @param string $target_lang Langue cible
     * @param string $source_lang Langue source (optionnel)
     * @return array|WP_Error
     */
    public function translate_text($text, $target_lang, $source_lang = 'auto') {
        if (!$this->is_api_key_valid()) {
            return new WP_Error('invalid_api_key', 'Clé API invalide');
        }
        
        $url = 'https://translation.googleapis.com/language/translate/v2';
        
        $args = [
            'timeout' => 10,
            'body' => json_encode([
                'q' => $text,
                'target' => $target_lang,
                'source' => $source_lang,
                'format' => 'text'
            ]),
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->api_key
            ]
        ];
        
        $response = wp_remote_post($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['data']['translations'][0]['translatedText'])) {
            return [
                'translated_text' => $data['data']['translations'][0]['translatedText'],
                'detected_source_language' => $data['data']['translations'][0]['detectedSourceLanguage'] ?? $source_lang
            ];
        }
        
        return new WP_Error('translation_failed', 'Échec de la traduction');
    }
    
    /**
     * Nettoie les caches et transients
     */
    public function clear_cache() {
        delete_transient('acc_api_key_validated');
        delete_transient('acc_api_key_error');
        $this->api_validated = null;
    }
}