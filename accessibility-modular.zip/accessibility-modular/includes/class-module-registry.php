<?php
/**
 * Module Registry
 * Gère l'enregistrement et la récupération des modules
 */

if (!defined('ABSPATH')) {
    exit;
}

class ACC_Module_Registry {
    
    private static $instance = null;
    private $modules = [];
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Constructor
    }
    
    /**
     * Enregistre un module
     */
    public function register_module($name, $path) {
        $config_file = $path . '/config.json';
        
        if (file_exists($config_file)) {
            $config = json_decode(file_get_contents($config_file), true);
            
            $this->modules[$name] = [
                'name' => $name,
                'path' => $path,
                'config' => $config
            ];
        } else {
            $this->modules[$name] = [
                'name' => $name,
                'path' => $path,
                'config' => []
            ];
        }
    }
    
    /**
     * Récupère tous les modules
     */
    public function get_all_modules() {
        return $this->modules;
    }
    
    /**
     * Récupère les modules actifs
     */
    public function get_active_modules() {
        $active_modules = get_option('acc_active_modules', []);
        
        // Si aucun module actif, activer tous par défaut
        if (empty($active_modules)) {
            $active_modules = array_keys($this->modules);
            update_option('acc_active_modules', $active_modules);
        }
        
        return $active_modules;
    }
    
    /**
     * Vérifie si un module est actif
     */
    public function is_module_active($name) {
        $active_modules = $this->get_active_modules();
        return in_array($name, $active_modules);
    }
    
    /**
     * Récupère un module spécifique
     */
    public function get_module($name) {
        return isset($this->modules[$name]) ? $this->modules[$name] : null;
    }
    
    /**
     * Récupère les informations formatées d'un module
     * Utilisé par widget.php pour afficher les modules
     * 
     * @param string $name Nom du module
     * @return array|null Informations du module
     */
    public function get_module_info($name) {
        if (!isset($this->modules[$name])) {
            return null;
        }
        
        $module = $this->modules[$name];
        $config = $module['config'];
        
        // Extraction des informations importantes du config.json
        return [
            'name' => $name,
            'title' => $config['title'] ?? ucfirst($name),
            'description' => $config['description'] ?? '',
            'icon' => $config['icon'] ?? '📦',
            'category' => $config['category'] ?? 'general',
            'version' => $config['version'] ?? '1.0.0',
            'enabled' => $config['enabled'] ?? true,
            'priority' => $config['priority'] ?? 50,
            'path' => $module['path'],
            'config' => $config
        ];
    }
    
    /**
     * Récupère tous les modules groupés par catégorie
     * 
     * @return array Modules groupés par catégorie
     */
    public function get_modules_by_category() {
        $categorized = [];
        
        foreach ($this->modules as $name => $module) {
            $config = $module['config'];
            $category = $config['category'] ?? 'general';
            
            if (!isset($categorized[$category])) {
                $categorized[$category] = [];
            }
            
            $categorized[$category][$name] = $this->get_module_info($name);
        }
        
        return $categorized;
    }
    
    /**
     * Compte le nombre de modules par catégorie
     * 
     * @return array Nombre de modules par catégorie
     */
    public function count_modules_by_category() {
        $counts = [];
        
        foreach ($this->modules as $module) {
            $config = $module['config'];
            $category = $config['category'] ?? 'general';
            
            if (!isset($counts[$category])) {
                $counts[$category] = 0;
            }
            
            $counts[$category]++;
        }
        
        return $counts;
    }
}