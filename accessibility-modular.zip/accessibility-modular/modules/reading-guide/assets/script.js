/**
 * Module Guide de Lecture - JavaScript (Avec personnalisation règle)
 * Gestion des outils d'aide à la lecture
 * Version: 1.3.0 - Sommaire amélioré avec détection intelligente
 * 
 * IMPORTANT: Utilise uniquement les cookies (pas localStorage)
 */

(function($) {
    'use strict';

    /**
     * Classe du module Guide de Lecture
     */
    class ReadingGuideModule {
        constructor() {
            this.module = $('#acc-module-reading-guide');
            this.toggle = $('#acc-reading-guide-toggle');
            this.content = $('#acc-reading-guide-content');
            this.featureInputs = $('.acc-feature-input');
            this.resetBtn = $('#acc-reading-guide-reset');
            
            this.features = {
                ruler: new RulerFeature(),
                syllables: new SyllablesFeature(),
                toc: new TOCFeature(),
                focus: new FocusFeature()
            };
            
            this.isActive = false;
            
            this.init();
        }

        /**
         * Initialisation
         */
        init() {
            this.loadSettings();
            this.bindEvents();
            
            // Appliquer les paramètres sauvegardés
            if (this.isActive) {
                this.restoreFeatures();
            }
        }

        /**
         * Liaison des événements
         */
        bindEvents() {
            // Toggle du module
            this.toggle.on('change', () => this.handleToggle());
            
            // Features individuelles
            this.featureInputs.on('change', (e) => this.handleFeatureToggle(e));
            
            // Réinitialisation
            this.resetBtn.on('click', () => this.reset());
        }

        /**
         * Gère l'activation/désactivation du module
         */
        handleToggle() {
            this.isActive = this.toggle.is(':checked');
            
            if (this.isActive) {
                this.content.slideDown(300);
                this.savePreference('active', true);
                this.announce('Module Guide de Lecture activé');
            } else {
                this.content.slideUp(300);
                this.disableAllFeatures();
                this.savePreference('active', false);
                this.announce('Module Guide de Lecture désactivé');
            }
        }

        /**
         * Gère l'activation/désactivation d'une feature
         */
        handleFeatureToggle(e) {
            const $input = $(e.currentTarget);
            const featureName = $input.data('feature');
            const isEnabled = $input.is(':checked');
            
            const feature = this.features[featureName];
            if (!feature) return;
            
            if (isEnabled) {
                feature.enable();
                this.announce(`${featureName} activé`);
                
                // Afficher les options de personnalisation pour la règle
                if (featureName === 'ruler') {
                    $('#acc-ruler-options').slideDown(300);
                }
            } else {
                feature.disable();
                this.announce(`${featureName} désactivé`);
                
                // Masquer les options de personnalisation pour la règle
                if (featureName === 'ruler') {
                    $('#acc-ruler-options').slideUp(300);
                }
            }
            
            this.savePreference(`feature_${featureName}`, isEnabled);
        }

        /**
         * Désactive toutes les features
         */
        disableAllFeatures() {
            this.featureInputs.each((i, input) => {
                $(input).prop('checked', false);
                const featureName = $(input).data('feature');
                if (this.features[featureName]) {
                    this.features[featureName].disable();
                }
            });
            
            // Masquer les options de la règle
            $('#acc-ruler-options').hide();
        }

        /**
         * Restaure les features sauvegardées
         */
        restoreFeatures() {
            this.featureInputs.each((i, input) => {
                const $input = $(input);
                const featureName = $input.data('feature');
                const isEnabled = this.getPreference(`feature_${featureName}`, false);
                
                if (isEnabled) {
                    $input.prop('checked', true);
                    if (this.features[featureName]) {
                        this.features[featureName].enable();
                        
                        // Afficher les options si c'est la règle
                        if (featureName === 'ruler') {
                            $('#acc-ruler-options').show();
                        }
                    }
                }
            });
        }

        /**
         * Réinitialise tous les paramètres
         */
        reset() {
            if (confirm('Désactiver toutes les fonctionnalités ?')) {
                this.disableAllFeatures();
                
                // Sauvegarder l'état
                this.featureInputs.each((i, input) => {
                    const featureName = $(input).data('feature');
                    this.savePreference(`feature_${featureName}`, false);
                });
                
                this.announce('Toutes les fonctionnalités désactivées');
            }
        }

        /**
         * Sauvegarde une préférence
         */
        savePreference(key, value) {
            window.accWidget.savePreference(`reading_${key}`, value);
        }

        /**
         * Récupère une préférence
         */
        getPreference(key, defaultValue) {
            return window.accWidget.getPreference(`reading_${key}`, defaultValue);
        }

        /**
         * Charge les paramètres sauvegardés
         */
        loadSettings() {
            this.isActive = this.getPreference('active', false);
            this.toggle.prop('checked', this.isActive);
            
            if (this.isActive) {
                this.content.show();
            }
        }

        /**
         * Annonce pour les lecteurs d'écran
         */
        announce(message) {
            if (window.accWidget) {
                window.accWidget.announce(message);
            }
        }
    }

    /**
     * Feature: Règle de lecture (AVEC PERSONNALISATION)
     */
    class RulerFeature {
        constructor() {
            this.enabled = false;
            this.$ruler = null;
            
            // Paramètres par défaut
            this.settings = {
                color: '#ffff00',
                height: 40,
                opacity: 30
            };
            
            this.initControls();
        }

        /**
         * Initialise les contrôles de personnalisation
         */
        initControls() {
            // Charger les préférences sauvegardées
            this.loadSettings();
            
            // Mettre à jour les valeurs des contrôles
            $('#acc-ruler-color').val(this.settings.color);
            $('#acc-ruler-height').val(this.settings.height);
            $('#acc-ruler-opacity').val(this.settings.opacity);
            $('#acc-ruler-height-value').text(this.settings.height + 'px');
            $('#acc-ruler-opacity-value').text(this.settings.opacity + '%');
            $('#acc-ruler-color-preview').css('background', this.settings.color);
            
            // Événements de changement
            $('#acc-ruler-color').on('input change', (e) => {
                this.settings.color = e.target.value;
                $('#acc-ruler-color-preview').css('background', this.settings.color);
                this.applySettings();
                this.saveSettings();
            });
            
            $('#acc-ruler-height').on('input', (e) => {
                this.settings.height = parseInt(e.target.value);
                $('#acc-ruler-height-value').text(this.settings.height + 'px');
                this.applySettings();
                this.saveSettings();
            });
            
            $('#acc-ruler-opacity').on('input', (e) => {
                this.settings.opacity = parseInt(e.target.value);
                $('#acc-ruler-opacity-value').text(this.settings.opacity + '%');
                this.applySettings();
                this.saveSettings();
            });
        }

        /**
         * Charge les paramètres sauvegardés
         */
        loadSettings() {
            this.settings.color = this.getPreference('ruler_color', '#ffff00');
            this.settings.height = this.getPreference('ruler_height', 40);
            this.settings.opacity = this.getPreference('ruler_opacity', 30);
        }

        /**
         * Sauvegarde les paramètres
         */
        saveSettings() {
            this.savePreference('ruler_color', this.settings.color);
            this.savePreference('ruler_height', this.settings.height);
            this.savePreference('ruler_opacity', this.settings.opacity);
        }

        /**
         * Applique les paramètres à la règle
         */
        applySettings() {
            if (!this.$ruler) return;
            
            const rgba = this.hexToRgba(this.settings.color, this.settings.opacity / 100);
            
            this.$ruler.css({
                'height': this.settings.height + 'px',
                'background': rgba
            });
        }

        /**
         * Active la règle
         */
        enable() {
            if (this.enabled) return;
            
            this.$ruler = $('<div>', {
                id: 'acc-reading-ruler-active',
                class: 'acc-reading-ruler'
            });
            
            $('body').append(this.$ruler);
            
            // Appliquer les paramètres personnalisés
            this.applySettings();
            
            // Suivre le curseur
            $(document).on('mousemove.ruler', (e) => {
                if (this.$ruler) {
                    const top = e.clientY - (this.settings.height / 2);
                    this.$ruler.css('top', top + 'px').show();
                }
            });
            
            this.enabled = true;
            console.log('✓ Règle activée avec personnalisation:', this.settings);
        }

        /**
         * Désactive la règle
         */
        disable() {
            if (!this.enabled) return;
            
            $(document).off('mousemove.ruler');
            if (this.$ruler) {
                this.$ruler.remove();
                this.$ruler = null;
            }
            
            this.enabled = false;
        }

        /**
         * Convertit hex en rgba
         */
        hexToRgba(hex, alpha) {
            const r = parseInt(hex.slice(1, 3), 16);
            const g = parseInt(hex.slice(3, 5), 16);
            const b = parseInt(hex.slice(5, 7), 16);
            return `rgba(${r}, ${g}, ${b}, ${alpha})`;
        }

        /**
         * Sauvegarde une préférence
         */
        savePreference(key, value) {
            window.accWidget.savePreference(`reading_${key}`, value);
        }

        /**
         * Récupère une préférence
         */
        getPreference(key, defaultValue) {
            return window.accWidget.getPreference(`reading_${key}`, defaultValue);
        }
    }

    /**
     * Feature: Division des syllabes (ALGORITHME AMÉLIORÉ)
     */
    class SyllablesFeature {
        constructor() {
            this.enabled = false;
            this.originalContent = new Map();
            this.separator = '·';
            
            // Voyelles (avec accents)
            this.vowels = 'aeiouyàâäéèêëïîôöùûü';
            
            // Groupes de consonnes inséparables
            this.inseparableGroups = [
                'bl', 'br', 'cl', 'cr', 'dr', 'fl', 'fr', 'gl', 'gr', 
                'pl', 'pr', 'tr', 'vr', 'ch', 'ph', 'th', 'gn'
            ];
            
            // Groupes de voyelles (diphtongues)
            this.vowelGroups = [
                'ai', 'au', 'eau', 'ei', 'eu', 'ou', 'oi', 'ay', 'oy', 
                'ui', 'ue', 'io', 'ia', 'ié', 'ieu', 'ain', 'ein', 'oin'
            ];
        }

        enable() {
            if (this.enabled) return;
            
            const $elements = $('p, h1, h2, h3, h4, h5, h6, li, span, td, th')
                .not('[data-syllabified]')
                .not('.acc-widget *'); // Exclure le widget
            
            $elements.each((i, el) => {
                const $el = $(el);
                
                // Ne traiter que les éléments avec du texte direct (pas d'enfants complexes)
                if ($el.children().length === 0) {
                    const text = $el.text().trim();
                    
                    if (text && text.length > 2) {
                        this.originalContent.set(el, text);
                        const syllabified = this.syllabify(text);
                        $el.html(syllabified)
                            .attr('data-syllabified', 'true')
                            .addClass('acc-syllabified');
                    }
                }
            });
            
            this.enabled = true;
            console.log(`✓ Syllabification appliquée à ${this.originalContent.size} éléments`);
        }

        disable() {
            if (!this.enabled) return;
            
            this.originalContent.forEach((original, el) => {
                $(el).text(original)
                    .removeAttr('data-syllabified')
                    .removeClass('acc-syllabified');
            });
            
            console.log(`✓ Syllabification restaurée pour ${this.originalContent.size} éléments`);
            this.originalContent.clear();
            this.enabled = false;
        }

        /**
         * Syllabifie un texte complet
         */
        syllabify(text) {
            // Séparer en mots en gardant la ponctuation et espaces
            const tokens = text.split(/(\s+|[.,;:!?()«»"'\-—–])/);
            
            return tokens.map(token => {
                // Ne pas traiter les espaces, ponctuation, ou mots très courts
                if (/^\s+$/.test(token) || token.length < 3 || /^[.,;:!?()«»"'\-—–]+$/.test(token)) {
                    return token;
                }
                
                return this.syllabifyWord(token);
            }).join('');
        }

        /**
         * Syllabifie un mot selon les règles françaises
         */
        syllabifyWord(word) {
            // Mots trop courts ou nombres
            if (word.length < 3 || /^\d+$/.test(word)) {
                return word;
            }
            
            const lower = word.toLowerCase();
            const syllables = [];
            let currentSyllable = '';
            let i = 0;
            
            while (i < word.length) {
                const char = word[i];
                const lowerChar = lower[i];
                
                // Ajouter le caractère actuel
                currentSyllable += char;
                
                // Si c'est une voyelle
                if (this.isVowel(lowerChar)) {
                    // Vérifier les groupes de voyelles
                    const nextChars = lower.substring(i, i + 4);
                    let vowelGroupFound = false;
                    
                    for (const group of this.vowelGroups) {
                        if (nextChars.startsWith(group) && group.length > 1) {
                            // Ajouter le reste du groupe
                            for (let j = 1; j < group.length && i + j < word.length; j++) {
                                currentSyllable += word[i + j];
                            }
                            i += group.length - 1;
                            vowelGroupFound = true;
                            break;
                        }
                    }
                    
                    if (!vowelGroupFound) {
                        // Regarder ce qui suit
                        if (i + 1 < word.length) {
                            const next1 = lower[i + 1];
                            const next2 = i + 2 < word.length ? lower[i + 2] : '';
                            const next3 = i + 3 < word.length ? lower[i + 3] : '';
                            
                            // Voyelle suivie de voyelle = continuer
                            if (this.isVowel(next1)) {
                                i++;
                                continue;
                            }
                            
                            // Voyelle + consonne + voyelle = couper après la voyelle
                            if (!this.isVowel(next1) && this.isVowel(next2)) {
                                // Vérifier les groupes inséparables
                                const consonantGroup = next1 + next2;
                                if (!this.inseparableGroups.includes(consonantGroup)) {
                                    syllables.push(currentSyllable);
                                    currentSyllable = '';
                                }
                            }
                            // Voyelle + 2 consonnes + voyelle
                            else if (!this.isVowel(next1) && !this.isVowel(next2) && this.isVowel(next3)) {
                                const consonantGroup = next1 + next2;
                                
                                // Si c'est un groupe inséparable, couper avant
                                if (this.inseparableGroups.includes(consonantGroup)) {
                                    syllables.push(currentSyllable);
                                    currentSyllable = '';
                                }
                                // Sinon, prendre la première consonne et couper
                                else {
                                    currentSyllable += word[i + 1];
                                    i++;
                                    syllables.push(currentSyllable);
                                    currentSyllable = '';
                                }
                            }
                            // Voyelle + 3+ consonnes = prendre la première consonne
                            else if (!this.isVowel(next1) && !this.isVowel(next2) && !this.isVowel(next3)) {
                                currentSyllable += word[i + 1];
                                i++;
                                syllables.push(currentSyllable);
                                currentSyllable = '';
                            }
                        }
                    }
                }
                
                i++;
            }
            
            // Ajouter la dernière syllabe
            if (currentSyllable) {
                syllables.push(currentSyllable);
            }
            
            // Ne retourner syllabifié que si on a trouvé plusieurs syllabes
            if (syllables.length > 1) {
                return syllables.join(this.separator);
            }
            
            return word;
        }

        /**
         * Vérifie si un caractère est une voyelle
         */
        isVowel(char) {
            return this.vowels.includes(char.toLowerCase());
        }

        /**
         * Vérifie si un caractère est une consonne
         */
        isConsonant(char) {
            return /[a-zàâäéèêëïîôöùûü]/i.test(char) && !this.isVowel(char);
        }
    }

    /**
     * Feature: Sommaire (VERSION AMÉLIORÉE - Détection intelligente + Drag & Drop)
     */
    class TOCFeature {
        constructor() {
            this.enabled = false;
            this.$toc = null;
            this.isDragging = false;
            this.dragOffset = { x: 0, y: 0 };
        }

        enable() {
            if (this.enabled) return;
            this.generateTOC();
            this.enabled = true;
        }

        disable() {
            if (!this.enabled) return;
            
            if (this.$toc) {
                this.$toc.fadeOut(300, () => {
                    this.$toc.remove();
                    this.$toc = null;
                });
            }
            
            this.enabled = false;
        }

        /**
         * Détecte tous les éléments qui peuvent servir de titres
         */
        detectHeadings() {
            const headings = [];
            
            console.log('🔍 Détection des titres en cours...');
            
            // 1. HEADINGS SÉMANTIQUES (h1-h6) - PRIORITÉ MAX
            $('h1, h2, h3, h4, h5, h6').not('.acc-widget *').each((i, el) => {
                const $el = $(el);
                const text = $el.text().trim();
                if (text.length > 0 && $el.is(':visible')) {
                    headings.push({
                        element: el,
                        text: text,
                        level: parseInt(el.tagName.substring(1)),
                        type: 'semantic'
                    });
                }
            });
            
            console.log(`   ✓ ${headings.length} headings sémantiques trouvés`);
            
            // 2. ÉLÉMENTS AVEC ROLE="HEADING" (ARIA)
            $('[role="heading"]').not('.acc-widget *').each((i, el) => {
                const $el = $(el);
                // Éviter les doublons si c'est déjà un h1-h6
                if (!el.tagName.match(/^H[1-6]$/i) && $el.is(':visible')) {
                    const ariaLevel = parseInt($el.attr('aria-level')) || 2;
                    const text = $el.text().trim();
                    if (text.length > 0) {
                        headings.push({
                            element: el,
                            text: text,
                            level: ariaLevel,
                            type: 'aria'
                        });
                    }
                }
            });
            
            console.log(`   ✓ ${headings.filter(h => h.type === 'aria').length} éléments ARIA trouvés`);
            
            // 3. CLASSES COMMUNES DE TITRES
            const titleSelectors = [
                '.entry-title', '.post-title', '.page-title', 
                '.article-title', '.section-title', '.widget-title',
                '.block-title', '.content-title', '.heading-title',
                '.card-title', '.box-title', '.panel-title',
                'header h1', 'header h2', 'article h1', 'article h2'
            ];
            
            titleSelectors.forEach(selector => {
                try {
                    $(selector).not('.acc-widget *').each((i, el) => {
                        const $el = $(el);
                        // Éviter les doublons
                        if (!headings.find(h => h.element === el) && $el.is(':visible')) {
                            const text = $el.text().trim();
                            if (text.length > 0) {
                                const level = this.guessLevelFromStyle($el);
                                headings.push({
                                    element: el,
                                    text: text,
                                    level: level,
                                    type: 'class'
                                });
                            }
                        }
                    });
                } catch(e) {
                    // Ignorer les erreurs de sélecteur
                }
            });
            
            console.log(`   ✓ ${headings.filter(h => h.type === 'class').length} éléments avec classes trouvés`);
            
            // 4. DÉTECTION PAR STYLE (si peu de titres trouvés)
            if (headings.length < 5) {
                console.log('   ⚠ Peu de titres trouvés, détection par style...');
                this.detectByStyle(headings);
                console.log(`   ✓ ${headings.filter(h => h.type === 'style').length} éléments par style trouvés`);
            }
            
            // Trier par position dans le DOM
            headings.sort((a, b) => {
                const posA = $(a.element).offset();
                const posB = $(b.element).offset();
                return posA.top - posB.top;
            });
            
            console.log(`📊 TOTAL: ${headings.length} titres détectés`);
            
            return headings;
        }

        /**
         * Détecte les titres basés sur leur style
         */
        detectByStyle(headings) {
            const $candidates = $('p, div, span, strong, b, a')
                .not('.acc-widget *')
                .not('.acc-module *')
                .not('script, style, noscript');
            
            $candidates.each((i, el) => {
                const $el = $(el);
                
                // Déjà dans la liste ?
                if (headings.find(h => h.element === el)) return;
                
                // Doit être visible
                if (!$el.is(':visible')) return;
                
                // Doit avoir du texte court (pas un paragraphe)
                const text = $el.text().trim();
                if (text.length < 3 || text.length > 150) return;
                
                // Pas trop d'enfants complexes
                if ($el.find('*').length > 5) return;
                
                // Calculer un score basé sur le style
                const score = this.calculateHeadingScore($el);
                
                // Si le score est suffisant, c'est probablement un titre
                if (score >= 3) {
                    headings.push({
                        element: el,
                        text: text,
                        level: this.guessLevelFromStyle($el),
                        type: 'style',
                        score: score
                    });
                }
            });
        }

        /**
         * Calcule un score pour déterminer si un élément est un titre
         */
        calculateHeadingScore($el) {
            let score = 0;
            const styles = window.getComputedStyle($el[0]);
            
            // Taille de police > 16px
            const fontSize = parseFloat(styles.fontSize);
            if (fontSize >= 28) score += 3;
            else if (fontSize >= 22) score += 2;
            else if (fontSize >= 16) score += 1;
            
            // Texte en gras
            const fontWeight = parseInt(styles.fontWeight) || 400;
            if (fontWeight >= 700) score += 2;
            else if (fontWeight >= 600) score += 1;
            
            // Marge supérieure
            const marginTop = parseFloat(styles.marginTop);
            if (marginTop >= 20) score += 1;
            
            // Display block
            if (styles.display === 'block' || styles.display === 'flex') score += 1;
            
            // Texte court
            const textLength = $el.text().trim().length;
            if (textLength <= 60) score += 1;
            
            // Pas de point final
            if (!$el.text().trim().endsWith('.')) score += 1;
            
            return score;
        }

        /**
         * Devine le niveau d'un titre basé sur son style
         */
        guessLevelFromStyle($el) {
            const styles = window.getComputedStyle($el[0]);
            const fontSize = parseFloat(styles.fontSize);
            
            if (fontSize >= 32) return 1;
            if (fontSize >= 28) return 2;
            if (fontSize >= 24) return 3;
            if (fontSize >= 20) return 4;
            if (fontSize >= 18) return 5;
            return 6;
        }

        generateTOC() {
            const headings = this.detectHeadings();
            
            if (headings.length === 0) {
                alert('❌ Aucun titre trouvé sur cette page.\n\nOuvrez la console (F12) pour voir les détails de la détection.');
                $('#acc-reading-toc').prop('checked', false);
                return;
            }

            // Créer le conteneur du sommaire
            this.$toc = $('<div>', {
                id: 'acc-toc-container',
                class: 'acc-reading-toc-container',
                css: {
                    position: 'fixed',
                    top: '120px',
                    right: '20px',
                    width: '320px',
                    maxHeight: '70vh',
                    background: 'white',
                    border: '2px solid #333',
                    borderRadius: '12px',
                    boxShadow: '0 8px 24px rgba(0,0,0,0.2)',
                    zIndex: 999998,
                    display: 'none',
                    overflow: 'hidden'
                }
            });

            let html = `
                <div class="acc-toc-header" style="
                    padding: 16px 20px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    cursor: move;
                    user-select: none;
                ">
                    <h4 style="margin: 0; font-size: 16px; font-weight: 600;">
                        📑 Sommaire (${headings.length})
                    </h4>
                    <button class="acc-toc-close" style="
                        background: rgba(255,255,255,0.2);
                        border: none;
                        color: white;
                        width: 28px;
                        height: 28px;
                        border-radius: 50%;
                        cursor: pointer;
                        font-size: 18px;
                        transition: all 0.2s;
                        line-height: 1;
                    " aria-label="Fermer le sommaire">✕</button>
                </div>
                <div class="acc-toc-content" style="
                    padding: 15px 20px;
                    overflow-y: auto;
                    max-height: calc(70vh - 60px);
                ">
                    <ul class="acc-toc-list" style="
                        list-style: none;
                        padding: 0;
                        margin: 0;
                    ">
            `;

            headings.forEach((heading, i) => {
                const $h = $(heading.element);
                const text = heading.text;
                const level = heading.level;
                const indent = (level - 1) * 15;
                
                // Ajouter un ID si nécessaire
                if (!$h.attr('id')) {
                    $h.attr('id', 'acc-heading-' + i);
                }
                const id = $h.attr('id');

                // Badge de type (optionnel - pour debug)
                const showBadges = false; // Mettre à true pour voir les types
                const typeBadge = (showBadges && heading.type !== 'semantic') 
                    ? `<small style="opacity: 0.6; font-size: 10px; margin-right: 5px;">[${heading.type}]</small>` 
                    : '';

                html += `
                    <li style="margin-bottom: 8px; margin-left: ${indent}px;">
                        <a href="#${id}" class="acc-toc-link" data-target="${id}" style="
                            display: block;
                            padding: 8px 12px;
                            color: #0066cc;
                            text-decoration: none;
                            font-size: 14px;
                            border-radius: 6px;
                            transition: all 0.2s;
                            border-left: 3px solid transparent;
                        ">
                            ${typeBadge}${text}
                        </a>
                    </li>
                `;
            });

            html += `
                    </ul>
                </div>
                <div class="acc-toc-footer" style="
                    padding: 10px 20px;
                    background: #f5f5f5;
                    border-top: 1px solid #ddd;
                    font-size: 11px;
                    color: #666;
                    text-align: center;
                ">
                    💡 Glissez pour déplacer
                </div>
            `;

            this.$toc.html(html);
            $('body').append(this.$toc);
            
            // Afficher avec animation
            this.$toc.fadeIn(400);
            
            // Attacher les événements
            this.attachTOCEvents();
            
            console.log(`✅ Sommaire affiché avec ${headings.length} entrées:`, {
                semantic: headings.filter(h => h.type === 'semantic').length,
                aria: headings.filter(h => h.type === 'aria').length,
                class: headings.filter(h => h.type === 'class').length,
                style: headings.filter(h => h.type === 'style').length
            });
        }

        attachTOCEvents() {
            // Liens de navigation
            this.$toc.find('.acc-toc-link').on('click', (e) => {
                e.preventDefault();
                const targetId = $(e.currentTarget).data('target');
                const $target = $('#' + targetId);
                
                if ($target.length) {
                    // Animation de scroll
                    $('html, body').animate({
                        scrollTop: $target.offset().top - 100
                    }, 500);
                    
                    // Highlight temporaire
                    $target.css({
                        'background-color': 'rgba(255, 255, 0, 0.5)',
                        'transition': 'background-color 0.3s'
                    });
                    setTimeout(() => {
                        $target.css('background-color', '');
                    }, 2000);
                }
            });

            // Hover effect sur les liens
            this.$toc.find('.acc-toc-link').on('mouseenter', function() {
                $(this).css({
                    'background': '#e8f4ff',
                    'padding-left': '18px',
                    'border-left-color': '#0066cc'
                });
            }).on('mouseleave', function() {
                $(this).css({
                    'background': '',
                    'padding-left': '12px',
                    'border-left-color': 'transparent'
                });
            });

            // Bouton fermer
            this.$toc.find('.acc-toc-close').on('click', () => {
                this.disable();
                $('#acc-reading-toc').prop('checked', false);
            }).on('mouseenter', function() {
                $(this).css({
                    'background': 'rgba(255,255,255,0.3)',
                    'transform': 'rotate(90deg)'
                });
            }).on('mouseleave', function() {
                $(this).css({
                    'background': 'rgba(255,255,255,0.2)',
                    'transform': 'rotate(0deg)'
                });
            });

            // DRAG & DROP
            const $header = this.$toc.find('.acc-toc-header');
            
            $header.on('mousedown', (e) => {
                this.isDragging = true;
                this.dragOffset = {
                    x: e.clientX - this.$toc.offset().left,
                    y: e.clientY - this.$toc.offset().top
                };
                
                $header.css('cursor', 'grabbing');
                $('body').css('user-select', 'none');
                
                e.preventDefault();
            });

            $(document).on('mousemove.toc', (e) => {
                if (!this.isDragging) return;
                
                const newLeft = e.clientX - this.dragOffset.x;
                const newTop = e.clientY - this.dragOffset.y;
                
                // Limites de l'écran
                const maxLeft = $(window).width() - this.$toc.outerWidth();
                const maxTop = $(window).height() - this.$toc.outerHeight();
                
                this.$toc.css({
                    left: Math.max(0, Math.min(newLeft, maxLeft)) + 'px',
                    top: Math.max(0, Math.min(newTop, maxTop)) + 'px',
                    right: 'auto',
                    bottom: 'auto'
                });
            });

            $(document).on('mouseup.toc', () => {
                if (this.isDragging) {
                    this.isDragging = false;
                    $header.css('cursor', 'move');
                    $('body').css('user-select', '');
                }
            });
        }
    }

    /**
     * Feature: Mode focus
     */
    class FocusFeature {
        constructor() {
            this.enabled = false;
        }

        enable() {
            if (this.enabled) return;
            $('body').addClass('acc-focus-mode');
            this.enabled = true;
        }

        disable() {
            if (!this.enabled) return;
            $('body').removeClass('acc-focus-mode');
            this.enabled = false;
        }
    }

    /**
     * Initialisation
     */
    $(document).ready(function() {
        if ($('#acc-module-reading-guide').length) {
            window.accReadingGuide = new ReadingGuideModule();
            console.log('✓ Module Guide de Lecture initialisé (v1.3.0 - Sommaire intelligent)');
        }
    });

})(jQuery);