<?php
/**
 * Template du module Protection Épilepsie
 * Interface utilisateur pour la prévention des crises
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="acc-module acc-module-epilepsy" id="acc-module-epilepsy" data-module="epilepsy">
    <div class="acc-module-header">
        <h3 class="acc-module-title">
            <span class="acc-module-icon" aria-hidden="true">⚡</span>
            <?php esc_html_e('Protection Épilepsie', 'accessibility-modular'); ?>
        </h3>
        <label class="acc-module-toggle">
            <input 
                type="checkbox" 
                id="acc-epilepsy-toggle"
                aria-label="<?php esc_attr_e('Activer/désactiver la protection épilepsie', 'accessibility-modular'); ?>"
            />
            <span class="acc-module-toggle-slider"></span>
        </label>
    </div>

    <div class="acc-module-content" id="acc-epilepsy-content" style="display: none;">
        
        <!-- Avertissement de sécurité -->
        <div class="acc-safety-warning" style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 12px; margin-bottom: 20px; border-radius: 4px;">
            <p style="margin: 0; font-size: 13px; color: #856404;">
                <strong>⚠️ <?php esc_html_e('Important', 'accessibility-modular'); ?> :</strong>
                <?php esc_html_e('Ce module aide à réduire les risques de crises, mais ne les élimine pas complètement. En cas de sensibilité connue, consultez un médecin.', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Arrêter les animations -->
        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-epilepsy-stop-animations" 
                    class="acc-checkbox"
                    aria-describedby="acc-epilepsy-animations-desc"
                />
                <span><?php esc_html_e('Arrêter toutes les animations', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-epilepsy-animations-desc" class="acc-control-description">
                <?php esc_html_e('Désactive toutes les animations CSS et JavaScript', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Arrêter les GIFs -->
        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-epilepsy-stop-gifs" 
                    class="acc-checkbox"
                    aria-describedby="acc-epilepsy-gifs-desc"
                />
                <span><?php esc_html_e('Arrêter les GIFs animés', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-epilepsy-gifs-desc" class="acc-control-description">
                <?php esc_html_e('Fige les GIFs sur la première image', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Arrêter les vidéos -->
        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-epilepsy-stop-videos" 
                    class="acc-checkbox"
                    aria-describedby="acc-epilepsy-videos-desc"
                />
                <span><?php esc_html_e('Arrêter les vidéos automatiques', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-epilepsy-videos-desc" class="acc-control-description">
                <?php esc_html_e('Met en pause les vidéos en lecture automatique', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Supprimer les effets parallax -->
        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-epilepsy-remove-parallax" 
                    class="acc-checkbox"
                    aria-describedby="acc-epilepsy-parallax-desc"
                />
                <span><?php esc_html_e('Supprimer les effets parallax', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-epilepsy-parallax-desc" class="acc-control-description">
                <?php esc_html_e('Désactive les effets de défilement parallaxe', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Réduire tous les mouvements -->
        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-epilepsy-reduce-motion" 
                    class="acc-checkbox"
                    aria-describedby="acc-epilepsy-motion-desc"
                />
                <span><?php esc_html_e('Réduire tous les mouvements', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-epilepsy-motion-desc" class="acc-control-description">
                <?php esc_html_e('Active le mode réduction de mouvement globale', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Bloquer les flashs -->
        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-epilepsy-block-flashing" 
                    class="acc-checkbox"
                    aria-describedby="acc-epilepsy-flashing-desc"
                />
                <span><?php esc_html_e('Bloquer les flashs rapides', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-epilepsy-flashing-desc" class="acc-control-description">
                <?php esc_html_e('Détecte et bloque les changements rapides de luminosité', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Bouton d'activation rapide -->
        <div class="acc-control-group" style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd;">
            <button 
                type="button" 
                id="acc-epilepsy-activate-all" 
                class="acc-button acc-button-primary"
                style="width: 100%; background: #d32f2f; color: white; font-weight: bold;"
                aria-label="<?php esc_attr_e('Activer toutes les protections d\'urgence', 'accessibility-modular'); ?>"
            >
                <?php esc_html_e('🚨 ACTIVER TOUTES LES PROTECTIONS', 'accessibility-modular'); ?>
            </button>
            <p class="acc-control-description" style="text-align: center; margin-top: 10px;">
                <?php esc_html_e('Active instantanément toutes les protections pour une sécurité maximale', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Boutons d'action -->
        <div class="acc-control-group" style="margin-top: 15px;">
            <div class="acc-button-group">
                <button 
                    type="button" 
                    id="acc-epilepsy-reset" 
                    class="acc-button"
                    aria-label="<?php esc_attr_e('Réinitialiser les paramètres de protection épilepsie', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Réinitialiser', 'accessibility-modular'); ?>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.acc-checkbox-label {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-weight: 500;
}

.acc-checkbox {
    margin-right: 10px;
    width: 18px;
    height: 18px;
    cursor: pointer;
}

.acc-control-description {
    font-size: 12px;
    color: #666;
    margin: 5px 0 0 28px;
    line-height: 1.4;
}

.acc-button-primary {
    background: #d32f2f;
    border: none;
    padding: 12px 20px;
    cursor: pointer;
    border-radius: 4px;
    font-size: 14px;
    transition: background 0.2s;
}

.acc-button-primary:hover {
    background: #b71c1c;
}

.acc-safety-warning {
    animation: none !important;
}
</style>