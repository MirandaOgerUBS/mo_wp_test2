/**
 * Module Couleur des Boutons - JavaScript (VERSION AUTONOME)
 * Gestion de la personnalisation des couleurs des boutons
 * Version: 1.0.0
 * 
 * IMPORTANT: Utilise uniquement les cookies (pas localStorage)
 */

(function($) {
    'use strict';

    /**
     * Classe du module Couleur des Boutons
     */
    class ButtonColorModule {
        constructor() {
            this.module = $('#acc-module-button-color');
            this.toggle = $('#acc-button-color-toggle');
            this.content = $('#acc-button-color-content');
            this.presetButtons = $('.acc-color-preset');
            this.bgColorInput = $('#acc-button-bg-color');
            this.textColorInput = $('#acc-button-text-color');
            this.borderToggle = $('#acc-button-border');
            this.borderWidthSlider = $('#acc-button-border-width');
            this.resetBtn = $('#acc-button-color-reset');
            this.previewButton = $('.acc-button-color-preview');
            
            this.settings = this.getDefaultSettings();
            this.isActive = false;
            
            this.init();
        }

        /**
         * Initialisation
         */
        init() {
            this.loadSettings();
            this.bindEvents();
            this.updateUI();
            this.updatePreview();
            
            // Applique les paramètres sauvegardés
            if (this.isActive) {
                this.applyAllSettings();
            }
            
            console.log('✓ Module Couleur des Boutons initialisé', this.settings);
        }

        /**
         * Paramètres par défaut
         */
        getDefaultSettings() {
            return {
                preset: 'default',
                bgColor: '#0066CC',
                textColor: '#FFFFFF',
                borderEnabled: false,
                borderWidth: 2
            };
        }

        /**
         * Liaison des événements
         */
        bindEvents() {
            // Toggle du module
            this.toggle.on('change', () => this.handleToggle());
            
            // Presets
            this.presetButtons.on('click', (e) => this.handlePresetClick(e));
            
            // Couleurs personnalisées
            this.bgColorInput.on('input change', () => this.handleBgColorChange());
            this.textColorInput.on('input change', () => this.handleTextColorChange());
            
            // Bordure
            this.borderToggle.on('change', () => this.handleBorderToggle());
            this.borderWidthSlider.on('input', () => this.handleBorderWidthChange());
            
            // Réinitialisation
            this.resetBtn.on('click', () => this.reset());
        }

        /**
         * Gère l'activation/désactivation du module
         */
        handleToggle() {
            this.isActive = this.toggle.is(':checked');
            
            if (this.isActive) {
                this.content.slideDown(300);
                this.applyAllSettings();
                this.savePreference('active', true);
                this.announce('Module couleur des boutons activé');
                console.log('✓ Module couleur des boutons activé');
            } else {
                this.content.slideUp(300);
                this.removeAllSettings();
                this.savePreference('active', false);
                this.announce('Module couleur des boutons désactivé');
                console.log('✓ Module couleur des boutons désactivé');
            }
        }

        /**
         * Gère le clic sur un preset
         */
        handlePresetClick(e) {
            const $button = $(e.currentTarget);
            const preset = $button.data('preset');
            const bgColor = $button.data('bg');
            const textColor = $button.data('text');
            
            this.settings.preset = preset;
            this.settings.bgColor = bgColor === 'inherit' ? 'inherit' : bgColor;
            this.settings.textColor = textColor === 'inherit' ? 'inherit' : textColor;
            
            // Mettre à jour les color pickers
            if (bgColor !== 'inherit') {
                this.bgColorInput.val(bgColor);
                $('#acc-button-bg-value').text(bgColor);
            }
            if (textColor !== 'inherit') {
                this.textColorInput.val(textColor);
                $('#acc-button-text-value').text(textColor);
            }
            
            this.presetButtons.removeClass('active');
            $button.addClass('active');
            
            this.applyColors();
            this.updatePreview();
            this.updateContrastRatio();
            this.savePreference('preset', preset);
            this.savePreference('bgColor', this.settings.bgColor);
            this.savePreference('textColor', this.settings.textColor);
            
            this.announce(`Thème ${preset} appliqué`);
            console.log(`Preset appliqué: ${preset}`);
        }

        /**
         * Gère le changement de couleur de fond
         */
        handleBgColorChange() {
            this.settings.bgColor = this.bgColorInput.val();
            this.settings.preset = 'custom';
            
            $('#acc-button-bg-value').text(this.settings.bgColor);
            this.presetButtons.removeClass('active');
            
            this.applyColors();
            this.updatePreview();
            this.updateContrastRatio();
            this.savePreference('bgColor', this.settings.bgColor);
            this.savePreference('preset', 'custom');
            
            console.log(`Couleur de fond: ${this.settings.bgColor}`);
        }

        /**
         * Gère le changement de couleur de texte
         */
        handleTextColorChange() {
            this.settings.textColor = this.textColorInput.val();
            this.settings.preset = 'custom';
            
            $('#acc-button-text-value').text(this.settings.textColor);
            this.presetButtons.removeClass('active');
            
            this.applyColors();
            this.updatePreview();
            this.updateContrastRatio();
            this.savePreference('textColor', this.settings.textColor);
            this.savePreference('preset', 'custom');
            
            console.log(`Couleur de texte: ${this.settings.textColor}`);
        }

        /**
         * Gère l'activation/désactivation de la bordure
         */
        handleBorderToggle() {
            this.settings.borderEnabled = this.borderToggle.is(':checked');
            
            if (this.settings.borderEnabled) {
                $('#acc-border-options').slideDown(200);
            } else {
                $('#acc-border-options').slideUp(200);
            }
            
            this.applyBorder();
            this.updatePreview();
            this.savePreference('borderEnabled', this.settings.borderEnabled);
            
            console.log(`Bordure: ${this.settings.borderEnabled}`);
        }

        /**
         * Gère le changement d'épaisseur de bordure
         */
        handleBorderWidthChange() {
            this.settings.borderWidth = parseInt(this.borderWidthSlider.val());
            
            $('#acc-button-border-width-value').text(this.settings.borderWidth + 'px');
            this.borderWidthSlider.attr('aria-valuenow', this.settings.borderWidth);
            
            this.applyBorder();
            this.updatePreview();
            this.savePreference('borderWidth', this.settings.borderWidth);
            
            console.log(`Épaisseur bordure: ${this.settings.borderWidth}px`);
        }

        /**
         * Applique tous les paramètres
         */
        applyAllSettings() {
            this.applyColors();
            this.applyBorder();
            console.log('✓ Tous les paramètres appliqués', this.settings);
        }

        /**
         * Applique les couleurs
         */
        applyColors() {
            // Supprimer l'ancien style
            $('#acc-button-color-style').remove();
            
            if (this.settings.preset === 'default') {
                console.log('✓ Couleurs par défaut (aucun style appliqué)');
                return;
            }
            
            const css = `
                button:not(.acc-widget button):not(.acc-widget *):not(.acc-color-preset):not(.acc-button-color-preview),
                input[type="button"]:not(.acc-widget input),
                input[type="submit"]:not(.acc-widget input),
                input[type="reset"]:not(.acc-widget input),
                a.button:not(.acc-widget a),
                a.btn:not(.acc-widget a),
                [role="button"]:not(.acc-widget [role="button"]),
                .wp-block-button__link,
                .wp-block-button a {
                    background-color: ${this.settings.bgColor} !important;
                    color: ${this.settings.textColor} !important;
                }
                
                button:not(.acc-widget button):not(.acc-widget *):not(.acc-color-preset):not(.acc-button-color-preview):hover,
                input[type="button"]:not(.acc-widget input):hover,
                input[type="submit"]:not(.acc-widget input):hover,
                input[type="reset"]:not(.acc-widget input):hover,
                a.button:not(.acc-widget a):hover,
                a.btn:not(.acc-widget a):hover,
                [role="button"]:not(.acc-widget [role="button"]):hover {
                    filter: brightness(1.1) !important;
                }
            `;
            
            $('<style>', {
                id: 'acc-button-color-style',
                html: css
            }).appendTo('head');
            
            console.log(`✓ Couleurs appliquées: BG=${this.settings.bgColor}, Text=${this.settings.textColor}`);
        }

        /**
         * Applique la bordure
         */
        applyBorder() {
            // Supprimer l'ancien style
            $('#acc-button-border-style').remove();
            
            if (!this.settings.borderEnabled) {
                return;
            }
            
            const css = `
                button:not(.acc-widget button):not(.acc-widget *):not(.acc-color-preset):not(.acc-button-color-preview),
                input[type="button"]:not(.acc-widget input),
                input[type="submit"]:not(.acc-widget input),
                input[type="reset"]:not(.acc-widget input),
                a.button:not(.acc-widget a),
                a.btn:not(.acc-widget a),
                [role="button"]:not(.acc-widget [role="button"]),
                .wp-block-button__link,
                .wp-block-button a {
                    border: ${this.settings.borderWidth}px solid ${this.settings.textColor} !important;
                }
            `;
            
            $('<style>', {
                id: 'acc-button-border-style',
                html: css
            }).appendTo('head');
            
            console.log(`✓ Bordure appliquée: ${this.settings.borderWidth}px`);
        }

        /**
         * Supprime tous les paramètres
         */
        removeAllSettings() {
            $('#acc-button-color-style').remove();
            $('#acc-button-border-style').remove();
            this.updatePreview();
            console.log('✓ Tous les styles supprimés');
        }

        /**
         * Met à jour l'aperçu
         */
        updatePreview() {
            if (this.isActive && this.settings.preset !== 'default') {
                this.previewButton.css({
                    'background-color': this.settings.bgColor,
                    'color': this.settings.textColor,
                    'border': this.settings.borderEnabled 
                        ? `${this.settings.borderWidth}px solid ${this.settings.textColor}` 
                        : '2px solid transparent'
                });
            } else {
                this.previewButton.css({
                    'background-color': '',
                    'color': '',
                    'border': ''
                });
            }
        }

        /**
         * Calcule et affiche le ratio de contraste
         */
        updateContrastRatio() {
            if (this.settings.preset === 'default') {
                $('#acc-contrast-ratio').text('-');
                $('#acc-contrast-level').text('');
                return;
            }
            
            const ratio = this.calculateContrastRatio(this.settings.bgColor, this.settings.textColor);
            const level = this.getContrastLevel(ratio);
            
            $('#acc-contrast-ratio').text(ratio.toFixed(2) + ':1');
            $('#acc-contrast-level').html(level.html);
            
            console.log(`Ratio de contraste: ${ratio.toFixed(2)}:1 (${level.text})`);
        }

        /**
         * Calcule le ratio de contraste WCAG
         */
        calculateContrastRatio(color1, color2) {
            const lum1 = this.getLuminance(color1);
            const lum2 = this.getLuminance(color2);
            
            const lighter = Math.max(lum1, lum2);
            const darker = Math.min(lum1, lum2);
            
            return (lighter + 0.05) / (darker + 0.05);
        }

        /**
         * Calcule la luminance relative d'une couleur
         */
        getLuminance(hex) {
            // Convertir hex en RGB
            const rgb = this.hexToRgb(hex);
            
            // Convertir en valeurs sRGB
            const rsRGB = rgb.r / 255;
            const gsRGB = rgb.g / 255;
            const bsRGB = rgb.b / 255;
            
            // Appliquer la transformation gamma
            const r = rsRGB <= 0.03928 ? rsRGB / 12.92 : Math.pow((rsRGB + 0.055) / 1.055, 2.4);
            const g = gsRGB <= 0.03928 ? gsRGB / 12.92 : Math.pow((gsRGB + 0.055) / 1.055, 2.4);
            const b = bsRGB <= 0.03928 ? bsRGB / 12.92 : Math.pow((bsRGB + 0.055) / 1.055, 2.4);
            
            // Calculer la luminance
            return 0.2126 * r + 0.7152 * g + 0.0722 * b;
        }

        /**
         * Convertit hex en RGB
         */
        hexToRgb(hex) {
            const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
            return result ? {
                r: parseInt(result[1], 16),
                g: parseInt(result[2], 16),
                b: parseInt(result[3], 16)
            } : { r: 0, g: 0, b: 0 };
        }

        /**
         * Détermine le niveau de conformité WCAG
         */
        getContrastLevel(ratio) {
            if (ratio >= 7) {
                return {
                    text: 'AAA (Excellent)',
                    html: '✅ <strong style="color: #2D8A3E;">AAA</strong> - Excellent contraste'
                };
            } else if (ratio >= 4.5) {
                return {
                    text: 'AA (Bon)',
                    html: '✅ <strong style="color: #0066CC;">AA</strong> - Bon contraste'
                };
            } else if (ratio >= 3) {
                return {
                    text: 'AA Large (Acceptable)',
                    html: '⚠️ <strong style="color: #E67700;">AA Large</strong> - Acceptable pour texte large uniquement'
                };
            } else {
                return {
                    text: 'Insuffisant',
                    html: '❌ <strong style="color: #D32F2F;">Insuffisant</strong> - Contraste trop faible'
                };
            }
        }

        /**
         * Réinitialise tous les paramètres
         */
        reset() {
            if (confirm('Réinitialiser tous les paramètres de couleur des boutons ?')) {
                this.settings = this.getDefaultSettings();
                this.updateUI();
                this.applyAllSettings();
                this.updatePreview();
                this.updateContrastRatio();
                this.saveAllSettings();
                this.announce('Paramètres de couleur des boutons réinitialisés');
                console.log('✓ Paramètres réinitialisés');
            }
        }

        /**
         * Met à jour l'interface
         */
        updateUI() {
            // Color pickers
            if (this.settings.bgColor !== 'inherit') {
                this.bgColorInput.val(this.settings.bgColor);
                $('#acc-button-bg-value').text(this.settings.bgColor);
            }
            if (this.settings.textColor !== 'inherit') {
                this.textColorInput.val(this.settings.textColor);
                $('#acc-button-text-value').text(this.settings.textColor);
            }
            
            // Bordure
            this.borderToggle.prop('checked', this.settings.borderEnabled);
            this.borderWidthSlider.val(this.settings.borderWidth);
            $('#acc-button-border-width-value').text(this.settings.borderWidth + 'px');
            
            if (this.settings.borderEnabled) {
                $('#acc-border-options').show();
            } else {
                $('#acc-border-options').hide();
            }
            
            // Preset actif
            this.presetButtons.removeClass('active');
            if (this.settings.preset !== 'custom') {
                this.presetButtons.filter(`[data-preset="${this.settings.preset}"]`)
                                 .addClass('active');
            }
            
            this.updateContrastRatio();
        }

        /**
         * Sauvegarde une préférence dans un cookie
         */
        savePreference(key, value) {
            const cookieName = `acc_button_color_${key}`;
            const cookieValue = JSON.stringify(value);
            const expiryDays = 365;
            const date = new Date();
            date.setTime(date.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
            const expires = "expires=" + date.toUTCString();
            
            document.cookie = `${cookieName}=${cookieValue};${expires};path=/;SameSite=Lax`;
        }

        /**
         * Récupère une préférence depuis un cookie
         */
        getPreference(key, defaultValue) {
            const cookieName = `acc_button_color_${key}`;
            const name = cookieName + "=";
            const decodedCookie = decodeURIComponent(document.cookie);
            const cookieArray = decodedCookie.split(';');
            
            for (let i = 0; i < cookieArray.length; i++) {
                let cookie = cookieArray[i].trim();
                if (cookie.indexOf(name) === 0) {
                    const value = cookie.substring(name.length, cookie.length);
                    try {
                        return JSON.parse(value);
                    } catch(e) {
                        return value;
                    }
                }
            }
            
            return defaultValue;
        }

        /**
         * Charge les paramètres sauvegardés
         */
        loadSettings() {
            this.isActive = this.getPreference('active', false);
            this.settings.preset = this.getPreference('preset', 'default');
            this.settings.bgColor = this.getPreference('bgColor', '#0066CC');
            this.settings.textColor = this.getPreference('textColor', '#FFFFFF');
            this.settings.borderEnabled = this.getPreference('borderEnabled', false);
            this.settings.borderWidth = this.getPreference('borderWidth', 2);
            
            this.toggle.prop('checked', this.isActive);
            if (this.isActive) {
                this.content.show();
            }
            
            console.log('✓ Paramètres chargés:', this.settings);
        }

        /**
         * Sauvegarde tous les paramètres
         */
        saveAllSettings() {
            this.savePreference('active', this.isActive);
            this.savePreference('preset', this.settings.preset);
            this.savePreference('bgColor', this.settings.bgColor);
            this.savePreference('textColor', this.settings.textColor);
            this.savePreference('borderEnabled', this.settings.borderEnabled);
            this.savePreference('borderWidth', this.settings.borderWidth);
        }

        /**
         * Annonce pour les lecteurs d'écran
         */
        announce(message) {
            let $announcer = $('#acc-screen-reader-announcer');
            if (!$announcer.length) {
                $announcer = $('<div>', {
                    id: 'acc-screen-reader-announcer',
                    'aria-live': 'polite',
                    'aria-atomic': 'true',
                    css: {
                        position: 'absolute',
                        left: '-10000px',
                        width: '1px',
                        height: '1px',
                        overflow: 'hidden'
                    }
                }).appendTo('body');
            }
            
            $announcer.text('');
            setTimeout(() => {
                $announcer.text(message);
            }, 100);
        }
    }

    /**
     * Initialisation
     */
    $(document).ready(function() {
        if ($('#acc-module-button-color').length) {
            window.accButtonColorModule = new ButtonColorModule();
            console.log('✓ Module Couleur des Boutons prêt');
        }
    });

})(jQuery);