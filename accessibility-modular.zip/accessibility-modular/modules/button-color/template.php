<?php
/**
 * Template du module Couleur des Boutons
 * Interface utilisateur pour la personnalisation des couleurs des boutons
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="acc-module acc-module-button-color" id="acc-module-button-color" data-module="button-color">
    <div class="acc-module-header">
        <h3 class="acc-module-title">
            <span class="acc-module-icon" aria-hidden="true">🎨</span>
            <?php esc_html_e('Couleur des boutons', 'accessibility-modular'); ?>
        </h3>
        <label class="acc-module-toggle">
            <input 
                type="checkbox" 
                id="acc-button-color-toggle"
                aria-label="<?php esc_attr_e('Activer/désactiver le module couleur des boutons', 'accessibility-modular'); ?>"
            />
            <span class="acc-module-toggle-slider"></span>
        </label>
    </div>

    <div class="acc-module-content" id="acc-button-color-content" style="display: none;">
        
        <!-- Thèmes prédéfinis -->
        <div class="acc-control-group">
            <label class="acc-control-label">
                <?php esc_html_e('Thème prédéfini', 'accessibility-modular'); ?>
            </label>
            
            <!-- Grille de couleurs -->
            <div class="acc-color-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 10px;">
                
                <!-- Par défaut -->
                <button 
                    type="button" 
                    class="acc-color-preset active" 
                    data-preset="default"
                    data-bg="inherit"
                    data-text="inherit"
                    style="padding: 12px; border: 2px solid #ddd; border-radius: 8px; cursor: pointer; background: linear-gradient(135deg, #f0f0f0 0%, #e0e0e0 100%); transition: all 0.2s;"
                    aria-label="<?php esc_attr_e('Thème par défaut', 'accessibility-modular'); ?>"
                >
                    <div style="font-size: 11px; font-weight: 600; color: #333;">
                        <?php esc_html_e('Défaut', 'accessibility-modular'); ?>
                    </div>
                </button>

                <!-- Contraste élevé -->
                <button 
                    type="button" 
                    class="acc-color-preset" 
                    data-preset="high-contrast"
                    data-bg="#000000"
                    data-text="#FFFFFF"
                    style="padding: 12px; border: 2px solid #ddd; border-radius: 8px; cursor: pointer; background: #000000; transition: all 0.2s;"
                    aria-label="<?php esc_attr_e('Contraste élevé - Noir sur blanc', 'accessibility-modular'); ?>"
                >
                    <div style="font-size: 11px; font-weight: 600; color: #FFFFFF;">
                        <?php esc_html_e('Contraste', 'accessibility-modular'); ?>
                    </div>
                </button>

                <!-- Bleu -->
                <button 
                    type="button" 
                    class="acc-color-preset" 
                    data-preset="blue"
                    data-bg="#0066CC"
                    data-text="#FFFFFF"
                    style="padding: 12px; border: 2px solid #ddd; border-radius: 8px; cursor: pointer; background: #0066CC; transition: all 0.2s;"
                    aria-label="<?php esc_attr_e('Thème bleu', 'accessibility-modular'); ?>"
                >
                    <div style="font-size: 11px; font-weight: 600; color: #FFFFFF;">
                        <?php esc_html_e('Bleu', 'accessibility-modular'); ?>
                    </div>
                </button>

                <!-- Vert -->
                <button 
                    type="button" 
                    class="acc-color-preset" 
                    data-preset="green"
                    data-bg="#2D8A3E"
                    data-text="#FFFFFF"
                    style="padding: 12px; border: 2px solid #ddd; border-radius: 8px; cursor: pointer; background: #2D8A3E; transition: all 0.2s;"
                    aria-label="<?php esc_attr_e('Thème vert', 'accessibility-modular'); ?>"
                >
                    <div style="font-size: 11px; font-weight: 600; color: #FFFFFF;">
                        <?php esc_html_e('Vert', 'accessibility-modular'); ?>
                    </div>
                </button>

                <!-- Orange -->
                <button 
                    type="button" 
                    class="acc-color-preset" 
                    data-preset="orange"
                    data-bg="#E67700"
                    data-text="#FFFFFF"
                    style="padding: 12px; border: 2px solid #ddd; border-radius: 8px; cursor: pointer; background: #E67700; transition: all 0.2s;"
                    aria-label="<?php esc_attr_e('Thème orange', 'accessibility-modular'); ?>"
                >
                    <div style="font-size: 11px; font-weight: 600; color: #FFFFFF;">
                        <?php esc_html_e('Orange', 'accessibility-modular'); ?>
                    </div>
                </button>

                <!-- Violet -->
                <button 
                    type="button" 
                    class="acc-color-preset" 
                    data-preset="purple"
                    data-bg="#7C3AED"
                    data-text="#FFFFFF"
                    style="padding: 12px; border: 2px solid #ddd; border-radius: 8px; cursor: pointer; background: #7C3AED; transition: all 0.2s;"
                    aria-label="<?php esc_attr_e('Thème violet', 'accessibility-modular'); ?>"
                >
                    <div style="font-size: 11px; font-weight: 600; color: #FFFFFF;">
                        <?php esc_html_e('Violet', 'accessibility-modular'); ?>
                    </div>
                </button>

            </div>
        </div>

        <!-- Couleurs personnalisées -->
        <div class="acc-control-group" style="margin-top: 20px;">
            <label class="acc-control-label">
                <?php esc_html_e('Couleurs personnalisées', 'accessibility-modular'); ?>
            </label>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 10px;">
                
                <!-- Couleur de fond -->
                <div>
                    <label for="acc-button-bg-color" style="display: block; font-size: 12px; margin-bottom: 5px; color: var(--acc-text-muted);">
                        <?php esc_html_e('Fond', 'accessibility-modular'); ?>
                    </label>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <input 
                            type="color" 
                            id="acc-button-bg-color"
                            value="#0066CC"
                            style="width: 50px; height: 40px; border: 2px solid var(--acc-border); border-radius: 6px; cursor: pointer;"
                            aria-label="<?php esc_attr_e('Couleur de fond des boutons', 'accessibility-modular'); ?>"
                        />
                        <span id="acc-button-bg-value" style="font-size: 11px; color: var(--acc-text-muted); font-family: monospace;">#0066CC</span>
                    </div>
                </div>

                <!-- Couleur du texte -->
                <div>
                    <label for="acc-button-text-color" style="display: block; font-size: 12px; margin-bottom: 5px; color: var(--acc-text-muted);">
                        <?php esc_html_e('Texte', 'accessibility-modular'); ?>
                    </label>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <input 
                            type="color" 
                            id="acc-button-text-color"
                            value="#FFFFFF"
                            style="width: 50px; height: 40px; border: 2px solid var(--acc-border); border-radius: 6px; cursor: pointer;"
                            aria-label="<?php esc_attr_e('Couleur du texte des boutons', 'accessibility-modular'); ?>"
                        />
                        <span id="acc-button-text-value" style="font-size: 11px; color: var(--acc-text-muted); font-family: monospace;">#FFFFFF</span>
                    </div>
                </div>

            </div>

            <!-- Indicateur de contraste -->
            <div id="acc-contrast-indicator" style="margin-top: 12px; padding: 10px; background: var(--acc-surface); border-radius: 6px; font-size: 12px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span><?php esc_html_e('Ratio de contraste :', 'accessibility-modular'); ?></span>
                    <span id="acc-contrast-ratio" style="font-weight: 600; font-family: monospace;">-</span>
                </div>
                <div id="acc-contrast-level" style="margin-top: 5px; font-size: 11px; color: var(--acc-text-muted);"></div>
            </div>
        </div>

        <!-- Bordure -->
        <div class="acc-control-group">
            <div class="acc-feature-item" style="display: flex; justify-content: space-between; align-items: center;">
                <label for="acc-button-border" class="acc-control-label">
                    <?php esc_html_e('Bordure visible', 'accessibility-modular'); ?>
                </label>
                <label class="acc-module-toggle">
                    <input 
                        type="checkbox" 
                        id="acc-button-border"
                        aria-label="<?php esc_attr_e('Activer la bordure des boutons', 'accessibility-modular'); ?>"
                    />
                    <span class="acc-module-toggle-slider"></span>
                </label>
            </div>

            <div id="acc-border-options" style="display: none; margin-top: 12px;">
                <label for="acc-button-border-width" class="acc-control-label">
                    <?php esc_html_e('Épaisseur', 'accessibility-modular'); ?>
                    <span class="acc-control-value" id="acc-button-border-width-value">2px</span>
                </label>
                <input 
                    type="range" 
                    id="acc-button-border-width" 
                    class="acc-slider"
                    min="1" 
                    max="5" 
                    step="1" 
                    value="2"
                    aria-label="<?php esc_attr_e('Épaisseur de la bordure', 'accessibility-modular'); ?>"
                />
            </div>
        </div>

        <!-- Aperçu -->
        <div class="acc-control-group" style="background: var(--acc-surface); padding: 16px; border-radius: 8px; margin-top: 16px;">
            <label class="acc-control-label" style="margin-bottom: 12px;">
                <?php esc_html_e('Aperçu', 'accessibility-modular'); ?>
            </label>
            <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
                <button 
                    type="button" 
                    class="acc-button-color-preview" 
                    style="padding: 10px 20px; border: 2px solid transparent; border-radius: 6px; cursor: pointer; font-weight: 600; transition: all 0.2s;"
                >
                    <?php esc_html_e('Aperçu', 'accessibility-modular'); ?>
                </button>
            </div>
        </div>

        <!-- Bouton de réinitialisation -->
        <div class="acc-control-group" style="margin-top: 20px;">
            <div class="acc-button-group">
                <button 
                    type="button" 
                    id="acc-button-color-reset" 
                    class="acc-button"
                    aria-label="<?php esc_attr_e('Réinitialiser les paramètres de couleur des boutons', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Réinitialiser', 'accessibility-modular'); ?>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.acc-color-preset {
    position: relative;
}

.acc-color-preset:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.acc-color-preset.active {
    border-color: var(--acc-primary) !important;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2);
}

.acc-color-preset.active::after {
    content: '✓';
    position: absolute;
    top: -8px;
    right: -8px;
    width: 24px;
    height: 24px;
    background: var(--acc-primary);
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    font-weight: bold;
}
</style>