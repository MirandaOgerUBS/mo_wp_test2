<?php
/**
 * Module: Couleur des Boutons
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Classe du module Couleur des Boutons
 */
class ACC_Button_Color_Module {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Le module est enregistré, pas besoin de hooks ici
        // Les assets sont chargés par le plugin principal
    }
    
    /**
     * Retourne les informations du module
     */
    public static function get_info() {
        return [
            'name' => 'button-color',
            'title' => 'Couleur des boutons',
            'description' => 'Personnalisez les couleurs des boutons pour améliorer leur visibilité',
            'version' => '1.0.0',
            'icon' => '🎨',
            'category' => 'mobilite',
            'enabled' => true
        ];
    }
    
    /**
     * Rendu du template
     */
    public static function render() {
        include dirname(__FILE__) . '/template.php';
    }
}

// Initialiser le module
ACC_Button_Color_Module::get_instance();