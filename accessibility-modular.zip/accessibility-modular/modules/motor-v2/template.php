<?php
/**
 * Template du Module Moteur V2
 * Interface utilisateur reconstruite pour la stabilité.
 */
if (!defined('ABSPATH')) exit;
?>

<div class="acc-module acc-module-motor" id="acc-motor-v2-module">
    <div class="acc-module-header">
        <h3 class="acc-module-title">
            <span class="acc-module-icon" aria-hidden="true">🖱️</span>
            <?php esc_html_e('Contrôle Moteur', 'accessibility-modular'); ?>
        </h3>
        <label class="acc-module-toggle">
            <input type="checkbox" data-setting="master_toggle" aria-label="<?php esc_attr_e('Activer/désactiver le contrôle moteur', 'accessibility-modular'); ?>"/>
            <span class="acc-module-toggle-slider"></span>
        </label>
    </div>

    <div class="acc-module-content" style="display: none;">
        <div class="acc-info-box">
            <p><strong><?php esc_html_e('Pour qui ?', 'accessibility-modular'); ?></strong><br>
            <?php esc_html_e('Aide à la navigation pour les troubles moteurs (tremblements, Parkinson, SEP...).', 'accessibility-modular'); ?></p>
        </div>

        <?php
        $motor_controls = [
            'click_areas' => ['type' => 'range', 'label' => __('Zones de clic élargies', 'accessibility-modular'), 'min' => 0, 'max' => 25, 'step' => 5, 'unit' => 'px'],
            'disable_hover' => ['type' => 'checkbox', 'label' => __('Désactiver le survol', 'accessibility-modular')],
            'click_delay' => ['type' => 'range', 'label' => __('Délai d\'activation', 'accessibility-modular'), 'min' => 0, 'max' => 1500, 'step' => 100, 'unit' => 'ms'],
            'prevent_double_click' => ['type' => 'checkbox', 'label' => __('Prévenir les double-clics', 'accessibility-modular')],
            'cursor_size' => ['type' => 'range', 'label' => __('Taille du curseur', 'accessibility-modular'), 'min' => 1, 'max' => 4, 'step' => 0.5, 'unit' => 'x'],
            'cursor_highlight' => ['type' => 'checkbox', 'label' => __('Surbrillance du curseur', 'accessibility-modular')],
            'disable_drag' => ['type' => 'checkbox', 'label' => __('Désactiver le glisser-déposer', 'accessibility-modular')],
            'focus_highlight' => ['type' => 'checkbox', 'label' => __('Focus visible renforcé', 'accessibility-modular')]
        ];

        foreach ($motor_controls as $id => $control) : ?>
            <div class="acc-control-group">
                <?php if ($control['type'] === 'range') : ?>
                    <label class="acc-control-label">
                        <?php echo esc_html($control['label']); ?>
                        <span class="acc-control-value" data-unit="<?php echo esc_attr($control['unit']); ?>"></span>
                    </label>
                    <input type="range" class="acc-slider" data-setting="<?php echo esc_attr($id); ?>" min="<?php echo esc_attr($control['min']); ?>" max="<?php echo esc_attr($control['max']); ?>" step="<?php echo esc_attr($control['step']); ?>" />
                <?php else : ?>
                    <label class="acc-control-label acc-checkbox-label">
                        <input type="checkbox" class="acc-checkbox" data-setting="<?php echo esc_attr($id); ?>" />
                        <span><?php echo esc_html($control['label']); ?></span>
                    </label>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        
        <div class="acc-control-group" style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #eee;">
            <button type="button" class="acc-button acc-motor-reset-button">
                <?php esc_html_e('Réinitialiser', 'accessibility-modular'); ?>
            </button>
        </div>
    </div>
</div>