# Module Contrôle Moteur V2

Version stable et reconstruite pour aider les utilisateurs souffrant de troubles moteurs.

## Fonctionnalités

Ce module offre 8 réglages directs pour améliorer la navigation :

1.  **Zones de clic élargies** : Augmente la taille de la zone cliquable de tous les liens et boutons.
2.  **Désactiver le survol** : Empêche les menus de s'ouvrir accidentellement au passage de la souris.
3.  **Délai d'activation** : Ajoute un temps d'attente avant qu'un clic soit validé pour éviter les actions involontaires.
4.  **Prévenir les double-clics** : Ignore les clics multiples et rapides sur une même cible.
5.  **Taille du curseur** : Agrandit le curseur de la souris pour une meilleure visibilité.
6.  **Surbrillance du curseur** : Ajoute un cercle de couleur autour du curseur pour le repérer facilement.
7.  **Désactiver le glisser-déposer** : Bloque le "drag and drop" pour éviter de déplacer des éléments par erreur.
8.  **Focus visible renforcé** : Ajoute un cadre très visible autour de l'élément sélectionné avec le clavier.

## Installation

1.  Placer ce dossier (`motor-v2`) dans le répertoire `modules/` de votre plugin.
2.  Activer le module depuis le panneau d'administration.

Ce module est conçu pour être autonome et ne devrait causer aucun conflit.