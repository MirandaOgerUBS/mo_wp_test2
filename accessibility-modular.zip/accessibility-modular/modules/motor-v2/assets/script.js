/**
 * Module Moteur V2 - Script Reconstruit
 * Architecture stable et isolée pour éviter les conflits.
 */
(function($) {
    'use strict';

    class MotorModuleV2 {
        constructor() {
            this.module = $('#acc-motor-v2-module');
            if (!this.module.length) return;

            this.defaults = {
                master_toggle: false, click_areas: 0, disable_hover: false,
                click_delay: 0, prevent_double_click: false, cursor_size: 1,
                cursor_highlight: false, disable_drag: false, focus_highlight: false
            };
            this.settings = { ...this.defaults };
            this.lastClick = { time: 0, target: null };

            this.init();
        }

        init() {
            this.loadSettings();
            this.bindEvents();
            this.applyAllEffects();
            console.log('✓ Module Moteur V2 (Stable) initialisé.');
        }

        bindEvents() {
            // Isole le module : aucun événement interne ne peut déclencher les règles globales.
            this.module.on('click change input', e => e.stopPropagation());

            // Gère tous les changements de réglages (checkbox, sliders)
            this.module.on('change input', '[data-setting]', e => {
                const setting = $(e.target).data('setting');
                const value = e.target.type === 'checkbox' ? e.target.checked : parseFloat(e.target.value);
                this.updateSetting(setting, value);
            });

            // Bouton Réinitialiser
            this.module.find('.acc-motor-reset-button').on('click', () => {
                if (confirm('Réinitialiser tous les réglages du module moteur ?')) {
                    this.settings = { ...this.defaults, master_toggle: this.settings.master_toggle };
                    this.updateUI();
                    this.applyAllEffects();
                    this.saveAllSettings();
                }
            });

            // Listeners globaux (appliqués à tout le document)
            $(document)
                .off('.motorV2')
                .on('click.motorV2', this.handleGlobalClick.bind(this))
                .on('mousemove.motorV2', this.handleGlobalMouseMove.bind(this));
        }
        
        updateSetting(setting, value) {
            this.settings[setting] = value;
            
            if (setting === 'master_toggle') {
                this.module.find('.acc-module-content').slideToggle(value);
            }
            
            this.updateUI();
            this.applyAllEffects();
            this.saveAllSettings();
        }
        
        handleGlobalClick(e) {
            if (!this.settings.master_toggle) return;

            // Logique de prévention du double-clic
            if (this.settings.prevent_double_click) {
                const now = Date.now();
                if (e.target === this.lastClick.target && (now - this.lastClick.time) < 500) {
                    e.preventDefault(); e.stopPropagation(); return;
                }
                this.lastClick = { time: now, target: e.target };
            }

            // Logique du délai de clic
            if (this.settings.click_delay > 0 && $(e.target).closest('a, button').length) {
                const target = $(e.target).closest('a, button');
                if (target.data('motor-delayed')) return;
                
                e.preventDefault(); e.stopPropagation();
                target.data('motor-delayed', true).css('filter', 'brightness(80%)');
                
                setTimeout(() => {
                    target.removeData('motor-delayed').css('filter', '');
                    e.target.click();
                }, this.settings.click_delay);
            }
        }
        
        handleGlobalMouseMove(e) {
             if (this.settings.master_toggle && this.settings.cursor_highlight) {
                const highlighter = $('#acc-motor-highlighter');
                if (highlighter.length) {
                    highlighter.css({ top: e.clientY, left: e.clientX });
                }
            }
        }

        applyAllEffects() {
            $('#acc-motor-v2-styles, #acc-motor-highlighter').remove();
            
            if (!this.settings.master_toggle) return;

            let css = '';
            const s = this.settings;

            if (s.click_areas > 0) css += `body :where(a, button):not(#acc-motor-v2-module *) { padding: ${s.click_areas}px !important; }`;
            if (s.disable_hover) css += `body :where([class*="nav"], [class*="menu"]):hover > ul { display: none !important; }`;
            if (s.cursor_size > 1) {
                const size = 24 * s.cursor_size;
                css += `body :not(#acc-motor-v2-module *) { cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24"><path fill="black" stroke="white" stroke-width="1.5" d="M3 3L21 12L3 21V3Z"/></svg>') ${size/4} 0, auto !important; }`;
            }
            if (s.cursor_highlight) {
                $('<div>', { id: 'acc-motor-highlighter' }).appendTo('body');
                css += `#acc-motor-highlighter { position: fixed; width: 30px; height: 30px; border: 2px solid #FFC107; border-radius: 50%; transform: translate(-50%, -50%); pointer-events: none; z-index: 9999; }`;
            }
            if (s.disable_drag) css += `body :not(input, textarea, #acc-motor-v2-module *) { user-select: none !important; -webkit-user-drag: none !important; }`;
            if (s.focus_highlight) css += `body :where(a, button, input, [tabindex]):focus { outline: 3px solid #0d6efd !important; outline-offset: 2px; }`;
            
            if (css) $('<style>', { id: 'acc-motor-v2-styles', html: css }).appendTo('head');
        }

        updateUI() {
            this.module.find('[data-setting]').each((i, el) => {
                const setting = $(el).data('setting');
                const value = this.settings[setting];

                if (el.type === 'checkbox') {
                    el.checked = value;
                } else if (el.type === 'range') {
                    el.value = value;
                    const unit = $(el).siblings('label').find('.acc-control-value').data('unit') || '';
                    $(el).siblings('label').find('.acc-control-value').text(`: ${value}${unit}`);
                }
            });
        }

        loadSettings() {
            for (const key in this.defaults) {
                this.settings[key] = this.getCookie(`motor_v2_${key}`, this.defaults[key]);
            }
            this.module.find('.acc-module-content').toggle(this.settings.master_toggle);
            this.updateUI();
        }

        saveAllSettings() {
            for (const key in this.settings) {
                this.saveCookie(`motor_v2_${key}`, this.settings[key]);
            }
        }
        
        saveCookie(name, value) {
            document.cookie = `acc_${name}=${JSON.stringify(value)}; max-age=31536000; path=/; SameSite=Lax`;
        }

        getCookie(name, defaultValue) {
            const match = document.cookie.match(new RegExp(`(^| )${name}=([^;]+)`));
            if (match) {
                try { return JSON.parse(match[2]); } catch(e) { return match[2]; }
            }
            return defaultValue;
        }
    }

    $(document).ready(() => new MotorModuleV2());

})(jQuery);