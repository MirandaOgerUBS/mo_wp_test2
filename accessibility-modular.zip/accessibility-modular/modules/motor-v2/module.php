<?php
/**
 * Module Moteur V2
 * Intégration WordPress pour le module reconstruit.
 */
if (!defined('ABSPATH')) exit;

class ACC_Module_Motor_V2 {
    public function __construct() {
        // Cette classe peut être utilisée pour ajouter des hooks WordPress
        // comme l'enregistrement de styles ou de scripts côté serveur si nécessaire.
        // Pour l'instant, le module est autonome en JS.
    }

    public static function get_default_settings() {
        return [
            'click_areas' => 0,
            'disable_hover' => false,
            'click_delay' => 0,
            'prevent_double_click' => false,
            'cursor_size' => 1,
            'cursor_highlight' => false,
            'disable_drag' => false,
            'focus_highlight' => false
        ];
    }
}

new ACC_Module_Motor_V2();