/**
 * Module Texte - JavaScript (VERSION AUTONOME)
 * Gestion de la personnalisation de la typographie
 * Version: 1.1.0
 * 
 * IMPORTANT: Utilise uniquement les cookies (pas localStorage)
 */

(function($) {
    'use strict';

    /**
     * Classe du module Texte
     */
    class TextModule {
        constructor() {
            this.module = $('#acc-module-text');
            this.toggle = $('#acc-text-toggle');
            this.content = $('#acc-text-content');
            this.fontSelect = $('#acc-text-font');
            this.sizeSlider = $('#acc-text-size');
            this.paragraphSpacingSlider = $('#acc-text-paragraph-spacing');
            this.lineHeightSlider = $('#acc-text-line-height');
            this.wordSpacingSlider = $('#acc-text-word-spacing');
            this.letterSpacingSlider = $('#acc-text-letter-spacing');
            this.removeStylesCheckbox = $('#acc-text-remove-styles');
            this.resetBtn = $('#acc-text-reset');
            
            this.settings = this.getDefaultSettings();
            this.isActive = false;
            
            this.init();
        }

        /**
         * Initialisation
         */
        init() {
            this.loadSettings();
            this.bindEvents();
            this.updateUI();
            
            // Applique les paramètres sauvegardés
            if (this.isActive) {
                this.applyAllSettings();
            }
            
            console.log('✓ Module Texte initialisé', this.settings);
        }

        /**
         * Paramètres par défaut
         */
        getDefaultSettings() {
            return {
                font: 'inherit',
                size: 16,
                paragraphSpacing: 1,
                lineHeight: 150,
                wordSpacing: 0,
                letterSpacing: 0,
                removeStyles: false
            };
        }

        /**
         * Liaison des événements
         */
        bindEvents() {
            // Toggle du module
            this.toggle.on('change', () => this.handleToggle());
            
            // Police
            this.fontSelect.on('change', () => this.handleFontChange());
            
            // Taille
            this.sizeSlider.on('input', () => this.handleSizeChange());
            
            // Espacement paragraphes
            this.paragraphSpacingSlider.on('input', () => this.handleParagraphSpacingChange());
            
            // Interligne
            this.lineHeightSlider.on('input', () => this.handleLineHeightChange());
            
            // Espacement mots
            this.wordSpacingSlider.on('input', () => this.handleWordSpacingChange());
            
            // Espacement lettres
            this.letterSpacingSlider.on('input', () => this.handleLetterSpacingChange());
            
            // Supprimer les styles
            this.removeStylesCheckbox.on('change', () => this.handleRemoveStylesChange());
            
            // Réinitialisation
            this.resetBtn.on('click', () => this.reset());
        }

        /**
         * Gère l'activation/désactivation du module
         */
        handleToggle() {
            this.isActive = this.toggle.is(':checked');
            
            if (this.isActive) {
                this.content.slideDown(300);
                this.applyAllSettings();
                this.savePreference('active', true);
                this.announce('Module texte activé');
                console.log('✓ Module texte activé');
            } else {
                this.content.slideUp(300);
                this.removeAllSettings();
                this.savePreference('active', false);
                this.announce('Module texte désactivé');
                console.log('✓ Module texte désactivé');
            }
        }

        /**
         * Gère le changement de police
         */
        handleFontChange() {
            this.settings.font = this.fontSelect.val();
            this.applyFont();
            this.savePreference('font', this.settings.font);
            this.announce(`Police changée en ${this.settings.font}`);
            console.log('Police changée:', this.settings.font);
        }

        /**
         * Gère le changement de taille
         */
        handleSizeChange() {
            this.settings.size = parseInt(this.sizeSlider.val());
            $('#acc-text-size-value').text(this.settings.size + 'px');
            this.sizeSlider.attr('aria-valuenow', this.settings.size)
                          .attr('aria-valuetext', this.settings.size + ' pixels');
            this.applySize();
            this.savePreference('size', this.settings.size);
        }

        /**
         * Gère le changement d'espacement des paragraphes
         */
        handleParagraphSpacingChange() {
            this.settings.paragraphSpacing = parseFloat(this.paragraphSpacingSlider.val());
            $('#acc-text-paragraph-spacing-value').text(this.settings.paragraphSpacing.toFixed(1) + 'em');
            this.paragraphSpacingSlider.attr('aria-valuenow', this.settings.paragraphSpacing)
                                      .attr('aria-valuetext', this.settings.paragraphSpacing.toFixed(1) + ' em');
            this.applyParagraphSpacing();
            this.savePreference('paragraphSpacing', this.settings.paragraphSpacing);
        }

        /**
         * Gère le changement d'interligne
         */
        handleLineHeightChange() {
            this.settings.lineHeight = parseInt(this.lineHeightSlider.val());
            $('#acc-text-line-height-value').text(this.settings.lineHeight + '%');
            this.lineHeightSlider.attr('aria-valuenow', this.settings.lineHeight)
                                .attr('aria-valuetext', this.settings.lineHeight + ' pourcent');
            this.applyLineHeight();
            this.savePreference('lineHeight', this.settings.lineHeight);
        }

        /**
         * Gère le changement d'espacement des mots
         */
        handleWordSpacingChange() {
            this.settings.wordSpacing = parseInt(this.wordSpacingSlider.val());
            $('#acc-text-word-spacing-value').text(this.settings.wordSpacing + 'px');
            this.wordSpacingSlider.attr('aria-valuenow', this.settings.wordSpacing)
                                 .attr('aria-valuetext', this.settings.wordSpacing + ' pixels');
            this.applyWordSpacing();
            this.savePreference('wordSpacing', this.settings.wordSpacing);
        }

        /**
         * Gère le changement d'espacement des lettres
         */
        handleLetterSpacingChange() {
            this.settings.letterSpacing = parseFloat(this.letterSpacingSlider.val());
            $('#acc-text-letter-spacing-value').text(this.settings.letterSpacing.toFixed(1) + 'px');
            this.letterSpacingSlider.attr('aria-valuenow', this.settings.letterSpacing)
                                   .attr('aria-valuetext', this.settings.letterSpacing.toFixed(1) + ' pixels');
            this.applyLetterSpacing();
            this.savePreference('letterSpacing', this.settings.letterSpacing);
        }

        /**
         * Gère la suppression des styles
         */
        handleRemoveStylesChange() {
            this.settings.removeStyles = this.removeStylesCheckbox.is(':checked');
            this.applyRemoveStyles();
            this.savePreference('removeStyles', this.settings.removeStyles);
            
            const message = this.settings.removeStyles ? 
                'Styles supprimés : texte simplifié' : 
                'Styles restaurés';
            this.announce(message);
            console.log('✓', message);
        }

        /**
         * Applique tous les paramètres
         */
        applyAllSettings() {
            this.applyFont();
            this.applySize();
            this.applyParagraphSpacing();
            this.applyLineHeight();
            this.applyWordSpacing();
            this.applyLetterSpacing();
            this.applyRemoveStyles();
            console.log('✓ Tous les paramètres appliqués', this.settings);
        }

        /**
         * Applique la police
         */
        applyFont() {
            // Supprimer l'ancien style
            $('#acc-text-font-style').remove();
            
            if (this.settings.font !== 'inherit') {
                // Charger OpenDyslexic si nécessaire
                if (this.settings.font === 'OpenDyslexic') {
                    this.loadOpenDyslexic();
                }
                
                const css = `
                    body, p, div, span, a, li, td, th, label, input, textarea, select, button {
                        font-family: '${this.settings.font}', sans-serif !important;
                    }
                `;
                
                $('<style>', {
                    id: 'acc-text-font-style',
                    html: css
                }).appendTo('head');
                
                console.log('✓ Police appliquée:', this.settings.font);
            }
        }

        /**
         * Applique la taille
         */
        applySize() {
            // Supprimer l'ancien style
            $('#acc-text-size-style').remove();
            
            const css = `
                body {
                    font-size: ${this.settings.size}px !important;
                }
            `;
            
            $('<style>', {
                id: 'acc-text-size-style',
                html: css
            }).appendTo('head');
            
            console.log('✓ Taille appliquée:', this.settings.size + 'px');
        }

        /**
         * Applique l'espacement des paragraphes
         */
        applyParagraphSpacing() {
            // Supprimer l'ancien style
            $('#acc-text-paragraph-style').remove();
            
            const css = `
                p {
                    margin-bottom: ${this.settings.paragraphSpacing}em !important;
                }
            `;
            
            $('<style>', {
                id: 'acc-text-paragraph-style',
                html: css
            }).appendTo('head');
            
            console.log('✓ Espacement paragraphes appliqué:', this.settings.paragraphSpacing + 'em');
        }

        /**
         * Applique l'interligne
         */
        applyLineHeight() {
            // Supprimer l'ancien style
            $('#acc-text-lineheight-style').remove();
            
            const css = `
                body, p, div, li, td, th {
                    line-height: ${this.settings.lineHeight}% !important;
                }
                
                h1, h2, h3, h4, h5, h6 {
                    line-height: ${this.settings.lineHeight}% !important;
                }
            `;
            
            $('<style>', {
                id: 'acc-text-lineheight-style',
                html: css
            }).appendTo('head');
            
            console.log('✓ Interligne appliqué:', this.settings.lineHeight + '%');
        }

        /**
         * Applique l'espacement des mots
         */
        applyWordSpacing() {
            // Supprimer l'ancien style
            $('#acc-text-wordspacing-style').remove();
            
            if (this.settings.wordSpacing > 0) {
                const css = `
                    p, div, span, a, li {
                        word-spacing: ${this.settings.wordSpacing}px !important;
                    }
                `;
                
                $('<style>', {
                    id: 'acc-text-wordspacing-style',
                    html: css
                }).appendTo('head');
                
                console.log('✓ Espacement mots appliqué:', this.settings.wordSpacing + 'px');
            }
        }

        /**
         * Applique l'espacement des lettres
         */
        applyLetterSpacing() {
            // Supprimer l'ancien style
            $('#acc-text-letterspacing-style').remove();
            
            if (this.settings.letterSpacing > 0) {
                const css = `
                    p, div, span, a, li, h1, h2, h3, h4, h5, h6 {
                        letter-spacing: ${this.settings.letterSpacing}px !important;
                    }
                `;
                
                $('<style>', {
                    id: 'acc-text-letterspacing-style',
                    html: css
                }).appendTo('head');
                
                console.log('✓ Espacement lettres appliqué:', this.settings.letterSpacing + 'px');
            }
        }

        /**
         * Applique la suppression des styles
         */
        applyRemoveStyles() {
            // Supprimer l'ancien style
            $('#acc-text-removestyles-style').remove();
            
            if (this.settings.removeStyles) {
                const css = `
                    /* Suppression des styles de texte */
                    *, *::before, *::after {
                        font-style: normal !important;
                        text-decoration: none !important;
                        font-weight: normal !important;
                        background-color: transparent !important;
                        text-shadow: none !important;
                        box-shadow: none !important;
                    }
                    
                    /* Exception pour les liens pour garder une indication visuelle */
                    a {
                        border-bottom: 1px solid currentColor !important;
                    }
                    
                    /* Exception pour les titres (garder un poids raisonnable) */
                    h1, h2, h3, h4, h5, h6, strong, b {
                        font-weight: 600 !important;
                    }
                    
                    /* Préserver les backgrounds essentiels */
                    body, main, article, section {
                        background-color: white !important;
                    }
                    
                    /* Préserver les couleurs de texte */
                    * {
                        color: inherit;
                    }
                `;
                
                $('<style>', {
                    id: 'acc-text-removestyles-style',
                    html: css
                }).appendTo('head');
                
                console.log('✓ Styles supprimés : texte simplifié');
            } else {
                console.log('✓ Styles normaux restaurés');
            }
        }

        /**
         * Charge la police OpenDyslexic
         */
        loadOpenDyslexic() {
            if (!$('#acc-opendyslexic-font').length) {
                $('<link>', {
                    id: 'acc-opendyslexic-font',
                    rel: 'stylesheet',
                    href: 'https://fonts.googleapis.com/css2?family=OpenDyslexic&display=swap'
                }).appendTo('head');
                
                console.log('✓ Police OpenDyslexic chargée');
            }
        }

        /**
         * Supprime tous les paramètres
         */
        removeAllSettings() {
            $('#acc-text-font-style').remove();
            $('#acc-text-size-style').remove();
            $('#acc-text-paragraph-style').remove();
            $('#acc-text-lineheight-style').remove();
            $('#acc-text-wordspacing-style').remove();
            $('#acc-text-letterspacing-style').remove();
            $('#acc-text-removestyles-style').remove();
            
            console.log('✓ Tous les styles supprimés');
        }

        /**
         * Réinitialise tous les paramètres
         */
        reset() {
            if (confirm('Réinitialiser tous les paramètres du texte ?')) {
                this.settings = this.getDefaultSettings();
                this.updateUI();
                this.applyAllSettings();
                this.saveAllSettings();
                this.announce('Paramètres du texte réinitialisés');
                console.log('✓ Paramètres réinitialisés');
            }
        }

        /**
         * Met à jour l'interface
         */
        updateUI() {
            this.fontSelect.val(this.settings.font);
            this.sizeSlider.val(this.settings.size);
            this.paragraphSpacingSlider.val(this.settings.paragraphSpacing);
            this.lineHeightSlider.val(this.settings.lineHeight);
            this.wordSpacingSlider.val(this.settings.wordSpacing);
            this.letterSpacingSlider.val(this.settings.letterSpacing);
            this.removeStylesCheckbox.prop('checked', this.settings.removeStyles);
            
            $('#acc-text-size-value').text(this.settings.size + 'px');
            $('#acc-text-paragraph-spacing-value').text(this.settings.paragraphSpacing.toFixed(1) + 'em');
            $('#acc-text-line-height-value').text(this.settings.lineHeight + '%');
            $('#acc-text-word-spacing-value').text(this.settings.wordSpacing + 'px');
            $('#acc-text-letter-spacing-value').text(this.settings.letterSpacing.toFixed(1) + 'px');
        }

        /**
         * Sauvegarde une préférence dans un cookie
         */
        savePreference(key, value) {
            const cookieName = `acc_text_${key}`;
            const cookieValue = JSON.stringify(value);
            const expiryDays = 365;
            const date = new Date();
            date.setTime(date.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
            const expires = "expires=" + date.toUTCString();
            
            document.cookie = `${cookieName}=${cookieValue};${expires};path=/;SameSite=Lax`;
            
            console.log(`Cookie sauvegardé: ${cookieName} = ${cookieValue}`);
        }

        /**
         * Récupère une préférence depuis un cookie
         */
        getPreference(key, defaultValue) {
            const cookieName = `acc_text_${key}`;
            const name = cookieName + "=";
            const decodedCookie = decodeURIComponent(document.cookie);
            const cookieArray = decodedCookie.split(';');
            
            for (let i = 0; i < cookieArray.length; i++) {
                let cookie = cookieArray[i].trim();
                if (cookie.indexOf(name) === 0) {
                    const value = cookie.substring(name.length, cookie.length);
                    try {
                        return JSON.parse(value);
                    } catch(e) {
                        return value;
                    }
                }
            }
            
            return defaultValue;
        }

        /**
         * Charge les paramètres sauvegardés
         */
        loadSettings() {
            this.isActive = this.getPreference('active', false);
            this.settings.font = this.getPreference('font', 'inherit');
            this.settings.size = this.getPreference('size', 16);
            this.settings.paragraphSpacing = this.getPreference('paragraphSpacing', 1);
            this.settings.lineHeight = this.getPreference('lineHeight', 150);
            this.settings.wordSpacing = this.getPreference('wordSpacing', 0);
            this.settings.letterSpacing = this.getPreference('letterSpacing', 0);
            this.settings.removeStyles = this.getPreference('removeStyles', false);
            
            this.toggle.prop('checked', this.isActive);
            if (this.isActive) {
                this.content.show();
            }
            
            console.log('✓ Paramètres chargés:', this.settings);
        }

        /**
         * Sauvegarde tous les paramètres
         */
        saveAllSettings() {
            this.savePreference('active', this.isActive);
            this.savePreference('font', this.settings.font);
            this.savePreference('size', this.settings.size);
            this.savePreference('paragraphSpacing', this.settings.paragraphSpacing);
            this.savePreference('lineHeight', this.settings.lineHeight);
            this.savePreference('wordSpacing', this.settings.wordSpacing);
            this.savePreference('letterSpacing', this.settings.letterSpacing);
            this.savePreference('removeStyles', this.settings.removeStyles);
        }

        /**
         * Annonce pour les lecteurs d'écran
         */
        announce(message) {
            // Créer une région ARIA live si elle n'existe pas
            let $announcer = $('#acc-screen-reader-announcer');
            if (!$announcer.length) {
                $announcer = $('<div>', {
                    id: 'acc-screen-reader-announcer',
                    'aria-live': 'polite',
                    'aria-atomic': 'true',
                    css: {
                        position: 'absolute',
                        left: '-10000px',
                        width: '1px',
                        height: '1px',
                        overflow: 'hidden'
                    }
                }).appendTo('body');
            }
            
            // Effacer puis annoncer
            $announcer.text('');
            setTimeout(() => {
                $announcer.text(message);
            }, 100);
        }
    }

    /**
     * Initialisation
     */
    $(document).ready(function() {
        if ($('#acc-module-text').length) {
            window.accTextModule = new TextModule();
            console.log('✓ Module Texte prêt');
        }
    });

})(jQuery);