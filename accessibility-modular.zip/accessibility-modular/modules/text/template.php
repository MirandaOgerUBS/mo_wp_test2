<?php
/**
 * Template du module Texte
 * Interface utilisateur pour la personnalisation de la typographie
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="acc-module acc-module-text" id="acc-module-text" data-module="text">
    <div class="acc-module-header">
        <h3 class="acc-module-title">
            <span class="acc-module-icon" aria-hidden="true">📝</span>
            <?php esc_html_e('Texte', 'accessibility-modular'); ?>
        </h3>
        <label class="acc-module-toggle">
            <input 
                type="checkbox" 
                id="acc-text-toggle"
                aria-label="<?php esc_attr_e('Activer/désactiver le module texte', 'accessibility-modular'); ?>"
            />
            <span class="acc-module-toggle-slider"></span>
        </label>
    </div>

    <div class="acc-module-content" id="acc-text-content" style="display: none;">
        <!-- Police de caractères -->
        <div class="acc-control-group">
            <label for="acc-text-font" class="acc-control-label">
                <?php esc_html_e('Police de caractères', 'accessibility-modular'); ?>
            </label>
            <select 
                id="acc-text-font" 
                class="acc-select"
                aria-label="<?php esc_attr_e('Sélectionner une police de caractères', 'accessibility-modular'); ?>"
            >
                <option value="inherit"><?php esc_html_e('Police par défaut', 'accessibility-modular'); ?></option>
                <option value="Arial">Arial</option>
                <option value="Times New Roman">Times New Roman</option>
                <option value="Verdana">Verdana</option>
                <option value="Georgia">Georgia</option>
                <option value="OpenDyslexic">OpenDyslexic</option>
                <option value="Comic Sans MS">Comic Sans MS</option>
                <option value="Trebuchet MS">Trebuchet MS</option>
            </select>
        </div>

        <!-- Taille du texte -->
        <div class="acc-control-group">
            <label for="acc-text-size" class="acc-control-label">
                <?php esc_html_e('Taille du texte', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-text-size-value">16px</span>
            </label>
            <input 
                type="range" 
                id="acc-text-size" 
                class="acc-slider"
                min="12" 
                max="24" 
                step="1" 
                value="16"
                aria-label="<?php esc_attr_e('Ajuster la taille du texte', 'accessibility-modular'); ?>"
                aria-valuemin="12"
                aria-valuemax="24"
                aria-valuenow="16"
                aria-valuetext="16 pixels"
            />
        </div>

        <!-- Espacement des paragraphes -->
        <div class="acc-control-group">
            <label for="acc-text-paragraph-spacing" class="acc-control-label">
                <?php esc_html_e('Espacement des paragraphes', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-text-paragraph-spacing-value">1em</span>
            </label>
            <input 
                type="range" 
                id="acc-text-paragraph-spacing" 
                class="acc-slider"
                min="0" 
                max="2" 
                step="0.1" 
                value="1"
                aria-label="<?php esc_attr_e('Ajuster l\'espacement des paragraphes', 'accessibility-modular'); ?>"
                aria-valuemin="0"
                aria-valuemax="2"
                aria-valuenow="1"
                aria-valuetext="1 em"
            />
        </div>

        <!-- Interligne -->
        <div class="acc-control-group">
            <label for="acc-text-line-height" class="acc-control-label">
                <?php esc_html_e('Interligne', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-text-line-height-value">150%</span>
            </label>
            <input 
                type="range" 
                id="acc-text-line-height" 
                class="acc-slider"
                min="100" 
                max="250" 
                step="10" 
                value="150"
                aria-label="<?php esc_attr_e('Ajuster l\'interligne', 'accessibility-modular'); ?>"
                aria-valuemin="100"
                aria-valuemax="250"
                aria-valuenow="150"
                aria-valuetext="150 pourcent"
            />
        </div>

        <!-- Espacement des mots -->
        <div class="acc-control-group">
            <label for="acc-text-word-spacing" class="acc-control-label">
                <?php esc_html_e('Espacement des mots', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-text-word-spacing-value">0px</span>
            </label>
            <input 
                type="range" 
                id="acc-text-word-spacing" 
                class="acc-slider"
                min="0" 
                max="10" 
                step="1" 
                value="0"
                aria-label="<?php esc_attr_e('Ajuster l\'espacement des mots', 'accessibility-modular'); ?>"
                aria-valuemin="0"
                aria-valuemax="10"
                aria-valuenow="0"
                aria-valuetext="0 pixels"
            />
        </div>

        <!-- Espacement des lettres -->
        <div class="acc-control-group">
            <label for="acc-text-letter-spacing" class="acc-control-label">
                <?php esc_html_e('Espacement des lettres', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-text-letter-spacing-value">0px</span>
            </label>
            <input 
                type="range" 
                id="acc-text-letter-spacing" 
                class="acc-slider"
                min="0" 
                max="5" 
                step="0.5" 
                value="0"
                aria-label="<?php esc_attr_e('Ajuster l\'espacement des lettres', 'accessibility-modular'); ?>"
                aria-valuemin="0"
                aria-valuemax="5"
                aria-valuenow="0"
                aria-valuetext="0 pixels"
            />
        </div>

        <!-- Boutons d'action -->
        <div class="acc-control-group" style="margin-top: 20px;">
            <div class="acc-button-group">
                <button 
                    type="button" 
                    id="acc-text-reset" 
                    class="acc-button"
                    aria-label="<?php esc_attr_e('Réinitialiser les paramètres du texte', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Réinitialiser', 'accessibility-modular'); ?>
                </button>
            </div>
        </div>
    </div>
</div>
<!-- Supprimer les styles (À ajouter après letter_spacing) -->
        <div class="acc-control-group" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #ddd;">
            <label class="acc-control-label" style="display: flex; align-items: center; cursor: pointer;">
                <input 
                    type="checkbox" 
                    id="acc-text-remove-styles" 
                    style="margin-right: 10px; width: auto;"
                    aria-label="<?php esc_attr_e('Supprimer tous les styles de texte', 'accessibility-modular'); ?>"
                />
                <span><?php esc_html_e('Supprimer les styles', 'accessibility-modular'); ?></span>
            </label>
            <p class="acc-control-description" style="font-size: 12px; color: #666; margin-top: 5px; margin-left: 30px;">
                <?php esc_html_e('Supprime l\'italique, le gras, le soulignement et le surlignement', 'accessibility-modular'); ?>
            </p>
        </div>