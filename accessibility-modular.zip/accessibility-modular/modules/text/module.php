<?php
/**
 * Module Texte
 * Personnalisation de la typographie
 * 
 * @package AccessibilityModular
 * @subpackage Modules
 * @version 1.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Classe du module Texte
 */
class ACC_Module_Text {
    
    /**
     * Version du module
     */
    const VERSION = '1.1.0';
    
    /**
     * Nom du module
     */
    const MODULE_NAME = 'text';
    
    /**
     * Constructeur
     */
    public function __construct() {
        $this->init_hooks();
    }
    
    /**
     * Initialise les hooks
     */
    private function init_hooks() {
        // Enqueue la police OpenDyslexic si nécessaire
        add_action('wp_enqueue_scripts', [$this, 'maybe_enqueue_opendyslexic']);
        
        // Filtre pour ajouter des métadonnées
        add_filter('acc_module_metadata', [$this, 'add_metadata'], 10, 2);
    }
    
    /**
     * Charge la police OpenDyslexic si nécessaire
     */
    public function maybe_enqueue_opendyslexic() {
        // Vérifie si l'utilisateur a sélectionné OpenDyslexic via cookie
        if (isset($_COOKIE['acc_text_font'])) {
            $font = json_decode(stripslashes($_COOKIE['acc_text_font']), true);
            
            if ($font === 'OpenDyslexic') {
                wp_enqueue_style(
                    'acc-opendyslexic',
                    'https://fonts.googleapis.com/css2?family=OpenDyslexic&display=swap',
                    [],
                    self::VERSION
                );
            }
        }
    }
    
    /**
     * Ajoute des métadonnées au module
     * 
     * @param array $metadata Métadonnées existantes
     * @param string $module_name Nom du module
     * @return array
     */
    public function add_metadata($metadata, $module_name) {
        if ($module_name !== self::MODULE_NAME) {
            return $metadata;
        }
        
        $metadata['fonts_available'] = $this->get_available_fonts();
        $metadata['rgaa_compliance'] = [
            'criteria' => ['10.4', '10.9', '10.12'],
            'level' => 'AA'
        ];
        
        return $metadata;
    }
    
    /**
     * Retourne la liste des polices disponibles
     * 
     * @return array
     */
    private function get_available_fonts() {
        return [
            'inherit' => __('Police par défaut', 'accessibility-modular'),
            'Arial' => 'Arial',
            'Times New Roman' => 'Times New Roman',
            'Verdana' => 'Verdana',
            'Georgia' => 'Georgia',
            'OpenDyslexic' => 'OpenDyslexic',
            'Comic Sans MS' => 'Comic Sans MS',
            'Trebuchet MS' => 'Trebuchet MS'
        ];
    }
    
    /**
     * Retourne les paramètres par défaut
     * 
     * @return array
     */
    public static function get_default_settings() {
        return [
            'font_family' => 'inherit',
            'font_size' => 16,
            'paragraph_spacing' => 1,
            'line_height' => 150,
            'word_spacing' => 0,
            'letter_spacing' => 0,
            'remove_styles' => false
        ];
    }
    
    /**
     * Valide les paramètres
     * 
     * @param array $settings Paramètres à valider
     * @return array|WP_Error
     */
    public static function validate_settings($settings) {
        $defaults = self::get_default_settings();
        $validated = [];
        
        // Validation de la police
        if (isset($settings['font_family'])) {
            $allowed_fonts = ['inherit', 'Arial', 'Times New Roman', 'Verdana', 'Georgia', 'OpenDyslexic', 'Comic Sans MS', 'Trebuchet MS'];
            if (in_array($settings['font_family'], $allowed_fonts)) {
                $validated['font_family'] = $settings['font_family'];
            }
        }
        
        // Validation de la taille
        if (isset($settings['font_size'])) {
            $size = intval($settings['font_size']);
            if ($size >= 12 && $size <= 24) {
                $validated['font_size'] = $size;
            }
        }
        
        // Validation de l'espacement des paragraphes
        if (isset($settings['paragraph_spacing'])) {
            $spacing = floatval($settings['paragraph_spacing']);
            if ($spacing >= 0 && $spacing <= 2) {
                $validated['paragraph_spacing'] = $spacing;
            }
        }
        
        // Validation de l'interligne
        if (isset($settings['line_height'])) {
            $height = intval($settings['line_height']);
            if ($height >= 100 && $height <= 250) {
                $validated['line_height'] = $height;
            }
        }
        
        // Validation de l'espacement des mots
        if (isset($settings['word_spacing'])) {
            $spacing = intval($settings['word_spacing']);
            if ($spacing >= 0 && $spacing <= 10) {
                $validated['word_spacing'] = $spacing;
            }
        }
        
        // Validation de l'espacement des lettres
        if (isset($settings['letter_spacing'])) {
            $spacing = floatval($settings['letter_spacing']);
            if ($spacing >= 0 && $spacing <= 5) {
                $validated['letter_spacing'] = $spacing;
            }
        }
        
        // Validation de la suppression des styles
        if (isset($settings['remove_styles'])) {
            $validated['remove_styles'] = (bool) $settings['remove_styles'];
        }
        
        // Fusionne avec les valeurs par défaut
        return array_merge($defaults, $validated);
    }
    
    /**
     * Nettoie les cookies du module
     */
    public static function clear_cookies() {
        $cookies = [
            'acc_text_font',
            'acc_text_size',
            'acc_text_paragraph_spacing',
            'acc_text_line_height',
            'acc_text_word_spacing',
            'acc_text_letter_spacing',
            'acc_text_remove_styles'
        ];
        
        foreach ($cookies as $cookie) {
            if (isset($_COOKIE[$cookie])) {
                setcookie($cookie, '', time() - 3600, '/');
            }
        }
    }
}

// Initialise le module
new ACC_Module_Text();