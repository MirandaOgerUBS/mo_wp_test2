<?php
/**
 * Template du module Contrôle Moteur
 * Interface utilisateur pour faciliter l'interaction
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="acc-module acc-module-motor" id="acc-module-motor" data-module="motor">
    <div class="acc-module-header">
        <h3 class="acc-module-title">
            <span class="acc-module-icon" aria-hidden="true">🖱️</span>
            <?php esc_html_e('Contrôle Moteur', 'accessibility-modular'); ?>
        </h3>
        <label class="acc-module-toggle">
            <input 
                type="checkbox" 
                id="acc-motor-toggle"
                aria-label="<?php esc_attr_e('Activer/désactiver le contrôle moteur', 'accessibility-modular'); ?>"
            />
            <span class="acc-module-toggle-slider"></span>
        </label>
    </div>

    <div class="acc-module-content" id="acc-motor-content" style="display: none;">
        
        <div class="acc-info-box" style="background: #fff3e0; border-left: 4px solid #ff9800; padding: 12px; margin-bottom: 20px; border-radius: 4px;">
            <p style="margin: 0; font-size: 13px; color: #e65100;">
                <strong>ℹ️ <?php esc_html_e('Pour qui ?', 'accessibility-modular'); ?></strong><br>
                <?php esc_html_e('Parkinson, tremblements, SEP, arthrose, Wilson, troubles de la coordination', 'accessibility-modular'); ?>
            </p>
        </div>

        <div class="acc-control-group">
            <label for="acc-motor-click-areas" class="acc-control-label">
                <?php esc_html_e('Zones de clic élargies', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-motor-click-areas-value">0px</span>
            </label>
            <input 
                type="range" 
                id="acc-motor-click-areas" 
                class="acc-slider"
                min="0" 
                max="30" 
                step="5" 
                value="0"
                aria-label="<?php esc_attr_e('Ajuster la taille des zones cliquables', 'accessibility-modular'); ?>"
                aria-valuemin="0"
                aria-valuemax="30"
                aria-valuenow="0"
                aria-valuetext="0 pixels"
            />
            <p class="acc-control-description">
                <?php esc_html_e('Agrandit tous les boutons et liens pour faciliter le clic', 'accessibility-modular'); ?>
            </p>
        </div>

        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-motor-disable-hover" 
                    class="acc-checkbox"
                    aria-describedby="acc-motor-hover-desc"
                />
                <span><?php esc_html_e('Désactiver le survol', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-motor-hover-desc" class="acc-control-description">
                <?php esc_html_e('Supprime les menus et actions déclenchés au passage de la souris', 'accessibility-modular'); ?>
            </p>
        </div>

        <div class="acc-control-group">
            <label for="acc-motor-click-delay" class="acc-control-label">
                <?php esc_html_e('Délai d\'activation', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-motor-click-delay-value">0ms</span>
            </label>
            <input 
                type="range" 
                id="acc-motor-click-delay" 
                class="acc-slider"
                min="0" 
                max="2000" 
                step="100" 
                value="0"
                aria-label="<?php esc_attr_e('Ajuster le délai d\'activation', 'accessibility-modular'); ?>"
                aria-valuemin="0"
                aria-valuemax="2000"
                aria-valuenow="0"
                aria-valuetext="0 millisecondes"
            />
            <p class="acc-control-description">
                <?php esc_html_e('Temps d\'attente avant qu\'un clic soit validé (évite les clics accidentels)', 'accessibility-modular'); ?>
            </p>
        </div>

        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-motor-prevent-double" 
                    class="acc-checkbox"
                    aria-describedby="acc-motor-double-desc"
                />
                <span><?php esc_html_e('Prévenir les double-clics', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-motor-double-desc" class="acc-control-description">
                <?php esc_html_e('Ignore les clics répétés accidentels dans un court laps de temps', 'accessibility-modular'); ?>
            </p>
        </div>

        <div class="acc-control-group">
            <label for="acc-motor-cursor-size" class="acc-control-label">
                <?php esc_html_e('Taille du curseur', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-motor-cursor-size-value">1x</span>
            </label>
            <input 
                type="range" 
                id="acc-motor-cursor-size" 
                class="acc-slider"
                min="1" 
                max="4" 
                step="0.5" 
                value="1"
                aria-label="<?php esc_attr_e('Ajuster la taille du curseur', 'accessibility-modular'); ?>"
                aria-valuemin="1"
                aria-valuemax="4"
                aria-valuenow="1"
                aria-valuetext="1 fois"
            />
            <p class="acc-control-description">
                <?php esc_html_e('Agrandit le curseur de la souris pour le rendre plus visible', 'accessibility-modular'); ?>
            </p>
        </div>

        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-motor-cursor-highlight" 
                    class="acc-checkbox"
                    aria-describedby="acc-motor-highlight-desc"
                />
                <span><?php esc_html_e('Surbrillance du curseur', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-motor-highlight-desc" class="acc-control-description">
                <?php esc_html_e('Ajoute un halo lumineux autour du curseur pour le repérer facilement', 'accessibility-modular'); ?>
            </p>
        </div>

        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-motor-click-feedback" 
                    class="acc-checkbox"
                    aria-describedby="acc-motor-feedback-desc"
                />
                <span><?php esc_html_e('Retour visuel des clics', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-motor-feedback-desc" class="acc-control-description">
                <?php esc_html_e('Affiche une animation lors des clics pour confirmer l\'action', 'accessibility-modular'); ?>
            </p>
        </div>

        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-motor-disable-drag" 
                    class="acc-checkbox"
                    aria-describedby="acc-motor-drag-desc"
                />
                <span><?php esc_html_e('Désactiver le glisser-déposer', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-motor-drag-desc" class="acc-control-description">
                <?php esc_html_e('Empêche le déplacement accidentel d\'éléments', 'accessibility-modular'); ?>
            </p>
        </div>

        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-motor-sticky-focus" 
                    class="acc-checkbox"
                    aria-describedby="acc-motor-focus-desc"
                />
                <span><?php esc_html_e('Focus persistant', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-motor-focus-desc" class="acc-control-description">
                <?php esc_html_e('Maintient un indicateur visible sur l\'élément sélectionné', 'accessibility-modular'); ?>
            </p>
        </div>

        <div class="acc-control-group" style="margin-top: 25px; padding-top: 20px; border-top: 1px solid #ddd;">
            <div class="acc-button-group">
                <button 
                    type="button" 
                    id="acc-motor-reset" 
                    class="acc-button"
                    aria-label="<?php esc_attr_e('Réinitialiser les paramètres de contrôle moteur', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Réinitialiser', 'accessibility-modular'); ?>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
/* ... (Les styles CSS restent identiques) ... */
.acc-checkbox-label {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-weight: 500;
}
.acc-checkbox {
    margin-right: 10px;
    width: 18px;
    height: 18px;
    cursor: pointer;
}
.acc-control-description {
    font-size: 12px;
    color: #666;
    margin: 5px 0 0 28px;
    line-height: 1.4;
}
.acc-button-secondary {
    background: #f5f5f5;
    border: 1px solid #ddd;
    color: #333;
}
.acc-button-secondary:hover {
    background: #e0e0e0;
}
.acc-preset-buttons button {
    transition: all 0.2s;
}
.acc-preset-buttons button:hover {
    transform: translateY(-2px);
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
</style>