<?php
/**
 * Module Contrôle Moteur
 * Facilite l'interaction pour les personnes avec troubles moteurs
 * 
 * @package AccessibilityModular
 * @subpackage Modules
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Classe du module Contrôle Moteur
 */
class ACC_Module_Motor {
    
    /**
     * Version du module
     */
    const VERSION = '1.0.0';
    
    /**
     * Nom du module
     */
    const MODULE_NAME = 'motor';
    
    /**
     * Constructeur
     */
    public function __construct() {
        $this->init_hooks();
    }
    
    /**
     * Initialise les hooks
     */
    private function init_hooks() {
        add_filter('acc_module_metadata', array($this, 'add_metadata'), 10, 2);
        add_action('wp_head', array($this, 'add_meta_tags'), 1);
    }
    
    /**
     * Ajoute des métadonnées au module
     * 
     * @param array $metadata Métadonnées existantes
     * @param string $module_name Nom du module
     * @return array
     */
    public function add_metadata($metadata, $module_name) {
        if ($module_name !== self::MODULE_NAME) {
            return $metadata;
        }
        
        $metadata['motor_features'] = $this->get_motor_features();
        $metadata['wcag_compliance'] = array(
            'criteria' => array('2.1.1', '2.5.1', '2.5.2', '2.5.5', '2.5.8'),
            'level' => 'AAA'
        );
        $metadata['rgaa_compliance'] = array(
            'criteria' => array('10.7', '13.1', '13.2'),
            'level' => 'AA'
        );
        $metadata['medical_conditions'] = array(
            'parkinson',
            'tremblements_essentiels',
            'sclerose_en_plaques',
            'maladie_wilson',
            'arthrose',
            'troubles_moteurs'
        );
        
        return $metadata;
    }
    
    /**
     * Ajoute les meta tags
     */
    public function add_meta_tags() {
        // Meta tag pour désactiver le zoom tactile si demandé
        if ($this->is_touch_optimization_active()) {
            echo '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">' . "\n";
        }
    }
    
    /**
     * Vérifie si l'optimisation tactile est active
     * 
     * @return bool
     */
    private function is_touch_optimization_active() {
        return isset($_COOKIE['acc_motor_large_click_areas']) && 
               json_decode(stripslashes($_COOKIE['acc_motor_large_click_areas']), true) > 0;
    }
    
    /**
     * Retourne les fonctionnalités motrices
     * 
     * @return array
     */
    private function get_motor_features() {
        return array(
            'large_click_areas' => __('Zones de clic élargies', 'accessibility-modular'),
            'disable_hover' => __('Désactivation du survol', 'accessibility-modular'),
            'click_delay' => __('Délai d\'activation des clics', 'accessibility-modular'),
            'prevent_double_click' => __('Prévention double-clic', 'accessibility-modular'),
            'large_cursor' => __('Curseur agrandi', 'accessibility-modular'),
            'cursor_highlight' => __('Surbrillance curseur', 'accessibility-modular'),
            'click_feedback' => __('Retour visuel des clics', 'accessibility-modular'),
            'disable_drag' => __('Désactivation drag & drop', 'accessibility-modular'),
            'sticky_focus' => __('Focus persistant', 'accessibility-modular')
        );
    }
    
    /**
     * Retourne les paramètres par défaut
     * 
     * @return array
     */
    public static function get_default_settings() {
        return array(
            'large_click_areas' => 0,
            'disable_hover' => false,
            'click_delay' => 0,
            'prevent_double_click' => false,
            'large_cursor' => 1,
            'cursor_highlight' => false,
            'click_feedback' => false,
            'disable_drag' => false,
            'sticky_focus' => false
        );
    }
    
    /**
     * Valide les paramètres
     * 
     * @param array $settings Paramètres à valider
     * @return array
     */
    public static function validate_settings($settings) {
        $defaults = self::get_default_settings();
        $validated = array();
        
        // Validation zones de clic
        if (isset($settings['large_click_areas'])) {
            $size = intval($settings['large_click_areas']);
            if ($size >= 0 && $size <= 30) {
                $validated['large_click_areas'] = $size;
            }
        }
        
        // Validation désactivation hover
        if (isset($settings['disable_hover'])) {
            $validated['disable_hover'] = (bool) $settings['disable_hover'];
        }
        
        // Validation délai clic
        if (isset($settings['click_delay'])) {
            $delay = intval($settings['click_delay']);
            if ($delay >= 0 && $delay <= 2000) {
                $validated['click_delay'] = $delay;
            }
        }
        
        // Validation prévention double-clic
        if (isset($settings['prevent_double_click'])) {
            $validated['prevent_double_click'] = (bool) $settings['prevent_double_click'];
        }
        
        // Validation curseur agrandi
        if (isset($settings['large_cursor'])) {
            $size = floatval($settings['large_cursor']);
            if ($size >= 1 && $size <= 4) {
                $validated['large_cursor'] = $size;
            }
        }
        
        // Validation surbrillance curseur
        if (isset($settings['cursor_highlight'])) {
            $validated['cursor_highlight'] = (bool) $settings['cursor_highlight'];
        }
        
        // Validation retour visuel
        if (isset($settings['click_feedback'])) {
            $validated['click_feedback'] = (bool) $settings['click_feedback'];
        }
        
        // Validation désactivation drag
        if (isset($settings['disable_drag'])) {
            $validated['disable_drag'] = (bool) $settings['disable_drag'];
        }
        
        // Validation focus persistant
        if (isset($settings['sticky_focus'])) {
            $validated['sticky_focus'] = (bool) $settings['sticky_focus'];
        }
        
        return array_merge($defaults, $validated);
    }
    
    /**
     * Nettoie les cookies du module
     */
    public static function clear_cookies() {
        $cookies = array(
            'acc_motor_large_click_areas',
            'acc_motor_disable_hover',
            'acc_motor_click_delay',
            'acc_motor_prevent_double_click',
            'acc_motor_large_cursor',
            'acc_motor_cursor_highlight',
            'acc_motor_click_feedback',
            'acc_motor_disable_drag',
            'acc_motor_sticky_focus'
        );
        
        foreach ($cookies as $cookie) {
            if (isset($_COOKIE[$cookie])) {
                setcookie($cookie, '', time() - 3600, '/');
            }
        }
    }
}

// Initialise le module
new ACC_Module_Motor();