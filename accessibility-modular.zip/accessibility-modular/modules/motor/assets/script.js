/**
 * Module Contrôle Moteur - JavaScript
 * Version: 1.0.4 (Sans presets)
 */

(function($) {
    'use strict';

    class MotorModule {
        constructor() {
            this.module = $('#acc-module-motor');
            this.toggle = $('#acc-motor-toggle');
            this.content = $('#acc-motor-content');
            
            // Contrôles
            this.clickAreasSlider = $('#acc-motor-click-areas');
            this.disableHoverCheckbox = $('#acc-motor-disable-hover');
            this.clickDelaySlider = $('#acc-motor-click-delay');
            this.preventDoubleCheckbox = $('#acc-motor-prevent-double');
            this.cursorSizeSlider = $('#acc-motor-cursor-size');
            this.cursorHighlightCheckbox = $('#acc-motor-cursor-highlight');
            this.clickFeedbackCheckbox = $('#acc-motor-click-feedback');
            this.disableDragCheckbox = $('#acc-motor-disable-drag');
            this.stickyFocusCheckbox = $('#acc-motor-sticky-focus');
            
            // Presets et Reset
            this.resetBtn = $('#acc-motor-reset');
            
            this.settings = this.getDefaultSettings();
            this.isActive = false;
            this.lastClickTime = 0;
            this.lastClickTarget = null;
            this.clickTimer = null;
            this.pendingClick = null;
            
            this.init();
        }

        init() {
            this.loadSettings();
            this.bindEvents();
            this.updateUI();
            
            if (this.isActive) {
                this.applyAllSettings();
            }
            
            console.log('✓ Module Contrôle Moteur initialisé (sans presets)');
        }

        getDefaultSettings() {
            return {
                clickAreas: 0,
                disableHover: false,
                clickDelay: 0,
                preventDouble: false,
                cursorSize: 1,
                cursorHighlight: false,
                clickFeedback: false,
                disableDrag: false,
                stickyFocus: false
            };
        }

        bindEvents() {
            this.toggle.on('change', () => this.handleToggle());
            this.clickAreasSlider.on('input', () => this.handleClickAreas());
            this.disableHoverCheckbox.on('change', () => this.handleDisableHover());
            this.clickDelaySlider.on('input', () => this.handleClickDelay());
            this.preventDoubleCheckbox.on('change', () => this.handlePreventDouble());
            this.cursorSizeSlider.on('input', () => this.handleCursorSize());
            this.cursorHighlightCheckbox.on('change', () => this.handleCursorHighlight());
            this.clickFeedbackCheckbox.on('change', () => this.handleClickFeedback());
            this.disableDragCheckbox.on('change', () => this.handleDisableDrag());
            this.stickyFocusCheckbox.on('change', () => this.handleStickyFocus());
            this.resetBtn.on('click', () => this.reset());

            // Correction de propagation pour éviter les boucles
            this.module.on('click', (e) => {
                e.stopPropagation();
            });
        }

        handleToggle() {
            this.isActive = this.toggle.is(':checked');
            
            if (this.isActive) {
                this.content.slideDown(300);
                this.applyAllSettings();
                this.savePreference('active', true);
                this.announce('Module contrôle moteur activé');
            } else {
                this.content.slideUp(300);
                this.removeAllSettings();
                this.savePreference('active', false);
                this.announce('Module contrôle moteur désactivé');
            }
        }
        
        // ... (Toutes les fonctions handle... et apply... restent les mêmes)

        handleClickAreas(){this.settings.clickAreas=parseInt(this.clickAreasSlider.val());$('#acc-motor-click-areas-value').text(this.settings.clickAreas+'px');this.clickAreasSlider.attr('aria-valuenow',this.settings.clickAreas).attr('aria-valuetext',this.settings.clickAreas+' pixels');this.applyClickAreas();this.savePreference('large_click_areas',this.settings.clickAreas)}handleDisableHover(){this.settings.disableHover=this.disableHoverCheckbox.is(':checked');this.applyDisableHover();this.savePreference('disable_hover',this.settings.disableHover);this.announce(this.settings.disableHover?'Survol désactivé':'Survol réactivé')}handleClickDelay(){this.settings.clickDelay=parseInt(this.clickDelaySlider.val());$('#acc-motor-click-delay-value').text(this.settings.clickDelay+'ms');this.clickDelaySlider.attr('aria-valuenow',this.settings.clickDelay).attr('aria-valuetext',this.settings.clickDelay+' millisecondes');this.applyClickDelay();this.savePreference('click_delay',this.settings.clickDelay)}handlePreventDouble(){this.settings.preventDouble=this.preventDoubleCheckbox.is(':checked');this.applyPreventDouble();this.savePreference('prevent_double_click',this.settings.preventDouble);this.announce(this.settings.preventDouble?'Double-clic prévenu':'Double-clic normal')}handleCursorSize(){this.settings.cursorSize=parseFloat(this.cursorSizeSlider.val());$('#acc-motor-cursor-size-value').text(this.settings.cursorSize+'x');this.cursorSizeSlider.attr('aria-valuenow',this.settings.cursorSize).attr('aria-valuetext',this.settings.cursorSize+' fois');this.applyCursorSize();this.savePreference('large_cursor',this.settings.cursorSize)}handleCursorHighlight(){this.settings.cursorHighlight=this.cursorHighlightCheckbox.is(':checked');this.applyCursorHighlight();this.savePreference('cursor_highlight',this.settings.cursorHighlight);this.announce(this.settings.cursorHighlight?'Surbrillance activée':'Surbrillance désactivée')}handleClickFeedback(){this.settings.clickFeedback=this.clickFeedbackCheckbox.is(':checked');this.applyClickFeedback();this.savePreference('click_feedback',this.settings.clickFeedback);this.announce(this.settings.clickFeedback?'Retour visuel activé':'Retour visuel désactivé')}handleDisableDrag(){this.settings.disableDrag=this.disableDragCheckbox.is(':checked');this.applyDisableDrag();this.savePreference('disable_drag',this.settings.disableDrag);this.announce(this.settings.disableDrag?'Glisser-déposer désactivé':'Glisser-déposer réactivé')}handleStickyFocus(){this.settings.stickyFocus=this.stickyFocusCheckbox.is(':checked');this.applyStickyFocus();this.savePreference('sticky_focus',this.settings.stickyFocus);this.announce(this.settings.stickyFocus?'Focus persistant activé':'Focus normal')}applyAllSettings(){this.applyClickAreas();this.applyDisableHover();this.applyClickDelay();this.applyPreventDouble();this.applyCursorSize();this.applyCursorHighlight();this.applyClickFeedback();this.applyDisableDrag();this.applyStickyFocus()}applyClickAreas(){$('#acc-motor-clickareas-style').remove();if(this.settings.clickAreas>0){const padding=this.settings.clickAreas;const css=` body :not(#acc-module-motor) a, body :not(#acc-module-motor) button, body :not(#acc-module-motor) input, body :not(#acc-module-motor) select, body :not(#acc-module-motor) textarea, body :not(#acc-module-motor) [role="button"], body :not(#acc-module-motor) [onclick] { padding: ${padding}px !important; min-width: calc(44px + ${padding*2}px) !important; min-height: calc(44px + ${padding*2}px) !important; }`;$('<style>',{id:'acc-motor-clickareas-style',html:css}).appendTo('head')}}applyDisableHover(){$('#acc-motor-hover-style').remove();if(this.settings.disableHover){const css=` [class*="dropdown"]:hover > [class*="menu"], [class*="dropdown"]:hover > ul, nav:hover > ul { display: none !important; }`;$('<style>',{id:'acc-motor-hover-style',html:css}).appendTo('head');$('[data-toggle="dropdown"]').off('mouseenter mouseleave')}}applyClickDelay(){$(document).off('click.motorDelay');if(this.settings.clickDelay>0){$(document).on('click.motorDelay','a, button, [role="button"], [onclick]',e=>{const $target=$(e.currentTarget);if($target.data('motor-pending')){e.preventDefault();e.stopPropagation();return false}e.preventDefault();e.stopPropagation();$target.data('motor-pending',true).css('opacity','0.5');setTimeout(()=>{if(typeof $target.data==='function'){$target.data('motor-pending',false).css('opacity','1')}if(typeof $target[0].click==='function')$target[0].click()},this.settings.clickDelay);return false})}}applyPreventDouble(){$(document).off('click.motorDouble');if(this.settings.preventDouble){$(document).on('click.motorDouble','a, button, [role="button"], [onclick]',e=>{const now=Date.now(),target=e.currentTarget;if(this.lastClickTarget===target&&(now-this.lastClickTime)<500){e.preventDefault();e.stopPropagation();return false}this.lastClickTime=now;this.lastClickTarget=target})}}applyCursorSize(){$('#acc-motor-cursor-style').remove();if(this.settings.cursorSize>1){const size=this.settings.cursorSize,cursorSize=Math.round(24*size),hotspot=Math.round(12*size);const css=` body, body * { cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="${cursorSize}" height="${cursorSize}" viewBox="0 0 24 24"><path fill="black" stroke="white" stroke-width="1" d="M3 3 L3 18 L9 12 L12 18 L15 17 L12 11 L18 11 Z"/></svg>') ${hotspot} ${hotspot}, auto !important; }`;$('<style>',{id:'acc-motor-cursor-style',html:css}).appendTo('head')}}applyCursorHighlight(){$('#acc-motor-highlight').remove();$(document).off('mousemove.motorHighlight');if(this.settings.cursorHighlight){const $highlight=$('<div>',{id:'acc-motor-highlight'}).css({position:'fixed',width:'40px',height:'40px',borderRadius:'50%',border:'3px solid #ff9800',boxShadow:'0 0 20px rgba(255, 152, 0, 0.6)',pointerEvents:'none',zIndex:999999,transform:'translate(-50%, -50%)',transition:'top 0.05s ease-out, left 0.05s ease-out'});$('body').append($highlight);$(document).on('mousemove.motorHighlight',e=>$highlight.css({left:e.pageX+'px',top:e.pageY+'px'}))}}applyClickFeedback(){$(document).off('click.motorFeedback');if(this.settings.clickFeedback){$(document).on('click.motorFeedback',e=>{const $ripple=$('<div>').css({position:'fixed',left:e.pageX+'px',top:e.pageY+'px',width:'20px',height:'20px',borderRadius:'50%',background:'rgba(76, 175, 80, 0.6)',transform:'translate(-50%, -50%)',pointerEvents:'none',zIndex:999999,animation:'motor-ripple 0.6s ease-out'});$('body').append($ripple);setTimeout(()=>$ripple.remove(),600)});if(!$('#acc-motor-ripple-keyframes').length){$('<style>',{id:'acc-motor-ripple-keyframes',html:'@keyframes motor-ripple { 100% { transform: translate(-50%, -50%) scale(4); opacity: 0; } }'}).appendTo('head')}}}applyDisableDrag(){$('#acc-motor-drag-style').remove();$(document).off('dragstart.motorDrag');if(this.settings.disableDrag){const css=` body * { user-select: none !important; -webkit-user-drag: none !important; } input, textarea { user-select: text !important; }`;$('<style>',{id:'acc-motor-drag-style',html:css}).appendTo('head');$(document).on('dragstart.motorDrag',()=>false)}}applyStickyFocus(){$('#acc-motor-focus-style').remove();if(this.settings.stickyFocus){const css=` :is(a, button, input, select, textarea, [tabindex]):focus { outline: 3px solid #2196f3 !important; outline-offset: 2px !important; }`;$('<style>',{id:'acc-motor-focus-style',html:css}).appendTo('head')}}

        removeAllSettings() {
            $('#acc-motor-clickareas-style, #acc-motor-hover-style, #acc-motor-cursor-style, #acc-motor-highlight, #acc-motor-drag-style, #acc-motor-focus-style').remove();
            $(document).off('.motorDelay .motorDouble .motorFeedback .motorHighlight .motorDrag');
        }

        reset() {
            if (confirm('Réinitialiser tous les paramètres de contrôle moteur ?')) {
                this.settings = this.getDefaultSettings();
                this.updateUI();
                this.applyAllSettings();
                this.saveAllSettings();
                this.announce('Paramètres réinitialisés');
            }
        }

        updateUI() {
            this.clickAreasSlider.val(this.settings.clickAreas);
            this.disableHoverCheckbox.prop('checked', this.settings.disableHover);
            this.clickDelaySlider.val(this.settings.clickDelay);
            this.preventDoubleCheckbox.prop('checked', this.settings.preventDouble);
            this.cursorSizeSlider.val(this.settings.cursorSize);
            this.cursorHighlightCheckbox.prop('checked', this.settings.cursorHighlight);
            this.clickFeedbackCheckbox.prop('checked', this.settings.clickFeedback);
            this.disableDragCheckbox.prop('checked', this.settings.disableDrag);
            this.stickyFocusCheckbox.prop('checked', this.settings.stickyFocus);
            $('#acc-motor-click-areas-value').text(this.settings.clickAreas + 'px');
            $('#acc-motor-click-delay-value').text(this.settings.clickDelay + 'ms');
            $('#acc-motor-cursor-size-value').text(this.settings.cursorSize + 'x');
        }

        savePreference(key, value) {
            const date = new Date();
            date.setTime(date.getTime() + (365 * 24 * 60 * 60 * 1000));
            document.cookie = `acc_motor_${key}=${JSON.stringify(value)};expires=${date.toUTCString()};path=/;SameSite=Lax`;
        }

        getPreference(key, defaultValue) {
            const name = `acc_motor_${key}=`;
            const ca = decodeURIComponent(document.cookie).split(';');
            for (let c of ca) {
                c = c.trim();
                if (c.indexOf(name) === 0) {
                    try { return JSON.parse(c.substring(name.length)); } catch (e) { return c.substring(name.length); }
                }
            }
            return defaultValue;
        }

        loadSettings() {
            this.isActive = this.getPreference('active', false);
            this.settings.clickAreas = this.getPreference('large_click_areas', 0);
            this.settings.disableHover = this.getPreference('disable_hover', false);
            this.settings.clickDelay = this.getPreference('click_delay', 0);
            this.settings.preventDouble = this.getPreference('prevent_double_click', false);
            this.settings.cursorSize = this.getPreference('large_cursor', 1);
            this.settings.cursorHighlight = this.getPreference('cursor_highlight', false);
            this.settings.clickFeedback = this.getPreference('click_feedback', false);
            this.settings.disableDrag = this.getPreference('disable_drag', false);
            this.settings.stickyFocus = this.getPreference('sticky_focus', false);
            
            this.toggle.prop('checked', this.isActive);
            if (this.isActive) this.content.show(); else this.content.hide();
        }

        saveAllSettings() {
            this.savePreference('active', this.isActive);
            const keyMap = { clickAreas: 'large_click_areas', preventDouble: 'prevent_double_click', cursorSize: 'large_cursor' };
            for (const key in this.settings) {
                const cookieKey = keyMap[key] || key.replace(/([A-Z])/g, '_$1').toLowerCase();
                this.savePreference(cookieKey, this.settings[key]);
            }
        }

        announce(message) {
            let $announcer = $('#acc-screen-reader-announcer');
            if (!$announcer.length) {
                $announcer = $('<div>', {
                    id: 'acc-screen-reader-announcer', 'aria-live': 'polite', 'aria-atomic': 'true',
                    css: { position: 'absolute', left: '-10000px', width: '1px', height: '1px', overflow: 'hidden' }
                }).appendTo('body');
            }
            $announcer.text('').text(message);
        }
    }

    $(document).ready(() => {
        if ($('#acc-module-motor').length) {
            window.accMotorModule = new MotorModule();
        }
    });

})(jQuery);