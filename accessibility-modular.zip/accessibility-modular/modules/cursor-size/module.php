<?php
/**
 * Module: Taille du Curseur
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Classe du module Taille du Curseur
 */
class ACC_Cursor_Size_Module {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Le module est enregistré, pas besoin de hooks ici
        // Les assets sont chargés par le plugin principal
    }
    
    /**
     * Retourne les informations du module
     */
    public static function get_info() {
        return [
            'name' => 'cursor-size',
            'title' => 'Taille du curseur',
            'description' => 'Agrandissez le curseur de la souris pour améliorer sa visibilité',
            'version' => '1.0.0',
            'icon' => '🖱️',
            'category' => 'mobilite',
            'enabled' => true
        ];
    }
    
    /**
     * Rendu du template
     */
    public static function render() {
        include dirname(__FILE__) . '/template.php';
    }
}

// Initialiser le module
ACC_Cursor_Size_Module::get_instance();