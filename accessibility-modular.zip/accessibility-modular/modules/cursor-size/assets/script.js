/**
 * Module Taille du Curseur - JavaScript (VERSION AUTONOME)
 * Gestion de l'agrandissement et personnalisation du curseur
 * Version: 1.0.0
 * 
 * IMPORTANT: Utilise uniquement les cookies (pas localStorage)
 */

(function($) {
    'use strict';

    /**
     * Classe du module Taille du Curseur
     */
    class CursorSizeModule {
        constructor() {
            this.module = $('#acc-module-cursor-size');
            this.toggle = $('#acc-cursor-size-toggle');
            this.content = $('#acc-cursor-size-content');
            this.presetButtons = $('.acc-cursor-preset');
            this.sizeSlider = $('#acc-cursor-custom-size');
            this.styleSelect = $('#acc-cursor-style');
            this.colorInput = $('#acc-cursor-color');
            this.outlineToggle = $('#acc-cursor-outline');
            this.trailToggle = $('#acc-cursor-trail');
            this.resetBtn = $('#acc-cursor-size-reset');
            this.testArea = $('#acc-cursor-test-area');
            
            this.settings = this.getDefaultSettings();
            this.isActive = false;
            this.trailDots = [];
            this.trailInterval = null;
            
            this.init();
        }

        /**
         * Initialisation
         */
        init() {
            this.loadSettings();
            this.bindEvents();
            this.updateUI();
            
            // Applique les paramètres sauvegardés
            if (this.isActive) {
                this.applyAllSettings();
            }
            
            console.log('✓ Module Taille du Curseur initialisé', this.settings);
        }

        /**
         * Paramètres par défaut
         */
        getDefaultSettings() {
            return {
                size: 1,
                preset: 'normal',
                style: 'arrow',
                color: '#000000',
                outline: true,
                trail: false
            };
        }

        /**
         * Liaison des événements
         */
        bindEvents() {
            // Toggle du module
            this.toggle.on('change', () => this.handleToggle());
            
            // Presets
            this.presetButtons.on('click', (e) => this.handlePresetClick(e));
            
            // Taille personnalisée
            this.sizeSlider.on('input', () => this.handleSizeChange());
            
            // Style
            this.styleSelect.on('change', () => this.handleStyleChange());
            
            // Couleur
            this.colorInput.on('input change', () => this.handleColorChange());
            
            // Contour
            this.outlineToggle.on('change', () => this.handleOutlineChange());
            
            // Traînée
            this.trailToggle.on('change', () => this.handleTrailChange());
            
            // Réinitialisation
            this.resetBtn.on('click', () => this.reset());
        }

        /**
         * Gère l'activation/désactivation du module
         */
        handleToggle() {
            this.isActive = this.toggle.is(':checked');
            
            if (this.isActive) {
                this.content.slideDown(300);
                this.applyAllSettings();
                this.savePreference('active', true);
                this.announce('Module taille du curseur activé');
                console.log('✓ Module taille du curseur activé');
            } else {
                this.content.slideUp(300);
                this.removeAllSettings();
                this.savePreference('active', false);
                this.announce('Module taille du curseur désactivé');
                console.log('✓ Module taille du curseur désactivé');
            }
        }

        /**
         * Gère le clic sur un preset
         */
        handlePresetClick(e) {
            const $button = $(e.currentTarget);
            const size = parseFloat($button.data('size'));
            const preset = $button.data('preset');
            
            this.settings.size = size;
            this.settings.preset = preset;
            
            this.sizeSlider.val(size);
            this.presetButtons.removeClass('active');
            $button.addClass('active');
            
            this.updateSizeDisplay();
            this.applyCursor();
            this.savePreference('size', size);
            this.savePreference('preset', preset);
            
            this.announce(`Taille ${preset} appliquée : ${size}×`);
            console.log(`Preset appliqué: ${preset} (${size}×)`);
        }

        /**
         * Gère le changement de taille personnalisée
         */
        handleSizeChange() {
            this.settings.size = parseFloat(this.sizeSlider.val());
            this.settings.preset = 'custom';
            
            this.presetButtons.removeClass('active');
            this.updateSizeDisplay();
            this.applyCursor();
            this.savePreference('size', this.settings.size);
            this.savePreference('preset', 'custom');
            
            console.log(`Taille personnalisée: ${this.settings.size}×`);
        }

        /**
         * Gère le changement de style
         */
        handleStyleChange() {
            this.settings.style = this.styleSelect.val();
            
            this.applyCursor();
            this.savePreference('style', this.settings.style);
            
            this.announce(`Style changé en ${this.settings.style}`);
            console.log(`Style changé: ${this.settings.style}`);
        }

        /**
         * Gère le changement de couleur
         */
        handleColorChange() {
            this.settings.color = this.colorInput.val();
            
            $('#acc-cursor-color-value').text(this.settings.color);
            this.applyCursor();
            this.savePreference('color', this.settings.color);
            
            console.log(`Couleur changée: ${this.settings.color}`);
        }

        /**
         * Gère l'activation/désactivation du contour
         */
        handleOutlineChange() {
            this.settings.outline = this.outlineToggle.is(':checked');
            
            this.applyCursor();
            this.savePreference('outline', this.settings.outline);
            
            console.log(`Contour: ${this.settings.outline}`);
        }

        /**
         * Gère l'activation/désactivation de la traînée
         */
        handleTrailChange() {
            this.settings.trail = this.trailToggle.is(':checked');
            
            if (this.settings.trail) {
                this.startTrail();
            } else {
                this.stopTrail();
            }
            
            this.savePreference('trail', this.settings.trail);
            
            console.log(`Traînée: ${this.settings.trail}`);
        }

        /**
         * Met à jour l'affichage de la taille
         */
        updateSizeDisplay() {
            $('#acc-cursor-size-value').text(this.settings.size + '×');
            this.sizeSlider.attr('aria-valuenow', this.settings.size)
                          .attr('aria-valuetext', this.settings.size + ' fois');
        }

        /**
         * Applique tous les paramètres
         */
        applyAllSettings() {
            this.applyCursor();
            
            if (this.settings.trail) {
                this.startTrail();
            }
            
            console.log('✓ Tous les paramètres appliqués', this.settings);
        }

        /**
         * Applique le curseur personnalisé
         */
        applyCursor() {
            const cursorUrl = this.generateCursorSVG();
            const hotspot = this.getCursorHotspot();
            
            const css = `
                * {
                    cursor: url('${cursorUrl}') ${hotspot.x} ${hotspot.y}, auto !important;
                }
                
                a, button, input[type="button"], input[type="submit"], [role="button"] {
                    cursor: url('${cursorUrl}') ${hotspot.x} ${hotspot.y}, pointer !important;
                }
            `;
            
            // Supprimer l'ancien style
            $('#acc-cursor-style-tag').remove();
            
            // Ajouter le nouveau style
            $('<style>', {
                id: 'acc-cursor-style-tag',
                html: css
            }).appendTo('head');
            
            console.log('✓ Curseur appliqué:', {
                size: this.settings.size,
                style: this.settings.style,
                color: this.settings.color,
                outline: this.settings.outline
            });
        }

        /**
         * Génère un curseur SVG personnalisé
         */
        generateCursorSVG() {
            const baseSize = 24;
            const size = Math.round(baseSize * this.settings.size);
            let svg = '';
            
            const color = this.settings.color;
            const stroke = this.settings.outline ? 'white' : 'none';
            const strokeWidth = this.settings.outline ? 2 : 0;
            
            switch (this.settings.style) {
                case 'arrow':
                    svg = `
                        <svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24">
                            <path d="M3 3 L3 17 L9 11 L12 17 L14 16 L11 10 L17 10 Z" 
                                  fill="${color}" 
                                  stroke="${stroke}" 
                                  stroke-width="${strokeWidth}"
                                  stroke-linejoin="round"/>
                        </svg>
                    `;
                    break;
                    
                case 'pointer':
                    svg = `
                        <svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24">
                            <path d="M9 3 L9 10 L5 10 L5 14 L9 14 L9 21 L13 21 L13 14 L16 14 L16 10 L13 10 L13 3 Z" 
                                  fill="${color}" 
                                  stroke="${stroke}" 
                                  stroke-width="${strokeWidth}"/>
                        </svg>
                    `;
                    break;
                    
                case 'cross':
                    svg = `
                        <svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24">
                            <line x1="12" y1="2" x2="12" y2="22" stroke="${color}" stroke-width="3"/>
                            <line x1="2" y1="12" x2="22" y2="12" stroke="${color}" stroke-width="3"/>
                            ${this.settings.outline ? `
                                <line x1="12" y1="2" x2="12" y2="22" stroke="white" stroke-width="5" opacity="0.5"/>
                                <line x1="2" y1="12" x2="22" y2="12" stroke="white" stroke-width="5" opacity="0.5"/>
                            ` : ''}
                            <circle cx="12" cy="12" r="3" fill="${color}" stroke="${stroke}" stroke-width="${strokeWidth}"/>
                        </svg>
                    `;
                    break;
                    
                case 'circle':
                    svg = `
                        <svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="9" 
                                    fill="${color}" 
                                    stroke="${stroke}" 
                                    stroke-width="${strokeWidth * 2}"/>
                        </svg>
                    `;
                    break;
            }
            
            // Encoder le SVG en data URL
            const encoded = encodeURIComponent(svg.trim())
                .replace(/'/g, '%27')
                .replace(/"/g, '%22');
            
            return `data:image/svg+xml,${encoded}`;
        }

        /**
         * Retourne le point chaud du curseur (hotspot)
         */
        getCursorHotspot() {
            const baseSize = 24;
            const size = Math.round(baseSize * this.settings.size);
            
            switch (this.settings.style) {
                case 'arrow':
                    return { x: Math.round(size * 0.1), y: Math.round(size * 0.1) };
                case 'pointer':
                    return { x: Math.round(size * 0.5), y: Math.round(size * 0.2) };
                case 'cross':
                case 'circle':
                    return { x: Math.round(size * 0.5), y: Math.round(size * 0.5) };
                default:
                    return { x: 0, y: 0 };
            }
        }

        /**
         * Démarre l'effet de traînée
         */
        startTrail() {
            if (this.trailInterval) return;
            
            // Créer le conteneur de traînée
            if (!$('#acc-cursor-trail-container').length) {
                $('<div>', {
                    id: 'acc-cursor-trail-container',
                    css: {
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        pointerEvents: 'none',
                        zIndex: 999999
                    }
                }).appendTo('body');
            }
            
            // Suivre le curseur
            $(document).on('mousemove.cursortrail', (e) => {
                this.addTrailDot(e.clientX, e.clientY);
            });
            
            console.log('✓ Traînée activée');
        }

        /**
         * Ajoute un point de traînée
         */
        addTrailDot(x, y) {
            const $dot = $('<div>', {
                class: 'acc-cursor-trail-dot',
                css: {
                    position: 'fixed',
                    left: x + 'px',
                    top: y + 'px',
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    background: this.settings.color,
                    opacity: 0.6,
                    transform: 'translate(-50%, -50%)',
                    pointerEvents: 'none',
                    transition: 'opacity 0.5s'
                }
            });
            
            $('#acc-cursor-trail-container').append($dot);
            
            // Fade out et suppression
            setTimeout(() => {
                $dot.css('opacity', 0);
                setTimeout(() => $dot.remove(), 500);
            }, 100);
        }

        /**
         * Arrête l'effet de traînée
         */
        stopTrail() {
            $(document).off('mousemove.cursortrail');
            $('#acc-cursor-trail-container').remove();
            console.log('✓ Traînée désactivée');
        }

        /**
         * Supprime tous les paramètres
         */
        removeAllSettings() {
            $('#acc-cursor-style-tag').remove();
            this.stopTrail();
            console.log('✓ Tous les styles supprimés');
        }

        /**
         * Réinitialise tous les paramètres
         */
        reset() {
            if (confirm('Réinitialiser tous les paramètres du curseur ?')) {
                this.settings = this.getDefaultSettings();
                this.updateUI();
                this.applyAllSettings();
                this.saveAllSettings();
                this.announce('Paramètres du curseur réinitialisés');
                console.log('✓ Paramètres réinitialisés');
            }
        }

        /**
         * Met à jour l'interface
         */
        updateUI() {
            // Taille
            this.sizeSlider.val(this.settings.size);
            this.updateSizeDisplay();
            
            // Style
            this.styleSelect.val(this.settings.style);
            
            // Couleur
            this.colorInput.val(this.settings.color);
            $('#acc-cursor-color-value').text(this.settings.color);
            
            // Contour
            this.outlineToggle.prop('checked', this.settings.outline);
            
            // Traînée
            this.trailToggle.prop('checked', this.settings.trail);
            
            // Preset actif
            this.presetButtons.removeClass('active');
            if (this.settings.preset !== 'custom') {
                this.presetButtons.filter(`[data-preset="${this.settings.preset}"]`)
                                 .addClass('active');
            }
        }

        /**
         * Sauvegarde une préférence dans un cookie
         */
        savePreference(key, value) {
            const cookieName = `acc_cursor_${key}`;
            const cookieValue = JSON.stringify(value);
            const expiryDays = 365;
            const date = new Date();
            date.setTime(date.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
            const expires = "expires=" + date.toUTCString();
            
            document.cookie = `${cookieName}=${cookieValue};${expires};path=/;SameSite=Lax`;
        }

        /**
         * Récupère une préférence depuis un cookie
         */
        getPreference(key, defaultValue) {
            const cookieName = `acc_cursor_${key}`;
            const name = cookieName + "=";
            const decodedCookie = decodeURIComponent(document.cookie);
            const cookieArray = decodedCookie.split(';');
            
            for (let i = 0; i < cookieArray.length; i++) {
                let cookie = cookieArray[i].trim();
                if (cookie.indexOf(name) === 0) {
                    const value = cookie.substring(name.length, cookie.length);
                    try {
                        return JSON.parse(value);
                    } catch(e) {
                        return value;
                    }
                }
            }
            
            return defaultValue;
        }

        /**
         * Charge les paramètres sauvegardés
         */
        loadSettings() {
            this.isActive = this.getPreference('active', false);
            this.settings.size = this.getPreference('size', 1);
            this.settings.preset = this.getPreference('preset', 'normal');
            this.settings.style = this.getPreference('style', 'arrow');
            this.settings.color = this.getPreference('color', '#000000');
            this.settings.outline = this.getPreference('outline', true);
            this.settings.trail = this.getPreference('trail', false);
            
            this.toggle.prop('checked', this.isActive);
            if (this.isActive) {
                this.content.show();
            }
            
            console.log('✓ Paramètres chargés:', this.settings);
        }

        /**
         * Sauvegarde tous les paramètres
         */
        saveAllSettings() {
            this.savePreference('active', this.isActive);
            this.savePreference('size', this.settings.size);
            this.savePreference('preset', this.settings.preset);
            this.savePreference('style', this.settings.style);
            this.savePreference('color', this.settings.color);
            this.savePreference('outline', this.settings.outline);
            this.savePreference('trail', this.settings.trail);
        }

        /**
         * Annonce pour les lecteurs d'écran
         */
        announce(message) {
            let $announcer = $('#acc-screen-reader-announcer');
            if (!$announcer.length) {
                $announcer = $('<div>', {
                    id: 'acc-screen-reader-announcer',
                    'aria-live': 'polite',
                    'aria-atomic': 'true',
                    css: {
                        position: 'absolute',
                        left: '-10000px',
                        width: '1px',
                        height: '1px',
                        overflow: 'hidden'
                    }
                }).appendTo('body');
            }
            
            $announcer.text('');
            setTimeout(() => {
                $announcer.text(message);
            }, 100);
        }
    }

    /**
     * Initialisation
     */
    $(document).ready(function() {
        if ($('#acc-module-cursor-size').length) {
            window.accCursorModule = new CursorSizeModule();
            console.log('✓ Module Taille du Curseur prêt');
        }
    });

})(jQuery);