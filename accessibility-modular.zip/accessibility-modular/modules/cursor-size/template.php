<?php
/**
 * Template du module Taille du Curseur
 * Interface utilisateur pour l'agrandissement du curseur de la souris
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="acc-module acc-module-cursor-size" id="acc-module-cursor-size" data-module="cursor-size">
    <div class="acc-module-header">
        <h3 class="acc-module-title">
            <span class="acc-module-icon" aria-hidden="true">🖱️</span>
            <?php esc_html_e('Taille du curseur', 'accessibility-modular'); ?>
        </h3>
        <label class="acc-module-toggle">
            <input 
                type="checkbox" 
                id="acc-cursor-size-toggle"
                aria-label="<?php esc_attr_e('Activer/désactiver le module taille du curseur', 'accessibility-modular'); ?>"
            />
            <span class="acc-module-toggle-slider"></span>
        </label>
    </div>

    <div class="acc-module-content" id="acc-cursor-size-content" style="display: none;">
        
        <!-- Tailles prédéfinies -->
        <div class="acc-control-group">
            <label class="acc-control-label">
                <?php esc_html_e('Taille prédéfinie', 'accessibility-modular'); ?>
            </label>
            <div class="acc-button-group">
                <button 
                    type="button" 
                    class="acc-button acc-cursor-preset active" 
                    data-size="1"
                    data-preset="normal"
                    aria-label="<?php esc_attr_e('Normal - Taille par défaut', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Normal', 'accessibility-modular'); ?>
                </button>

                <button 
                    type="button" 
                    class="acc-button acc-cursor-preset" 
                    data-size="1.5"
                    data-preset="large"
                    aria-label="<?php esc_attr_e('Grand - 1.5× plus grand', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Grand', 'accessibility-modular'); ?>
                </button>

                <button 
                    type="button" 
                    class="acc-button acc-cursor-preset" 
                    data-size="2"
                    data-preset="xlarge"
                    aria-label="<?php esc_attr_e('Très grand - 2× plus grand', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Très grand', 'accessibility-modular'); ?>
                </button>
            </div>

            <div class="acc-button-group" style="margin-top: 8px;">
                <button 
                    type="button" 
                    class="acc-button acc-cursor-preset" 
                    data-size="3"
                    data-preset="xxlarge"
                    aria-label="<?php esc_attr_e('Extra large - 3× plus grand', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Extra large', 'accessibility-modular'); ?>
                </button>
            </div>
        </div>

        <!-- Taille personnalisée -->
        <div class="acc-control-group">
            <label for="acc-cursor-custom-size" class="acc-control-label">
                <?php esc_html_e('Taille personnalisée', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-cursor-size-value">1×</span>
            </label>
            <input 
                type="range" 
                id="acc-cursor-custom-size" 
                class="acc-slider"
                min="1" 
                max="5" 
                step="0.5" 
                value="1"
                aria-label="<?php esc_attr_e('Ajuster la taille du curseur', 'accessibility-modular'); ?>"
                aria-valuemin="1"
                aria-valuemax="5"
                aria-valuenow="1"
                aria-valuetext="1 fois"
            />
        </div>

        <!-- Style de curseur -->
        <div class="acc-control-group">
            <label for="acc-cursor-style" class="acc-control-label">
                <?php esc_html_e('Style de curseur', 'accessibility-modular'); ?>
            </label>
            <select 
                id="acc-cursor-style" 
                class="acc-select"
                aria-label="<?php esc_attr_e('Sélectionner un style de curseur', 'accessibility-modular'); ?>"
            >
                <option value="arrow"><?php esc_html_e('Flèche classique', 'accessibility-modular'); ?></option>
                <option value="pointer"><?php esc_html_e('Main (pointeur)', 'accessibility-modular'); ?></option>
                <option value="cross"><?php esc_html_e('Croix de précision', 'accessibility-modular'); ?></option>
                <option value="circle"><?php esc_html_e('Cercle plein', 'accessibility-modular'); ?></option>
            </select>
        </div>

        <!-- Couleur du curseur -->
        <div class="acc-control-group">
            <label for="acc-cursor-color" class="acc-control-label">
                <?php esc_html_e('Couleur du curseur', 'accessibility-modular'); ?>
            </label>
            <div style="display: flex; align-items: center; gap: 10px;">
                <input 
                    type="color" 
                    id="acc-cursor-color"
                    value="#000000"
                    style="width: 60px; height: 40px; border: 2px solid var(--acc-border); border-radius: 6px; cursor: pointer;"
                    aria-label="<?php esc_attr_e('Couleur du curseur', 'accessibility-modular'); ?>"
                />
                <span id="acc-cursor-color-value" style="font-size: 12px; color: var(--acc-text-muted); font-family: monospace;">#000000</span>
            </div>
        </div>

        <!-- Contour blanc -->
        <div class="acc-control-group">
            <div class="acc-feature-item" style="display: flex; justify-content: space-between; align-items: center;">
                <label for="acc-cursor-outline" class="acc-control-label">
                    <?php esc_html_e('Contour blanc', 'accessibility-modular'); ?>
                </label>
                <label class="acc-module-toggle">
                    <input 
                        type="checkbox" 
                        id="acc-cursor-outline"
                        checked
                        aria-label="<?php esc_attr_e('Activer le contour blanc', 'accessibility-modular'); ?>"
                    />
                    <span class="acc-module-toggle-slider"></span>
                </label>
            </div>
            <p class="acc-control-hint" style="font-size: 11px; color: var(--acc-text-muted); margin-top: 4px;">
                <?php esc_html_e('Améliore la visibilité sur fonds sombres', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Effet de traînée -->
        <div class="acc-control-group">
            <div class="acc-feature-item" style="display: flex; justify-content: space-between; align-items: center;">
                <label for="acc-cursor-trail" class="acc-control-label">
                    <?php esc_html_e('Effet de traînée', 'accessibility-modular'); ?>
                </label>
                <label class="acc-module-toggle">
                    <input 
                        type="checkbox" 
                        id="acc-cursor-trail"
                        aria-label="<?php esc_attr_e('Activer l\'effet de traînée', 'accessibility-modular'); ?>"
                    />
                    <span class="acc-module-toggle-slider"></span>
                </label>
            </div>
            <p class="acc-control-hint" style="font-size: 11px; color: var(--acc-text-muted); margin-top: 4px;">
                <?php esc_html_e('Laisse une traînée visuelle pour suivre le mouvement', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Zone d'aperçu -->
        <div class="acc-control-group" style="background: linear-gradient(135deg, #f5f5f5 0%, #e5e5e5 100%); padding: 40px 20px; border-radius: 8px; margin-top: 16px; position: relative; overflow: hidden;">
            <label class="acc-control-label" style="margin-bottom: 12px; display: block; text-align: center;">
                <?php esc_html_e('Zone de test', 'accessibility-modular'); ?>
            </label>
            <p style="text-align: center; color: var(--acc-text-muted); font-size: 13px;">
                <?php esc_html_e('Déplacez votre souris ici pour tester le curseur', 'accessibility-modular'); ?>
            </p>
            
            <!-- Grille de test avec différents fonds -->
            <div id="acc-cursor-test-area" style="margin-top: 20px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; min-height: 120px;">
                <div style="background: white; border: 2px dashed #ccc; border-radius: 4px; padding: 15px; display: flex; align-items: center; justify-content: center; font-size: 11px; color: #666;">
                    Fond clair
                </div>
                <div style="background: #333; border: 2px dashed #666; border-radius: 4px; padding: 15px; display: flex; align-items: center; justify-content: center; font-size: 11px; color: #ccc;">
                    Fond sombre
                </div>
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: 2px dashed rgba(255,255,255,0.3); border-radius: 4px; padding: 15px; display: flex; align-items: center; justify-content: center; font-size: 11px; color: white;">
                    Fond coloré
                </div>
            </div>
        </div>

        <!-- Bouton de réinitialisation -->
        <div class="acc-control-group" style="margin-top: 20px;">
            <div class="acc-button-group">
                <button 
                    type="button" 
                    id="acc-cursor-size-reset" 
                    class="acc-button"
                    aria-label="<?php esc_attr_e('Réinitialiser les paramètres du curseur', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Réinitialiser', 'accessibility-modular'); ?>
                </button>
            </div>
        </div>
    </div>
</div>