/**
 * Module Taille des Boutons - JavaScript (VERSION AUTONOME)
 * Gestion de l'ajustement de la taille des boutons
 * Version: 1.1.0
 * 
 * IMPORTANT: Utilise uniquement les cookies (pas localStorage)
 */

(function($) {
    'use strict';

    /**
     * Classe du module Taille des Boutons
     */
    class ButtonSizeModule {
        constructor() {
            this.module = $('#acc-module-button-size');
            this.toggle = $('#acc-button-size-toggle');
            this.content = $('#acc-button-size-content');
            this.presetButtons = $('.acc-button-preset');
            this.sizeSlider = $('#acc-button-custom-size');
            this.spacingSlider = $('#acc-button-spacing');
            this.resetBtn = $('#acc-button-size-reset');
            this.previewButtons = $('.acc-button-preview');
            
            this.settings = this.getDefaultSettings();
            this.isActive = false;
            
            this.init();
        }

        /**
         * Initialisation
         */
        init() {
            this.loadSettings();
            this.bindEvents();
            this.updateUI();
            this.updatePreview();
            
            // Applique les paramètres sauvegardés
            if (this.isActive) {
                this.applyAllSettings();
            }
            
            console.log('✓ Module Taille des Boutons initialisé', this.settings);
        }

        /**
         * Paramètres par défaut
         */
        getDefaultSettings() {
            return {
                size: 100,
                spacing: 8,
                preset: 'normal'
            };
        }

        /**
         * Liaison des événements
         */
        bindEvents() {
            // Toggle du module
            this.toggle.on('change', () => this.handleToggle());
            
            // Presets
            this.presetButtons.on('click', (e) => this.handlePresetClick(e));
            
            // Taille personnalisée
            this.sizeSlider.on('input', () => this.handleSizeChange());
            
            // Espacement
            this.spacingSlider.on('input', () => this.handleSpacingChange());
            
            // Réinitialisation
            this.resetBtn.on('click', () => this.reset());
        }

        /**
         * Gère l'activation/désactivation du module
         */
        handleToggle() {
            this.isActive = this.toggle.is(':checked');
            
            if (this.isActive) {
                this.content.slideDown(300);
                this.applyAllSettings();
                this.savePreference('active', true);
                this.announce('Module taille des boutons activé');
                console.log('✓ Module taille des boutons activé');
            } else {
                this.content.slideUp(300);
                this.removeAllSettings();
                this.savePreference('active', false);
                this.announce('Module taille des boutons désactivé');
                console.log('✓ Module taille des boutons désactivé');
            }
        }

        /**
         * Gère le clic sur un preset
         */
        handlePresetClick(e) {
            const $button = $(e.currentTarget);
            const size = parseInt($button.data('size'));
            const preset = $button.data('preset');
            
            this.settings.size = size;
            this.settings.preset = preset;
            
            this.sizeSlider.val(size);
            this.presetButtons.removeClass('active');
            $button.addClass('active');
            
            this.updateSizeDisplay();
            this.applySize();
            this.updatePreview();
            this.savePreference('size', size);
            this.savePreference('preset', preset);
            
            this.announce(`Taille ${preset} appliquée : ${size}%`);
            console.log(`Preset appliqué: ${preset} (${size}%)`);
        }

        /**
         * Gère le changement de taille personnalisée
         */
        handleSizeChange() {
            this.settings.size = parseInt(this.sizeSlider.val());
            this.settings.preset = 'custom';
            
            this.presetButtons.removeClass('active');
            this.updateSizeDisplay();
            this.applySize();
            this.updatePreview();
            this.savePreference('size', this.settings.size);
            this.savePreference('preset', 'custom');
            
            console.log(`Taille personnalisée: ${this.settings.size}%`);
        }

        /**
         * Gère le changement d'espacement
         */
        handleSpacingChange() {
            this.settings.spacing = parseInt(this.spacingSlider.val());
            
            $('#acc-button-spacing-value').text(this.settings.spacing + 'px');
            this.spacingSlider.attr('aria-valuenow', this.settings.spacing)
                             .attr('aria-valuetext', this.settings.spacing + ' pixels');
            
            this.applySpacing();
            this.updatePreview();
            this.savePreference('spacing', this.settings.spacing);
            
            console.log(`Espacement: ${this.settings.spacing}px`);
        }

        /**
         * Met à jour l'affichage de la taille
         */
        updateSizeDisplay() {
            $('#acc-button-size-value').text(this.settings.size + '%');
            this.sizeSlider.attr('aria-valuenow', this.settings.size)
                          .attr('aria-valuetext', this.settings.size + ' pourcent');
        }

        /**
         * Applique tous les paramètres
         */
        applyAllSettings() {
            this.applySize();
            this.applySpacing();
            console.log('✓ Tous les paramètres appliqués', this.settings);
        }

        /**
         * Applique la taille des boutons
         */
        applySize() {
            // Supprimer l'ancien style
            $('#acc-button-size-style').remove();
            
            const scale = this.settings.size / 100;
            const minSize = Math.ceil(44 / scale);
            
            const css = `
                button:not(.acc-widget button):not(.acc-widget *):not(.acc-button-preset):not(.acc-button-preview),
                input[type="button"]:not(.acc-widget input),
                input[type="submit"]:not(.acc-widget input),
                input[type="reset"]:not(.acc-widget input),
                a.button:not(.acc-widget a),
                a.btn:not(.acc-widget a),
                [role="button"]:not(.acc-widget [role="button"]),
                .wp-block-button__link,
                .wp-block-button a {
                    transform: scale(${scale}) !important;
                    transform-origin: center !important;
                    min-width: ${minSize}px !important;
                    min-height: ${minSize}px !important;
                }
            `;
            
            $('<style>', {
                id: 'acc-button-size-style',
                html: css
            }).appendTo('head');
            
            console.log(`✓ Taille appliquée: ${this.settings.size}% (scale: ${scale}, min: ${minSize}px)`);
        }

        /**
         * Applique l'espacement
         */
        applySpacing() {
            // Supprimer l'ancien style
            $('#acc-button-spacing-style').remove();
            
            const css = `
                button:not(.acc-widget button):not(.acc-widget *):not(.acc-button-preset):not(.acc-button-preview),
                input[type="button"]:not(.acc-widget input),
                input[type="submit"]:not(.acc-widget input),
                input[type="reset"]:not(.acc-widget input),
                a.button:not(.acc-widget a),
                a.btn:not(.acc-widget a),
                [role="button"]:not(.acc-widget [role="button"]),
                .wp-block-button__link,
                .wp-block-button a {
                    margin: ${this.settings.spacing}px !important;
                }
            `;
            
            $('<style>', {
                id: 'acc-button-spacing-style',
                html: css
            }).appendTo('head');
            
            console.log(`✓ Espacement appliqué: ${this.settings.spacing}px`);
        }

        /**
         * Supprime tous les paramètres
         */
        removeAllSettings() {
            $('#acc-button-size-style').remove();
            $('#acc-button-spacing-style').remove();
            this.updatePreview();
            console.log('✓ Tous les styles supprimés');
        }

        /**
         * Met à jour l'aperçu
         */
        updatePreview() {
            const scale = this.isActive ? (this.settings.size / 100) : 1;
            const spacing = this.isActive ? this.settings.spacing : 8;
            
            this.previewButtons.css({
                'transform': `scale(${scale})`,
                'margin': `${spacing}px`
            });
        }

        /**
         * Réinitialise tous les paramètres
         */
        reset() {
            if (confirm('Réinitialiser tous les paramètres de taille des boutons ?')) {
                this.settings = this.getDefaultSettings();
                this.updateUI();
                this.applyAllSettings();
                this.updatePreview();
                this.saveAllSettings();
                this.announce('Paramètres de taille des boutons réinitialisés');
                console.log('✓ Paramètres réinitialisés');
            }
        }

        /**
         * Met à jour l'interface
         */
        updateUI() {
            this.sizeSlider.val(this.settings.size);
            this.spacingSlider.val(this.settings.spacing);
            
            this.updateSizeDisplay();
            $('#acc-button-spacing-value').text(this.settings.spacing + 'px');
            
            // Active le bon preset
            this.presetButtons.removeClass('active');
            if (this.settings.preset !== 'custom') {
                this.presetButtons.filter(`[data-preset="${this.settings.preset}"]`)
                                 .addClass('active');
            }
        }

        /**
         * Sauvegarde une préférence dans un cookie
         */
        savePreference(key, value) {
            const cookieName = `acc_button_${key}`;
            const cookieValue = JSON.stringify(value);
            const expiryDays = 365;
            const date = new Date();
            date.setTime(date.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
            const expires = "expires=" + date.toUTCString();
            
            document.cookie = `${cookieName}=${cookieValue};${expires};path=/;SameSite=Lax`;
            
            console.log(`Cookie sauvegardé: ${cookieName} = ${cookieValue}`);
        }

        /**
         * Récupère une préférence depuis un cookie
         */
        getPreference(key, defaultValue) {
            const cookieName = `acc_button_${key}`;
            const name = cookieName + "=";
            const decodedCookie = decodeURIComponent(document.cookie);
            const cookieArray = decodedCookie.split(';');
            
            for (let i = 0; i < cookieArray.length; i++) {
                let cookie = cookieArray[i].trim();
                if (cookie.indexOf(name) === 0) {
                    const value = cookie.substring(name.length, cookie.length);
                    try {
                        return JSON.parse(value);
                    } catch(e) {
                        return value;
                    }
                }
            }
            
            return defaultValue;
        }

        /**
         * Charge les paramètres sauvegardés
         */
        loadSettings() {
            this.isActive = this.getPreference('active', false);
            this.settings.size = this.getPreference('size', 100);
            this.settings.spacing = this.getPreference('spacing', 8);
            this.settings.preset = this.getPreference('preset', 'normal');
            
            this.toggle.prop('checked', this.isActive);
            if (this.isActive) {
                this.content.show();
            }
            
            console.log('✓ Paramètres chargés:', this.settings);
        }

        /**
         * Sauvegarde tous les paramètres
         */
        saveAllSettings() {
            this.savePreference('active', this.isActive);
            this.savePreference('size', this.settings.size);
            this.savePreference('spacing', this.settings.spacing);
            this.savePreference('preset', this.settings.preset);
        }

        /**
         * Annonce pour les lecteurs d'écran
         */
        announce(message) {
            // Créer une région ARIA live si elle n'existe pas
            let $announcer = $('#acc-screen-reader-announcer');
            if (!$announcer.length) {
                $announcer = $('<div>', {
                    id: 'acc-screen-reader-announcer',
                    'aria-live': 'polite',
                    'aria-atomic': 'true',
                    css: {
                        position: 'absolute',
                        left: '-10000px',
                        width: '1px',
                        height: '1px',
                        overflow: 'hidden'
                    }
                }).appendTo('body');
            }
            
            // Effacer puis annoncer
            $announcer.text('');
            setTimeout(() => {
                $announcer.text(message);
            }, 100);
        }
    }

    /**
     * Initialisation
     */
    $(document).ready(function() {
        if ($('#acc-module-button-size').length) {
            window.accButtonModule = new ButtonSizeModule();
            console.log('✓ Module Taille des Boutons prêt');
        }
    });

})(jQuery);