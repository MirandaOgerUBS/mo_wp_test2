<?php
/**
 * Template du module Taille des Boutons
 * Interface utilisateur pour l'ajustement de la taille des boutons
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="acc-module acc-module-button-size" id="acc-module-button-size" data-module="button-size">
    <div class="acc-module-header">
        <h3 class="acc-module-title">
            <span class="acc-module-icon" aria-hidden="true">🔘</span>
            <?php esc_html_e('Taille des boutons', 'accessibility-modular'); ?>
        </h3>
        <label class="acc-module-toggle">
            <input 
                type="checkbox" 
                id="acc-button-size-toggle"
                aria-label="<?php esc_attr_e('Activer/désactiver le module taille des boutons', 'accessibility-modular'); ?>"
            />
            <span class="acc-module-toggle-slider"></span>
        </label>
    </div>

    <div class="acc-module-content" id="acc-button-size-content" style="display: none;">
        <!-- Tailles prédéfinies -->
        <div class="acc-control-group">
            <label class="acc-control-label">
                <?php esc_html_e('Taille prédéfinie', 'accessibility-modular'); ?>
            </label>
            <div class="acc-button-group">
                <button 
                    type="button" 
                    class="acc-button acc-button-preset active" 
                    data-size="80"
                    data-preset="small"
                    aria-label="<?php esc_attr_e('Petit - 80%', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Petit', 'accessibility-modular'); ?>
                </button>

                <button 
                    type="button" 
                    class="acc-button acc-button-preset" 
                    data-size="100"
                    data-preset="normal"
                    aria-label="<?php esc_attr_e('Normal - 100%', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Normal', 'accessibility-modular'); ?>
                </button>

                <button 
                    type="button" 
                    class="acc-button acc-button-preset" 
                    data-size="140"
                    data-preset="large"
                    aria-label="<?php esc_attr_e('Grand - 140% (recommandé)', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Grand', 'accessibility-modular'); ?>
                </button>
            </div>

            <div class="acc-button-group" style="margin-top: 8px;">
                <button 
                    type="button" 
                    class="acc-button acc-button-preset" 
                    data-size="180"
                    data-preset="xlarge"
                    aria-label="<?php esc_attr_e('Très grand - 180%', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Très grand', 'accessibility-modular'); ?>
                </button>
            </div>
        </div>

        <!-- Taille personnalisée -->
        <div class="acc-control-group">
            <label for="acc-button-custom-size" class="acc-control-label">
                <?php esc_html_e('Taille personnalisée', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-button-size-value">100%</span>
            </label>
            <input 
                type="range" 
                id="acc-button-custom-size" 
                class="acc-slider"
                min="80" 
                max="200" 
                step="10" 
                value="100"
                aria-label="<?php esc_attr_e('Ajuster la taille des boutons', 'accessibility-modular'); ?>"
                aria-valuemin="80"
                aria-valuemax="200"
                aria-valuenow="100"
                aria-valuetext="100 pourcent"
            />
            <p class="acc-control-hint" style="font-size: 11px; color: var(--acc-text-muted); margin-top: 4px;">
                <?php esc_html_e('Recommandation WCAG : minimum 44×44 pixels', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Espacement -->
        <div class="acc-control-group">
            <label for="acc-button-spacing" class="acc-control-label">
                <?php esc_html_e('Espacement entre boutons', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-button-spacing-value">8px</span>
            </label>
            <input 
                type="range" 
                id="acc-button-spacing" 
                class="acc-slider"
                min="4" 
                max="16" 
                step="2" 
                value="8"
                aria-label="<?php esc_attr_e('Ajuster l\'espacement entre les boutons', 'accessibility-modular'); ?>"
                aria-valuemin="4"
                aria-valuemax="16"
                aria-valuenow="8"
                aria-valuetext="8 pixels"
            />
        </div>

        <!-- Aperçu -->
        <div class="acc-control-group" style="background: var(--acc-surface); padding: 16px; border-radius: 8px; margin-top: 16px;">
            <label class="acc-control-label" style="margin-bottom: 12px;">
                <?php esc_html_e('Aperçu', 'accessibility-modular'); ?>
            </label>
            <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap;">
                <button 
                    type="button" 
                    class="acc-button-preview" 
                    style="padding: 8px 16px; background: var(--acc-primary); color: white; border: none; border-radius: 4px; cursor: pointer; transition: transform 0.2s;"
                >
                    <?php esc_html_e('Bouton 1', 'accessibility-modular'); ?>
                </button>
                <button 
                    type="button" 
                    class="acc-button-preview" 
                    style="padding: 8px 16px; background: var(--acc-primary); color: white; border: none; border-radius: 4px; cursor: pointer; transition: transform 0.2s;"
                >
                    <?php esc_html_e('Bouton 2', 'accessibility-modular'); ?>
                </button>
            </div>
        </div>

        <!-- Bouton de réinitialisation -->
        <div class="acc-control-group" style="margin-top: 20px;">
            <div class="acc-button-group">
                <button 
                    type="button" 
                    id="acc-button-size-reset" 
                    class="acc-button"
                    aria-label="<?php esc_attr_e('Réinitialiser les paramètres de taille des boutons', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Réinitialiser', 'accessibility-modular'); ?>
                </button>
            </div>
        </div>
    </div>
</div>