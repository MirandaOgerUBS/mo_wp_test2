<?php
/**
 * Module: Taille des Boutons
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Classe du module Taille des Boutons
 */
class ACC_Button_Size_Module {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Le module est enregistré, pas besoin de hooks ici
        // Les assets sont chargés par le plugin principal
    }
    
    /**
     * Retourne les informations du module
     */
    public static function get_info() {
        return [
            'name' => 'button-size',
            'title' => 'Taille des boutons',
            'description' => 'Ajustez la taille des boutons pour faciliter les interactions',
            'version' => '1.0.0',
            'icon' => '🔘',
            'category' => 'mobilite',
            'enabled' => true
        ];
    }
    
    /**
     * Rendu du template
     */
    public static function render() {
        include dirname(__FILE__) . '/template.php';
    }
}

// Initialiser le module
ACC_Button_Size_Module::get_instance();