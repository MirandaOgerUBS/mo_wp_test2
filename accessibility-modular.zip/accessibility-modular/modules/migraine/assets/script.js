/**
 * Module Soulagement Migraines - JavaScript
 * Réduit les déclencheurs visuels des migraines ophtalmiques
 * Version: 1.0.0
 * 
 * IMPORTANT: Utilise uniquement les cookies (pas localStorage)
 */

(function($) {
    'use strict';

    /**
     * Classe du module Soulagement Migraines
     */
    class MigraineModule {
        constructor() {
            this.module = $('#acc-module-migraine');
            this.toggle = $('#acc-migraine-toggle');
            this.content = $('#acc-migraine-content');
            
            // Contrôles
            this.darkModeCheckbox = $('#acc-migraine-dark-mode');
            this.brightnessSlider = $('#acc-migraine-brightness');
            this.blueLightSlider = $('#acc-migraine-blue-light');
            this.saturationSlider = $('#acc-migraine-saturation');
            this.contrastSlider = $('#acc-migraine-contrast');
            this.colorThemeSelect = $('#acc-migraine-color-theme');
            this.removePatternsCheckbox = $('#acc-migraine-remove-patterns');
            this.increaseSpacingCheckbox = $('#acc-migraine-increase-spacing');
            
            // Boutons presets
            this.presetMildBtn = $('#acc-migraine-preset-mild');
            this.presetModerateBtn = $('#acc-migraine-preset-moderate');
            this.presetStrongBtn = $('#acc-migraine-preset-strong');
            this.presetCrisisBtn = $('#acc-migraine-preset-crisis');
            this.resetBtn = $('#acc-migraine-reset');
            
            this.settings = this.getDefaultSettings();
            this.isActive = false;
            
            this.init();
        }

        /**
         * Initialisation
         */
        init() {
            this.loadSettings();
            this.bindEvents();
            this.updateUI();
            
            // Applique les paramètres sauvegardés
            if (this.isActive) {
                this.applyAllSettings();
            }
            
            console.log('✓ Module Soulagement Migraines initialisé', this.settings);
        }

        /**
         * Paramètres par défaut
         */
        getDefaultSettings() {
            return {
                darkMode: false,
                brightness: 100,
                blueLight: 0,
                saturation: 100,
                contrast: 100,
                colorTheme: 'none',
                removePatterns: false,
                increaseSpacing: false
            };
        }

        /**
         * Liaison des événements
         */
        bindEvents() {
            // Toggle du module
            this.toggle.on('change', () => this.handleToggle());
            
            // Contrôles
            this.darkModeCheckbox.on('change', () => this.handleDarkMode());
            this.brightnessSlider.on('input', () => this.handleBrightness());
            this.blueLightSlider.on('input', () => this.handleBlueLight());
            this.saturationSlider.on('input', () => this.handleSaturation());
            this.contrastSlider.on('input', () => this.handleContrast());
            this.colorThemeSelect.on('change', () => this.handleColorTheme());
            this.removePatternsCheckbox.on('change', () => this.handleRemovePatterns());
            this.increaseSpacingCheckbox.on('change', () => this.handleIncreaseSpacing());
            
            // Presets
            this.presetMildBtn.on('click', () => this.applyPreset('mild'));
            this.presetModerateBtn.on('click', () => this.applyPreset('moderate'));
            this.presetStrongBtn.on('click', () => this.applyPreset('strong'));
            this.presetCrisisBtn.on('click', () => this.applyPreset('crisis'));
            
            // Reset
            this.resetBtn.on('click', () => this.reset());
        }

        /**
         * Gère l'activation/désactivation du module
         */
        handleToggle() {
            this.isActive = this.toggle.is(':checked');
            
            if (this.isActive) {
                this.content.slideDown(300);
                this.applyAllSettings();
                this.savePreference('active', true);
                this.announce('Module soulagement migraines activé');
                console.log('✓ Soulagement migraines activé');
            } else {
                this.content.slideUp(300);
                this.removeAllSettings();
                this.savePreference('active', false);
                this.announce('Module soulagement migraines désactivé');
                console.log('✓ Soulagement migraines désactivé');
            }
        }

        /**
         * Gère le mode sombre
         */
        handleDarkMode() {
            this.settings.darkMode = this.darkModeCheckbox.is(':checked');
            this.applyDarkMode();
            this.savePreference('dark_mode', this.settings.darkMode);
            this.announce(this.settings.darkMode ? 'Mode sombre activé' : 'Mode sombre désactivé');
        }

        /**
         * Gère la luminosité
         */
        handleBrightness() {
            this.settings.brightness = parseInt(this.brightnessSlider.val());
            $('#acc-migraine-brightness-value').text(this.settings.brightness + '%');
            this.brightnessSlider.attr('aria-valuenow', this.settings.brightness)
                                .attr('aria-valuetext', this.settings.brightness + ' pourcent');
            this.applyFilters();
            this.savePreference('brightness', this.settings.brightness);
        }

        /**
         * Gère le filtre lumière bleue
         */
        handleBlueLight() {
            this.settings.blueLight = parseInt(this.blueLightSlider.val());
            $('#acc-migraine-blue-light-value').text(this.settings.blueLight + '%');
            this.blueLightSlider.attr('aria-valuenow', this.settings.blueLight)
                               .attr('aria-valuetext', this.settings.blueLight + ' pourcent');
            this.applyFilters();
            this.savePreference('blue_light_filter', this.settings.blueLight);
        }

        /**
         * Gère la saturation
         */
        handleSaturation() {
            this.settings.saturation = parseInt(this.saturationSlider.val());
            $('#acc-migraine-saturation-value').text(this.settings.saturation + '%');
            this.saturationSlider.attr('aria-valuenow', this.settings.saturation)
                                .attr('aria-valuetext', this.settings.saturation + ' pourcent');
            this.applyFilters();
            this.savePreference('saturation', this.settings.saturation);
        }

        /**
         * Gère le contraste
         */
        handleContrast() {
            this.settings.contrast = parseInt(this.contrastSlider.val());
            $('#acc-migraine-contrast-value').text(this.settings.contrast + '%');
            this.contrastSlider.attr('aria-valuenow', this.settings.contrast)
                              .attr('aria-valuetext', this.settings.contrast + ' pourcent');
            this.applyFilters();
            this.savePreference('contrast', this.settings.contrast);
        }

        /**
         * Gère le thème de couleur
         */
        handleColorTheme() {
            this.settings.colorTheme = this.colorThemeSelect.val();
            this.applyColorTheme();
            this.savePreference('color_theme', this.settings.colorTheme);
            this.announce('Thème changé en ' + this.settings.colorTheme);
        }

        /**
         * Gère la suppression des motifs
         */
        handleRemovePatterns() {
            this.settings.removePatterns = this.removePatternsCheckbox.is(':checked');
            this.applyRemovePatterns();
            this.savePreference('remove_patterns', this.settings.removePatterns);
            this.announce(this.settings.removePatterns ? 'Motifs supprimés' : 'Motifs restaurés');
        }

        /**
         * Gère l'augmentation de l'espacement
         */
        handleIncreaseSpacing() {
            this.settings.increaseSpacing = this.increaseSpacingCheckbox.is(':checked');
            this.applyIncreaseSpacing();
            this.savePreference('increase_spacing', this.settings.increaseSpacing);
            this.announce(this.settings.increaseSpacing ? 'Espacement augmenté' : 'Espacement normal');
        }

        /**
         * Applique tous les paramètres
         */
        applyAllSettings() {
            this.applyDarkMode();
            this.applyFilters();
            this.applyColorTheme();
            this.applyRemovePatterns();
            this.applyIncreaseSpacing();
            console.log('✓ Tous les réglages appliqués');
        }

        /**
         * Applique le mode sombre
         */
        applyDarkMode() {
            $('#acc-migraine-darkmode-style').remove();
            
            if (this.settings.darkMode) {
                const css = `
                    /* Mode sombre pour migraines */
                    html {
                        filter: invert(1) hue-rotate(180deg) !important;
                    }
                    
                    /* Exception pour les images et vidéos */
                    img, video, iframe, [style*="background-image"] {
                        filter: invert(1) hue-rotate(180deg) !important;
                    }
                    
                    /* Préserver les médias */
                    picture, figure {
                        filter: invert(1) hue-rotate(180deg) !important;
                    }
                `;
                
                $('<style>', {
                    id: 'acc-migraine-darkmode-style',
                    html: css
                }).appendTo('head');
                
                console.log('✓ Mode sombre appliqué');
            }
        }

        /**
         * Applique tous les filtres (luminosité, lumière bleue, saturation, contraste)
         */
        applyFilters() {
            $('#acc-migraine-filters-style').remove();
            
            // Calcul des filtres CSS
            const brightness = this.settings.brightness / 100;
            const saturation = this.settings.saturation / 100;
            const contrast = this.settings.contrast / 100;
            
            // Calcul du filtre lumière bleue (teinte orangée)
            const blueLightIntensity = this.settings.blueLight;
            const sepiaValue = blueLightIntensity / 100 * 0.3; // Max 30% sépia
            
            let filters = [];
            
            if (brightness !== 1) {
                filters.push(`brightness(${brightness})`);
            }
            
            if (saturation !== 1) {
                filters.push(`saturate(${saturation})`);
            }
            
            if (contrast !== 1) {
                filters.push(`contrast(${contrast})`);
            }
            
            if (blueLightIntensity > 0) {
                filters.push(`sepia(${sepiaValue})`);
                
                // Ajoute une teinte chaude
                const hueShift = -10; // Vers l'orange
                filters.push(`hue-rotate(${hueShift}deg)`);
            }
            
            if (filters.length > 0) {
                const css = `
                    /* Filtres visuels pour migraines */
                    html {
                        filter: ${filters.join(' ')} !important;
                    }
                `;
                
                $('<style>', {
                    id: 'acc-migraine-filters-style',
                    html: css
                }).appendTo('head');
                
                console.log('✓ Filtres appliqués:', filters.join(', '));
            }
        }

        /**
         * Applique le thème de couleur
         */
        applyColorTheme() {
            $('#acc-migraine-theme-style').remove();
            
            if (this.settings.colorTheme !== 'none') {
                let filterValue = '';
                
                switch (this.settings.colorTheme) {
                    case 'sepia':
                        filterValue = 'sepia(0.6)';
                        break;
                    case 'grayscale':
                        filterValue = 'grayscale(1)';
                        break;
                    case 'green':
                        filterValue = 'sepia(0.3) hue-rotate(60deg)';
                        break;
                    case 'blue':
                        filterValue = 'sepia(0.3) hue-rotate(180deg)';
                        break;
                }
                
                if (filterValue) {
                    const css = `
                        /* Thème de couleur apaisant */
                        html {
                            filter: ${filterValue} !important;
                        }
                    `;
                    
                    $('<style>', {
                        id: 'acc-migraine-theme-style',
                        html: css
                    }).appendTo('head');
                    
                    console.log('✓ Thème appliqué:', this.settings.colorTheme);
                }
            }
        }

        /**
         * Applique la suppression des motifs
         */
        applyRemovePatterns() {
            $('#acc-migraine-patterns-style').remove();
            
            if (this.settings.removePatterns) {
                const css = `
                    /* Suppression des motifs répétitifs */
                    * {
                        background-image: none !important;
                    }
                    
                    /* Garde les images réelles */
                    img, picture, figure {
                        background-image: unset !important;
                    }
                    
                    /* Remplace par couleur unie */
                    body, div, section, article, aside, header, footer, nav {
                        background-image: none !important;
                    }
                `;
                
                $('<style>', {
                    id: 'acc-migraine-patterns-style',
                    html: css
                }).appendTo('head');
                
                console.log('✓ Motifs supprimés');
            }
        }

        /**
         * Applique l'augmentation de l'espacement
         */
        applyIncreaseSpacing() {
            $('#acc-migraine-spacing-style').remove();
            
            if (this.settings.increaseSpacing) {
                const css = `
                    /* Augmentation de l'espace blanc - RESPONSIVE */
                    
                    /* Interligne augmenté */
                    body {
                        line-height: 1.8 !important;
                    }
                    
                    /* Espacement des paragraphes */
                    p {
                        margin-bottom: 2em !important;
                    }
                    
                    /* Espacement des titres */
                    h1, h2, h3, h4, h5, h6 {
                        margin-top: 2em !important;
                        margin-bottom: 1.5em !important;
                    }
                    
                    /* Espacement des listes */
                    li {
                        margin-bottom: 1em !important;
                    }
                    
                    /* Espacement entre sections - RESPONSIVE */
                    article, section, main {
                        margin-bottom: 3em !important;
                    }
                    
                    /* Padding intérieur - Adaptatif selon écran */
                    @media (min-width: 1024px) {
                        /* Desktop : espacement généreux */
                        article, section, main {
                            padding-top: 3em !important;
                            padding-bottom: 3em !important;
                        }
                        
                        .content, .entry-content, [class*="content"] {
                            padding-left: 2em !important;
                            padding-right: 2em !important;
                        }
                    }
                    
                    @media (min-width: 768px) and (max-width: 1023px) {
                        /* Tablette : espacement modéré */
                        article, section, main {
                            padding-top: 2em !important;
                            padding-bottom: 2em !important;
                        }
                        
                        .content, .entry-content, [class*="content"] {
                            padding-left: 1.5em !important;
                            padding-right: 1.5em !important;
                        }
                    }
                    
                    @media (max-width: 767px) {
                        /* Mobile : espacement réduit */
                        article, section, main {
                            padding-top: 1.5em !important;
                            padding-bottom: 1.5em !important;
                        }
                        
                        .content, .entry-content, [class*="content"] {
                            padding-left: 1em !important;
                            padding-right: 1em !important;
                        }
                        
                        /* Réduction sur mobile pour éviter débordement */
                        p {
                            margin-bottom: 1.5em !important;
                        }
                        
                        h1, h2, h3, h4, h5, h6 {
                            margin-top: 1.5em !important;
                            margin-bottom: 1em !important;
                        }
                    }
                    
                    /* Espacement entre éléments généraux */
                    .entry-content > *, 
                    .content > *, 
                    main > * {
                        margin-top: 1.5em !important;
                    }
                    
                    /* Éviter les espacements excessifs sur certains éléments */
                    img, video, iframe, canvas, svg {
                        margin-top: 2em !important;
                        margin-bottom: 2em !important;
                    }
                    
                    /* Préserver les grilles et flex */
                    [class*="grid"], 
                    [class*="flex"],
                    [style*="display: flex"],
                    [style*="display: grid"] {
                        padding: 0 !important;
                    }
                `;
                
                $('<style>', {
                    id: 'acc-migraine-spacing-style',
                    html: css
                }).appendTo('head');
                
                console.log('✓ Espacement augmenté (responsive)');
            }
        }

        /**
         * Applique un preset
         */
        applyPreset(presetName) {
            let preset = {};
            
            switch (presetName) {
                case 'mild': // Doux - symptômes légers
                    preset = {
                        darkMode: false,
                        brightness: 90,
                        blueLight: 20,
                        saturation: 80,
                        contrast: 95,
                        colorTheme: 'none',
                        removePatterns: false,
                        increaseSpacing: false
                    };
                    this.announce('Preset doux appliqué');
                    break;
                    
                case 'moderate': // Modéré - symptômes moyens
                    preset = {
                        darkMode: false,
                        brightness: 75,
                        blueLight: 40,
                        saturation: 60,
                        contrast: 90,
                        colorTheme: 'sepia',
                        removePatterns: true,
                        increaseSpacing: false
                    };
                    this.announce('Preset modéré appliqué');
                    break;
                    
                case 'strong': // Fort - symptômes sévères
                    preset = {
                        darkMode: true,
                        brightness: 60,
                        blueLight: 60,
                        saturation: 40,
                        contrast: 85,
                        colorTheme: 'sepia',
                        removePatterns: true,
                        increaseSpacing: true
                    };
                    this.announce('Preset fort appliqué');
                    break;
                    
                case 'crisis': // Crise - protection maximale
                    preset = {
                        darkMode: true,
                        brightness: 50,
                        blueLight: 80,
                        saturation: 20,
                        contrast: 80,
                        colorTheme: 'grayscale',
                        removePatterns: true,
                        increaseSpacing: true
                    };
                    this.announce('🚨 Preset crise appliqué - Protection maximale');
                    break;
            }
            
            // Applique le preset
            this.settings = preset;
            this.updateUI();
            this.applyAllSettings();
            this.saveAllSettings();
            
            console.log(`✓ Preset "${presetName}" appliqué`, preset);
        }

        /**
         * Supprime tous les paramètres
         */
        removeAllSettings() {
            $('#acc-migraine-darkmode-style').remove();
            $('#acc-migraine-filters-style').remove();
            $('#acc-migraine-theme-style').remove();
            $('#acc-migraine-patterns-style').remove();
            $('#acc-migraine-spacing-style').remove();
            
            console.log('✓ Tous les réglages supprimés');
        }

        /**
         * Réinitialise tous les paramètres
         */
        reset() {
            if (confirm('Réinitialiser tous les paramètres de soulagement migraines ?')) {
                this.settings = this.getDefaultSettings();
                this.updateUI();
                this.applyAllSettings();
                this.saveAllSettings();
                this.announce('Paramètres réinitialisés');
                console.log('✓ Paramètres réinitialisés');
            }
        }

        /**
         * Met à jour l'interface
         */
        updateUI() {
            this.darkModeCheckbox.prop('checked', this.settings.darkMode);
            this.brightnessSlider.val(this.settings.brightness);
            this.blueLightSlider.val(this.settings.blueLight);
            this.saturationSlider.val(this.settings.saturation);
            this.contrastSlider.val(this.settings.contrast);
            this.colorThemeSelect.val(this.settings.colorTheme);
            this.removePatternsCheckbox.prop('checked', this.settings.removePatterns);
            this.increaseSpacingCheckbox.prop('checked', this.settings.increaseSpacing);
            
            // Met à jour les valeurs affichées
            $('#acc-migraine-brightness-value').text(this.settings.brightness + '%');
            $('#acc-migraine-blue-light-value').text(this.settings.blueLight + '%');
            $('#acc-migraine-saturation-value').text(this.settings.saturation + '%');
            $('#acc-migraine-contrast-value').text(this.settings.contrast + '%');
        }

        /**
         * Sauvegarde une préférence
         */
        savePreference(key, value) {
            const cookieName = `acc_migraine_${key}`;
            const cookieValue = JSON.stringify(value);
            const expiryDays = 365;
            const date = new Date();
            date.setTime(date.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
            const expires = "expires=" + date.toUTCString();
            
            document.cookie = `${cookieName}=${cookieValue};${expires};path=/;SameSite=Lax`;
        }

        /**
         * Récupère une préférence
         */
        getPreference(key, defaultValue) {
            const cookieName = `acc_migraine_${key}`;
            const name = cookieName + "=";
            const decodedCookie = decodeURIComponent(document.cookie);
            const cookieArray = decodedCookie.split(';');
            
            for (let i = 0; i < cookieArray.length; i++) {
                let cookie = cookieArray[i].trim();
                if (cookie.indexOf(name) === 0) {
                    const value = cookie.substring(name.length, cookie.length);
                    try {
                        return JSON.parse(value);
                    } catch(e) {
                        return value;
                    }
                }
            }
            
            return defaultValue;
        }

        /**
         * Charge les paramètres
         */
        loadSettings() {
            this.isActive = this.getPreference('active', false);
            this.settings.darkMode = this.getPreference('dark_mode', false);
            this.settings.brightness = this.getPreference('brightness', 100);
            this.settings.blueLight = this.getPreference('blue_light_filter', 0);
            this.settings.saturation = this.getPreference('saturation', 100);
            this.settings.contrast = this.getPreference('contrast', 100);
            this.settings.colorTheme = this.getPreference('color_theme', 'none');
            this.settings.removePatterns = this.getPreference('remove_patterns', false);
            this.settings.increaseSpacing = this.getPreference('increase_spacing', false);
            
            this.toggle.prop('checked', this.isActive);
            if (this.isActive) {
                this.content.show();
            }
            
            console.log('✓ Paramètres chargés:', this.settings);
        }

        /**
         * Sauvegarde tous les paramètres
         */
        saveAllSettings() {
            this.savePreference('active', this.isActive);
            this.savePreference('dark_mode', this.settings.darkMode);
            this.savePreference('brightness', this.settings.brightness);
            this.savePreference('blue_light_filter', this.settings.blueLight);
            this.savePreference('saturation', this.settings.saturation);
            this.savePreference('contrast', this.settings.contrast);
            this.savePreference('color_theme', this.settings.colorTheme);
            this.savePreference('remove_patterns', this.settings.removePatterns);
            this.savePreference('increase_spacing', this.settings.increaseSpacing);
        }

        /**
         * Annonce pour les lecteurs d'écran
         */
        announce(message) {
            let $announcer = $('#acc-screen-reader-announcer');
            if (!$announcer.length) {
                $announcer = $('<div>', {
                    id: 'acc-screen-reader-announcer',
                    'aria-live': 'polite',
                    'aria-atomic': 'true',
                    css: {
                        position: 'absolute',
                        left: '-10000px',
                        width: '1px',
                        height: '1px',
                        overflow: 'hidden'
                    }
                }).appendTo('body');
            }
            
            $announcer.text('');
            setTimeout(() => {
                $announcer.text(message);
            }, 100);
        }
    }

    /**
     * Initialisation
     */
    $(document).ready(function() {
        if ($('#acc-module-migraine').length) {
            window.accMigraineModule = new MigraineModule();
            console.log('✓ Module Soulagement Migraines prêt');
        }
    });

})(jQuery);