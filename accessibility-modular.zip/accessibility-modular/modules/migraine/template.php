<?php
/**
 * Template du module Soulagement Migraines
 * Interface utilisateur pour réduire les déclencheurs visuels
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="acc-module acc-module-migraine" id="acc-module-migraine" data-module="migraine">
    <div class="acc-module-header">
        <h3 class="acc-module-title">
            <span class="acc-module-icon" aria-hidden="true">🧠</span>
            <?php esc_html_e('Soulagement Migraines', 'accessibility-modular'); ?>
        </h3>
        <label class="acc-module-toggle">
            <input 
                type="checkbox" 
                id="acc-migraine-toggle"
                aria-label="<?php esc_attr_e('Activer/désactiver le soulagement migraines', 'accessibility-modular'); ?>"
            />
            <span class="acc-module-toggle-slider"></span>
        </label>
    </div>

    <div class="acc-module-content" id="acc-migraine-content" style="display: none;">
        
        <!-- Information médicale -->
        <div class="acc-info-box" style="background: #e3f2fd; border-left: 4px solid #2196f3; padding: 12px; margin-bottom: 20px; border-radius: 4px;">
            <p style="margin: 0; font-size: 13px; color: #1565c0;">
                <strong>ℹ️ <?php esc_html_e('À savoir', 'accessibility-modular'); ?> :</strong>
                <?php esc_html_e('Ces réglages réduisent les déclencheurs visuels courants des migraines ophtalmiques : lumière intense, couleurs vives, motifs répétitifs.', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Mode sombre -->
        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-migraine-dark-mode" 
                    class="acc-checkbox"
                    aria-describedby="acc-migraine-dark-desc"
                />
                <span><?php esc_html_e('Mode sombre', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-migraine-dark-desc" class="acc-control-description">
                <?php esc_html_e('Inverse les couleurs pour réduire la luminosité globale', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Luminosité -->
        <div class="acc-control-group">
            <label for="acc-migraine-brightness" class="acc-control-label">
                <?php esc_html_e('Luminosité', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-migraine-brightness-value">100%</span>
            </label>
            <input 
                type="range" 
                id="acc-migraine-brightness" 
                class="acc-slider"
                min="50" 
                max="100" 
                step="5" 
                value="100"
                aria-label="<?php esc_attr_e('Ajuster la luminosité', 'accessibility-modular'); ?>"
                aria-valuemin="50"
                aria-valuemax="100"
                aria-valuenow="100"
                aria-valuetext="100 pourcent"
            />
            <p class="acc-control-description">
                <?php esc_html_e('Réduit l\'intensité lumineuse de l\'écran', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Filtre lumière bleue -->
        <div class="acc-control-group">
            <label for="acc-migraine-blue-light" class="acc-control-label">
                <?php esc_html_e('Filtre lumière bleue', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-migraine-blue-light-value">0%</span>
            </label>
            <input 
                type="range" 
                id="acc-migraine-blue-light" 
                class="acc-slider"
                min="0" 
                max="100" 
                step="10" 
                value="0"
                aria-label="<?php esc_attr_e('Ajuster le filtre de lumière bleue', 'accessibility-modular'); ?>"
                aria-valuemin="0"
                aria-valuemax="100"
                aria-valuenow="0"
                aria-valuetext="0 pourcent"
            />
            <p class="acc-control-description">
                <?php esc_html_e('Réduit la lumière bleue fatigante émise par l\'écran', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Saturation -->
        <div class="acc-control-group">
            <label for="acc-migraine-saturation" class="acc-control-label">
                <?php esc_html_e('Saturation des couleurs', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-migraine-saturation-value">100%</span>
            </label>
            <input 
                type="range" 
                id="acc-migraine-saturation" 
                class="acc-slider"
                min="0" 
                max="100" 
                step="10" 
                value="100"
                aria-label="<?php esc_attr_e('Ajuster la saturation des couleurs', 'accessibility-modular'); ?>"
                aria-valuemin="0"
                aria-valuemax="100"
                aria-valuenow="100"
                aria-valuetext="100 pourcent"
            />
            <p class="acc-control-description">
                <?php esc_html_e('Réduit l\'intensité des couleurs vives qui peuvent déclencher des migraines', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Contraste -->
        <div class="acc-control-group">
            <label for="acc-migraine-contrast" class="acc-control-label">
                <?php esc_html_e('Contraste', 'accessibility-modular'); ?>
                <span class="acc-control-value" id="acc-migraine-contrast-value">100%</span>
            </label>
            <input 
                type="range" 
                id="acc-migraine-contrast" 
                class="acc-slider"
                min="80" 
                max="150" 
                step="5" 
                value="100"
                aria-label="<?php esc_attr_e('Ajuster le contraste', 'accessibility-modular'); ?>"
                aria-valuemin="80"
                aria-valuemax="150"
                aria-valuenow="100"
                aria-valuetext="100 pourcent"
            />
            <p class="acc-control-description">
                <?php esc_html_e('Ajuste le contraste pour un confort optimal', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Thème de couleur -->
        <div class="acc-control-group">
            <label for="acc-migraine-color-theme" class="acc-control-label">
                <?php esc_html_e('Thème de couleur', 'accessibility-modular'); ?>
            </label>
            <select 
                id="acc-migraine-color-theme" 
                class="acc-select"
                aria-label="<?php esc_attr_e('Sélectionner un thème de couleur', 'accessibility-modular'); ?>"
            >
                <option value="none"><?php esc_html_e('Aucun', 'accessibility-modular'); ?></option>
                <option value="sepia"><?php esc_html_e('Sépia (beige apaisant)', 'accessibility-modular'); ?></option>
                <option value="grayscale"><?php esc_html_e('Niveaux de gris', 'accessibility-modular'); ?></option>
                <option value="green"><?php esc_html_e('Teinte verte douce', 'accessibility-modular'); ?></option>
                <option value="blue"><?php esc_html_e('Teinte bleue froide', 'accessibility-modular'); ?></option>
            </select>
            <p class="acc-control-description">
                <?php esc_html_e('Applique une teinte colorée apaisante sur toute la page', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Supprimer les motifs -->
        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-migraine-remove-patterns" 
                    class="acc-checkbox"
                    aria-describedby="acc-migraine-patterns-desc"
                />
                <span><?php esc_html_e('Supprimer les motifs', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-migraine-patterns-desc" class="acc-control-description">
                <?php esc_html_e('Supprime les arrière-plans à motifs répétitifs (rayures, damiers, etc.)', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Augmenter l'espacement -->
        <div class="acc-control-group">
            <label class="acc-control-label acc-checkbox-label">
                <input 
                    type="checkbox" 
                    id="acc-migraine-increase-spacing" 
                    class="acc-checkbox"
                    aria-describedby="acc-migraine-spacing-desc"
                />
                <span><?php esc_html_e('Augmenter l\'espacement', 'accessibility-modular'); ?></span>
            </label>
            <p id="acc-migraine-spacing-desc" class="acc-control-description">
                <?php esc_html_e('Ajoute plus d\'espace blanc pour réduire la densité visuelle', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Presets rapides -->
        <div class="acc-control-group" style="margin-top: 25px; padding-top: 20px; border-top: 1px solid #ddd;">
            <label class="acc-control-label" style="margin-bottom: 12px; display: block;">
                <?php esc_html_e('Presets rapides', 'accessibility-modular'); ?>
            </label>
            <div class="acc-preset-buttons" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <button 
                    type="button" 
                    id="acc-migraine-preset-mild" 
                    class="acc-button acc-button-secondary"
                    style="padding: 8px 12px; font-size: 13px;"
                    aria-label="<?php esc_attr_e('Appliquer le preset doux', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('🌤️ Doux', 'accessibility-modular'); ?>
                </button>
                <button 
                    type="button" 
                    id="acc-migraine-preset-moderate" 
                    class="acc-button acc-button-secondary"
                    style="padding: 8px 12px; font-size: 13px;"
                    aria-label="<?php esc_attr_e('Appliquer le preset modéré', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('☁️ Modéré', 'accessibility-modular'); ?>
                </button>
                <button 
                    type="button" 
                    id="acc-migraine-preset-strong" 
                    class="acc-button acc-button-secondary"
                    style="padding: 8px 12px; font-size: 13px;"
                    aria-label="<?php esc_attr_e('Appliquer le preset fort', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('🌙 Fort', 'accessibility-modular'); ?>
                </button>
                <button 
                    type="button" 
                    id="acc-migraine-preset-crisis" 
                    class="acc-button"
                    style="padding: 8px 12px; font-size: 13px; background: #f44336; color: white;"
                    aria-label="<?php esc_attr_e('Appliquer le preset crise', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('🚨 Crise', 'accessibility-modular'); ?>
                </button>
            </div>
            <p class="acc-control-description" style="margin-top: 10px;">
                <?php esc_html_e('Configurations prédéfinies selon l\'intensité de vos symptômes', 'accessibility-modular'); ?>
            </p>
        </div>

        <!-- Bouton réinitialisation -->
        <div class="acc-control-group" style="margin-top: 15px;">
            <div class="acc-button-group">
                <button 
                    type="button" 
                    id="acc-migraine-reset" 
                    class="acc-button"
                    aria-label="<?php esc_attr_e('Réinitialiser les paramètres de soulagement migraines', 'accessibility-modular'); ?>"
                >
                    <?php esc_html_e('Réinitialiser', 'accessibility-modular'); ?>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.acc-checkbox-label {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-weight: 500;
}

.acc-checkbox {
    margin-right: 10px;
    width: 18px;
    height: 18px;
    cursor: pointer;
}

.acc-control-description {
    font-size: 12px;
    color: #666;
    margin: 5px 0 0 28px;
    line-height: 1.4;
}

.acc-button-secondary {
    background: #f5f5f5;
    border: 1px solid #ddd;
    color: #333;
}

.acc-button-secondary:hover {
    background: #e0e0e0;
}

.acc-preset-buttons button {
    transition: all 0.2s;
}

.acc-preset-buttons button:hover {
    transform: translateY(-2px);
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
</style>