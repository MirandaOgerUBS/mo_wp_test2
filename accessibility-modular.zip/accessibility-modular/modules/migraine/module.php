<?php
/**
 * Module Soulagement Migraines
 * Réduit les déclencheurs visuels des migraines ophtalmiques
 * 
 * @package AccessibilityModular
 * @subpackage Modules
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Classe du module Soulagement Migraines
 */
class ACC_Module_Migraine {
    
    /**
     * Version du module
     */
    const VERSION = '1.0.0';
    
    /**
     * Nom du module
     */
    const MODULE_NAME = 'migraine';
    
    /**
     * Constructeur
     */
    public function __construct() {
        $this->init_hooks();
    }
    
    /**
     * Initialise les hooks
     */
    private function init_hooks() {
        add_filter('acc_module_metadata', array($this, 'add_metadata'), 10, 2);
        add_action('wp_head', array($this, 'add_meta_tags'), 1);
    }
    
    /**
     * Ajoute des métadonnées au module
     * 
     * @param array $metadata Métadonnées existantes
     * @param string $module_name Nom du module
     * @return array
     */
    public function add_metadata($metadata, $module_name) {
        if ($module_name !== self::MODULE_NAME) {
            return $metadata;
        }
        
        $metadata['relief_features'] = $this->get_relief_features();
        $metadata['wcag_compliance'] = array(
            'criteria' => array('1.4.3', '1.4.6', '1.4.8', '1.4.12'),
            'level' => 'AAA'
        );
        $metadata['rgaa_compliance'] = array(
            'criteria' => array('3.2', '3.3', '10.3'),
            'level' => 'AA'
        );
        $metadata['medical_conditions'] = array(
            'migraine_ophtalmique',
            'photophobie',
            'fatigue_oculaire',
            'sensibilite_lumiere'
        );
        
        return $metadata;
    }
    
    /**
     * Ajoute les meta tags
     */
    public function add_meta_tags() {
        // Vérifier si le mode sombre est actif
        if ($this->is_dark_mode_active()) {
            echo '<meta name="color-scheme" content="dark light">' . "\n";
        }
    }
    
    /**
     * Vérifie si le mode sombre est actif
     * 
     * @return bool
     */
    private function is_dark_mode_active() {
        return isset($_COOKIE['acc_migraine_dark_mode']) && 
               json_decode(stripslashes($_COOKIE['acc_migraine_dark_mode']), true) === true;
    }
    
    /**
     * Retourne les fonctionnalités de soulagement
     * 
     * @return array
     */
    private function get_relief_features() {
        return array(
            'dark_mode' => __('Mode sombre pour réduire la luminosité', 'accessibility-modular'),
            'brightness' => __('Contrôle de la luminosité globale', 'accessibility-modular'),
            'blue_light_filter' => __('Filtre de lumière bleue', 'accessibility-modular'),
            'saturation' => __('Désaturation des couleurs vives', 'accessibility-modular'),
            'contrast' => __('Ajustement du contraste', 'accessibility-modular'),
            'color_theme' => __('Teintes apaisantes (sépia, gris, etc.)', 'accessibility-modular'),
            'remove_patterns' => __('Suppression des motifs répétitifs', 'accessibility-modular'),
            'increase_spacing' => __('Augmentation de l\'espace blanc', 'accessibility-modular')
        );
    }
    
    /**
     * Retourne les paramètres par défaut
     * 
     * @return array
     */
    public static function get_default_settings() {
        return array(
            'dark_mode' => false,
            'brightness' => 100,
            'blue_light_filter' => 0,
            'saturation' => 100,
            'contrast' => 100,
            'color_theme' => 'none',
            'remove_patterns' => false,
            'increase_spacing' => false
        );
    }
    
    /**
     * Valide les paramètres
     * 
     * @param array $settings Paramètres à valider
     * @return array
     */
    public static function validate_settings($settings) {
        $defaults = self::get_default_settings();
        $validated = array();
        
        // Validation du mode sombre
        if (isset($settings['dark_mode'])) {
            $validated['dark_mode'] = (bool) $settings['dark_mode'];
        }
        
        // Validation de la luminosité
        if (isset($settings['brightness'])) {
            $brightness = intval($settings['brightness']);
            if ($brightness >= 50 && $brightness <= 100) {
                $validated['brightness'] = $brightness;
            }
        }
        
        // Validation du filtre lumière bleue
        if (isset($settings['blue_light_filter'])) {
            $filter = intval($settings['blue_light_filter']);
            if ($filter >= 0 && $filter <= 100) {
                $validated['blue_light_filter'] = $filter;
            }
        }
        
        // Validation de la saturation
        if (isset($settings['saturation'])) {
            $saturation = intval($settings['saturation']);
            if ($saturation >= 0 && $saturation <= 100) {
                $validated['saturation'] = $saturation;
            }
        }
        
        // Validation du contraste
        if (isset($settings['contrast'])) {
            $contrast = intval($settings['contrast']);
            if ($contrast >= 80 && $contrast <= 150) {
                $validated['contrast'] = $contrast;
            }
        }
        
        // Validation du thème de couleur
        if (isset($settings['color_theme'])) {
            $allowed_themes = array('none', 'sepia', 'grayscale', 'green', 'blue');
            if (in_array($settings['color_theme'], $allowed_themes)) {
                $validated['color_theme'] = $settings['color_theme'];
            }
        }
        
        // Validation de la suppression des motifs
        if (isset($settings['remove_patterns'])) {
            $validated['remove_patterns'] = (bool) $settings['remove_patterns'];
        }
        
        // Validation de l'augmentation de l'espacement
        if (isset($settings['increase_spacing'])) {
            $validated['increase_spacing'] = (bool) $settings['increase_spacing'];
        }
        
        return array_merge($defaults, $validated);
    }
    
    /**
     * Nettoie les cookies du module
     */
    public static function clear_cookies() {
        $cookies = array(
            'acc_migraine_dark_mode',
            'acc_migraine_brightness',
            'acc_migraine_blue_light_filter',
            'acc_migraine_saturation',
            'acc_migraine_contrast',
            'acc_migraine_color_theme',
            'acc_migraine_remove_patterns',
            'acc_migraine_increase_spacing'
        );
        
        foreach ($cookies as $cookie) {
            if (isset($_COOKIE[$cookie])) {
                setcookie($cookie, '', time() - 3600, '/');
            }
        }
    }
}

// Initialise le module
new ACC_Module_Migraine();