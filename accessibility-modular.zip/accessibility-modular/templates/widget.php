<?php
/**
 * Template du widget d'accessibilité
 * Conforme RGAA 4.1
 */

if (!defined('ABSPATH')) {
    exit;
}

// Récupération des modules actifs et organisation par catégorie
$module_registry = ACC_Module_Registry::get_instance();
$active_modules = $module_registry->get_active_modules();
$all_modules_info = [];

foreach ($active_modules as $module_name) {
    $module_info = $module_registry->get_module_info($module_name);
    if ($module_info) {
        $category = $module_info['category'];
        if (!isset($all_modules_info[$category])) {
            $all_modules_info[$category] = [];
        }
        $all_modules_info[$category][] = $module_info;
    }
}

// Si aucun module actif, ne pas afficher le widget
if (empty($all_modules_info)) {
    return;
}
?>

<div id="acc-widget" class="acc-widget" role="dialog" aria-labelledby="acc-widget-title" aria-hidden="true">
    <!-- Bouton d'ouverture du widget -->
    <button 
        id="acc-widget-trigger" 
        class="acc-widget-trigger" 
        aria-label="<?php esc_attr_e('Ouvrir les options d\'accessibilité', 'accessibility-modular'); ?>"
        aria-expanded="false"
        aria-controls="acc-widget-panel"
        type="button"
    >
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
            <circle cx="12" cy="12" r="10"></circle>
            <circle cx="12" cy="12" r="3"></circle>
            <line x1="12" y1="1" x2="12" y2="3"></line>
            <line x1="12" y1="21" x2="12" y2="23"></line>
            <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
            <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
            <line x1="1" y1="12" x2="3" y2="12"></line>
            <line x1="21" y1="12" x2="23" y2="12"></line>
            <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
            <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
        </svg>
    </button>

    <!-- Panneau du widget -->
    <div id="acc-widget-panel" class="acc-widget-panel" style="display: none;">
        <!-- Header -->
        <div class="acc-widget-header">
            <button 
                id="acc-widget-back" 
                class="acc-widget-back" 
                aria-label="<?php esc_attr_e('Retour à la vue globale', 'accessibility-modular'); ?>"
                type="button"
                style="display: none;"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                    <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
            </button>
            
            <h2 id="acc-widget-title" class="acc-widget-title">
                <?php esc_html_e('Accessibilité', 'accessibility-modular'); ?>
            </h2>
            
            <button 
                id="acc-widget-search-toggle" 
                class="acc-widget-search-toggle" 
                aria-label="<?php esc_attr_e('Rechercher une fonctionnalité', 'accessibility-modular'); ?>"
                type="button"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                    <circle cx="11" cy="11" r="8"></circle>
                    <path d="m21 21-4.35-4.35"></path>
                </svg>
            </button>
            
            <button 
                id="acc-widget-close" 
                class="acc-widget-close" 
                aria-label="<?php esc_attr_e('Fermer les options d\'accessibilité', 'accessibility-modular'); ?>"
                type="button"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </div>

        <!-- Barre de recherche -->
        <div id="acc-widget-search-bar" class="acc-widget-search-bar" style="display: none;">
            <input 
                type="search" 
                id="acc-widget-search-input"
                class="acc-widget-search-input"
                placeholder="<?php esc_attr_e('Rechercher...', 'accessibility-modular'); ?>"
                aria-label="<?php esc_attr_e('Rechercher une fonctionnalité d\'accessibilité', 'accessibility-modular'); ?>"
            />
            <button 
                type="button"
                class="acc-widget-search-voice"
                aria-label="<?php esc_attr_e('Recherche vocale', 'accessibility-modular'); ?>"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                    <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path>
                    <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
                    <line x1="12" x2="12" y1="19" y2="22"></line>
                </svg>
            </button>
        </div>

        <!-- Icônes catégories principales (Vue globale) -->
        <div id="acc-categories-icons" class="acc-categories-icons">
            <?php
            // Icônes SVG pour chaque catégorie
            $category_icons = [
                'vision' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>',
                'audition' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 8.5a6.5 6.5 0 1 1 13 0c0 6-6 6-6 10a3.5 3.5 0 1 1-7 0"></path><line x1="13" x2="13" y1="11" y2="11"></line><line x1="13" x2="13" y1="8" y2="8"></line></svg>',
                'mobilite' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="1"></circle><path d="m9 20 3-6 3 6"></path><path d="m6 8 6 2 6-2"></path><path d="M12 10v4"></path></svg>',
                'cognition' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48 2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48 2.83-2.83"></path></svg>',
                'lecture' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path></svg>'
            ];
            
            // Labels des catégories
            $category_labels = [
                'vision' => __('Vision', 'accessibility-modular'),
                'audition' => __('Audition', 'accessibility-modular'),
                'mobilite' => __('Mobilité', 'accessibility-modular'),
                'cognition' => __('Cognition', 'accessibility-modular'),
                'lecture' => __('Lecture', 'accessibility-modular')
            ];
            
            // Afficher les catégories qui ont des modules
            foreach ($all_modules_info as $category => $modules):
                if (!empty($modules)):
                    $icon = $category_icons[$category] ?? $category_icons['vision'];
                    $label = $category_labels[$category] ?? ucfirst($category);
            ?>
                <button 
                    type="button"
                    class="acc-category-icon" 
                    data-category="<?php echo esc_attr($category); ?>"
                    aria-label="<?php echo esc_attr(sprintf(__('Ouvrir les options de %s', 'accessibility-modular'), $label)); ?>"
                >
                    <span aria-hidden="true"><?php echo $icon; ?></span>
                    <span class="acc-category-label"><?php echo esc_html($label); ?></span>
                </button>
            <?php
                endif;
            endforeach;
            ?>
        </div>

        <!-- Contenu détaillé (Vue détaillée par catégorie) -->
        <div id="acc-content-detail" class="acc-content-detail" style="display: none;">
            <?php foreach ($all_modules_info as $category => $modules): ?>
                <div 
                    class="acc-category-section" 
                    id="acc-section-<?php echo esc_attr($category); ?>"
                    data-category="<?php echo esc_attr($category); ?>"
                    style="display: none;"
                >
                    <?php
                    // Inclure le template de chaque module
                    foreach ($modules as $module_info):
                        $module_file = $module_info['path'] . '/template.php';
                        if (file_exists($module_file)) {
                            include $module_file;
                        }
                    endforeach;
                    ?>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Vue par liste (alternative pour accessibilité) -->
        <div id="acc-categories-list" class="acc-categories-list" style="display: none;">
            <?php 
            foreach ($all_modules_info as $category => $modules): 
                $label = $category_labels[$category] ?? ucfirst($category);
            ?>
                <button 
                    type="button"
                    class="acc-category-list-item" 
                    data-category="<?php echo esc_attr($category); ?>"
                    aria-label="<?php echo esc_attr(sprintf(__('Afficher %s', 'accessibility-modular'), $label)); ?>"
                >
                    <?php echo esc_html($label); ?>
                    <span class="acc-category-count" aria-label="<?php echo esc_attr(sprintf(_n('%d module', '%d modules', count($modules), 'accessibility-modular'), count($modules))); ?>">
                        (<?php echo count($modules); ?>)
                    </span>
                </button>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Zone d'annonces pour les lecteurs d'écran -->
    <div id="acc-announcer" class="sr-only" role="status" aria-live="polite" aria-atomic="true"></div>
</div>