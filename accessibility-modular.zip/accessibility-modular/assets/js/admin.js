/**
 * Admin JavaScript - Accessibilité Modulaire
 * Scripts pour la page d'administration WordPress
 * Version: 1.0.0
 */

(function($) {
    'use strict';

    /**
     * Classe pour gérer l'interface admin
     */
    class AccessibilityAdmin {
        constructor() {
            this.form = $('form');
            this.moduleCards = $('.acc-module-card');
            this.apiKeyInput = $('#acc_api_key');
            this.selectAllBtn = null;
            this.deselectAllBtn = null;
            
            this.init();
        }

        /**
         * Initialisation
         */
        init() {
            this.addBulkActions();
            this.bindEvents();
            this.setupValidation();
            this.setupSearch();
            this.animateCards();
        }

        /**
         * Ajoute les actions en masse
         */
        addBulkActions() {
            const $modulesSection = $('.acc-modules-grid').closest('.acc-admin-section');
            
            if ($modulesSection.length && this.moduleCards.length > 0) {
                const $bulkActions = $('<div>', {
                    class: 'acc-bulk-actions',
                    style: 'margin-bottom: 16px; display: flex; gap: 8px;'
                });

                this.selectAllBtn = $('<button>', {
                    type: 'button',
                    class: 'button',
                    text: 'Tout sélectionner'
                });

                this.deselectAllBtn = $('<button>', {
                    type: 'button',
                    class: 'button',
                    text: 'Tout désélectionner'
                });

                $bulkActions.append(this.selectAllBtn, this.deselectAllBtn);
                $modulesSection.find('p.description').after($bulkActions);
            }
        }

        /**
         * Liaison des événements
         */
        bindEvents() {
            // Actions en masse
            if (this.selectAllBtn) {
                this.selectAllBtn.on('click', () => this.selectAll());
            }
            if (this.deselectAllBtn) {
                this.deselectAllBtn.on('click', () => this.deselectAll());
            }

            // Clic sur la carte entière
            this.moduleCards.on('click', function(e) {
                if (e.target.tagName !== 'INPUT') {
                    const $checkbox = $(this).find('input[type="checkbox"]');
                    $checkbox.prop('checked', !$checkbox.prop('checked')).trigger('change');
                }
            });

            // Changement de statut des modules
            this.moduleCards.find('input[type="checkbox"]').on('change', function() {
                const $card = $(this).closest('.acc-module-card');
                $card.toggleClass('active', $(this).is(':checked'));
            });

            // Validation de la clé API
            this.apiKeyInput.on('blur', () => this.validateApiKey());

            // Prévention de la soumission accidentelle
            this.form.on('submit', (e) => this.handleSubmit(e));

            // Compteur de modules sélectionnés
            $('input[name="acc_modules[]"]').on('change', () => this.updateModuleCount());
        }

        /**
         * Sélectionne tous les modules
         */
        selectAll() {
            this.moduleCards.find('input[type="checkbox"]').prop('checked', true).trigger('change');
            this.updateModuleCount();
            this.showNotice('Tous les modules ont été sélectionnés', 'success');
        }

        /**
         * Désélectionne tous les modules
         */
        deselectAll() {
            this.moduleCards.find('input[type="checkbox"]').prop('checked', false).trigger('change');
            this.updateModuleCount();
            this.showNotice('Tous les modules ont été désélectionnés', 'info');
        }

        /**
         * Met à jour le compteur de modules
         */
        updateModuleCount() {
            const total = this.moduleCards.length;
            const selected = this.moduleCards.find('input:checked').length;
            
            let $counter = $('#acc-module-counter');
            
            if (!$counter.length) {
                $counter = $('<p>', {
                    id: 'acc-module-counter',
                    class: 'description',
                    style: 'font-weight: 600; color: #2271b1;'
                });
                $('.acc-modules-grid').before($counter);
            }
            
            $counter.html(`<span class="dashicons dashicons-yes-alt"></span> ${selected} module(s) sélectionné(s) sur ${total}`);
        }

        /**
         * Validation de la clé API
         */
        validateApiKey() {
            const apiKey = this.apiKeyInput.val().trim();
            
            if (!apiKey) {
                this.showFieldError(this.apiKeyInput, 'La clé API est requise');
                return false;
            }
            
            if (apiKey.length < 20) {
                this.showFieldError(this.apiKeyInput, 'La clé API semble trop courte');
                return false;
            }
            
            if (!/^[A-Za-z0-9_-]+$/.test(apiKey)) {
                this.showFieldError(this.apiKeyInput, 'Format de clé API invalide');
                return false;
            }
            
            this.clearFieldError(this.apiKeyInput);
            return true;
        }

        /**
         * Affiche une erreur sur un champ
         */
        showFieldError($field, message) {
            this.clearFieldError($field);
            
            const $error = $('<p>', {
                class: 'acc-field-error description',
                style: 'color: #d63638; margin-top: 8px;',
                html: `<span class="dashicons dashicons-warning"></span> ${message}`
            });
            
            $field.after($error);
            $field.css('border-color', '#d63638');
        }

        /**
         * Efface l'erreur d'un champ
         */
        clearFieldError($field) {
            $field.next('.acc-field-error').remove();
            $field.css('border-color', '');
        }

        /**
         * Configuration de la validation du formulaire
         */
        setupValidation() {
            // Initialise le compteur
            this.updateModuleCount();
            
            // Marque les cartes actives
            this.moduleCards.find('input:checked').each(function() {
                $(this).closest('.acc-module-card').addClass('active');
            });
        }

        /**
         * Gestion de la soumission du formulaire
         */
        handleSubmit(e) {
            // Validation de la clé API
            if (!this.validateApiKey()) {
                e.preventDefault();
                this.apiKeyInput.focus();
                this.showNotice('Veuillez corriger les erreurs avant de sauvegarder', 'error');
                return false;
            }
            
            // Confirmation si aucun module n'est sélectionné
            const selectedCount = this.moduleCards.find('input:checked').length;
            if (selectedCount === 0) {
                const confirmed = confirm('Aucun module n\'est sélectionné. Le widget d\'accessibilité sera vide. Continuer ?');
                if (!confirmed) {
                    e.preventDefault();
                    return false;
                }
            }
            
            // Ajout d'un spinner
            const $submitBtn = this.form.find('button[type="submit"]');
            $submitBtn.prop('disabled', true).append(' <span class="acc-loading"></span>');
            
            return true;
        }

        /**
         * Affiche une notice
         */
        showNotice(message, type = 'info') {
            const $notice = $('<div>', {
                class: `notice notice-${type} is-dismissible`,
                style: 'margin: 16px 0;'
            }).append($('<p>', {
                text: message
            }));
            
            $('.wrap h1').after($notice);
            
            // Auto-suppression après 5 secondes
            setTimeout(() => {
                $notice.fadeOut(300, function() {
                    $(this).remove();
                });
            }, 5000);
        }

        /**
         * Configuration de la recherche
         */
        setupSearch() {
            const $modulesSection = $('.acc-modules-grid').closest('.acc-admin-section');
            
            if ($modulesSection.length && this.moduleCards.length > 3) {
                const $searchBox = $('<div>', {
                    class: 'acc-search-box',
                    style: 'margin-bottom: 16px;'
                });

                const $searchInput = $('<input>', {
                    type: 'search',
                    class: 'regular-text',
                    placeholder: 'Rechercher un module...',
                    'aria-label': 'Rechercher un module'
                });

                $searchBox.append($searchInput);
                $modulesSection.find('h2').after($searchBox);

                // Recherche en temps réel
                $searchInput.on('input', this.debounce((e) => {
                    this.filterModules($(e.target).val());
                }, 300));
            }
        }

        /**
         * Filtre les modules
         */
        filterModules(query) {
            query = query.toLowerCase().trim();
            
            if (!query) {
                this.moduleCards.show();
                $('.acc-category-section').show();
                return;
            }
            
            let visibleCount = 0;
            
            this.moduleCards.each(function() {
                const $card = $(this);
                const title = $card.find('strong').text().toLowerCase();
                const description = $card.find('p').text().toLowerCase();
                const matches = title.includes(query) || description.includes(query);
                
                $card.toggle(matches);
                if (matches) visibleCount++;
            });
            
            // Cache les catégories vides
            $('.acc-category-section').each(function() {
                const $section = $(this);
                const hasVisible = $section.find('.acc-module-card:visible').length > 0;
                $section.toggle(hasVisible);
            });
            
            if (visibleCount === 0) {
                this.showNotice('Aucun module ne correspond à votre recherche', 'warning');
            }
        }

        /**
         * Animation des cartes au chargement
         */
        animateCards() {
            this.moduleCards.each(function(index) {
                $(this).css({
                    'animation-delay': `${index * 0.05}s`
                });
            });
        }

        /**
         * Debounce helper
         */
        debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
    }

    /**
     * Initialisation au chargement du DOM
     */
    $(document).ready(function() {
        // Vérifie qu'on est sur la bonne page
        if ($('.acc-modules-grid').length) {
            new AccessibilityAdmin();
        }

        // Gestion des notices dismissibles WordPress
        $(document).on('click', '.notice-dismiss', function() {
            $(this).closest('.notice').fadeOut(300);
        });

        // Tooltip pour les modules
        $('.acc-module-card').each(function() {
            $(this).attr('title', 'Cliquer pour activer/désactiver ce module');
        });

        // Confirmation avant de quitter si modifications non sauvegardées
        let formChanged = false;
        $('input, select, textarea').on('change', function() {
            formChanged = true;
        });

        $('form').on('submit', function() {
            formChanged = false;
        });

        $(window).on('beforeunload', function() {
            if (formChanged) {
                return 'Vous avez des modifications non sauvegardées. Voulez-vous vraiment quitter cette page ?';
            }
        });
    });

})(jQuery);