/**
 * Accessibility Utils - Module utilitaire complet
 * Version fusionnée : Gestion CSS + Cookies + Préférences + ARIA
 * 
 * @package AccessibilityModular
 * @version 2.0.0
 */

(function($) {
    'use strict';

    // ============================================
    // GESTION CSS (version optimisée)
    // ============================================

    /**
     * Stockage des règles CSS appliquées
     * Map: id → index dans la feuille de style
     */
    const appliedRules = new Map();
    
    /**
     * Référence vers la feuille de style
     */
    let styleSheet = null;

    /**
     * Crée ou récupère la feuille de style dédiée
     * @returns {CSSStyleSheet}
     */
    function createStyleSheet() {
        if (styleSheet) {
            return styleSheet;
        }
        
        // Créer l'élément <style>
        const style = document.createElement('style');
        style.id = 'acc-custom-styles';
        style.setAttribute('data-acc', 'true');
        document.head.appendChild(style);
        
        // Récupérer la feuille de style
        styleSheet = style.sheet;
        
        return styleSheet;
    }

    /**
     * Applique des styles CSS personnalisés
     * 
     * @param {string} id - Identifiant unique de la règle
     * @param {string} css - Code CSS à appliquer
     */
    function applyCustomCSS(id, css) {
        if (!id || !css) {
            console.warn('accUtils.applyCustomCSS: paramètres invalides', id, css);
            return;
        }
        
        const sheet = createStyleSheet();
        
        // Supprimer l'ancienne règle si elle existe
        if (appliedRules.has(id)) {
            const oldIndex = appliedRules.get(id);
            try {
                sheet.deleteRule(oldIndex);
                
                // Mettre à jour les indices des autres règles
                appliedRules.forEach((index, key) => {
                    if (index > oldIndex) {
                        appliedRules.set(key, index - 1);
                    }
                });
                
            } catch (e) {
                console.warn('Impossible de supprimer la règle:', id, e);
            }
        }
        
        // Ajouter la nouvelle règle
        try {
            const index = sheet.insertRule(css, sheet.cssRules.length);
            appliedRules.set(id, index);
        } catch (e) {
            console.error('Erreur lors de l\'ajout de la règle CSS:', e);
            console.error('CSS:', css);
        }
    }

    /**
     * Supprime des styles CSS personnalisés
     * 
     * @param {string} id - Identifiant de la règle à supprimer
     */
    function removeCustomCSS(id) {
        if (!id) {
            console.warn('accUtils.removeCustomCSS: id invalide');
            return;
        }
        
        if (!styleSheet) {
            return;
        }
        
        if (appliedRules.has(id)) {
            const index = appliedRules.get(id);
            
            try {
                styleSheet.deleteRule(index);
                appliedRules.delete(id);
                
                // Mettre à jour les indices des autres règles
                appliedRules.forEach((ruleIndex, key) => {
                    if (ruleIndex > index) {
                        appliedRules.set(key, ruleIndex - 1);
                    }
                });
                
            } catch (e) {
                console.error('Erreur lors de la suppression de la règle CSS:', e);
            }
        }
    }

    /**
     * Supprime tous les styles CSS personnalisés
     */
    function removeAllCustomCSS() {
        if (!styleSheet) {
            return;
        }
        
        try {
            // Supprimer toutes les règles
            while (styleSheet.cssRules.length > 0) {
                styleSheet.deleteRule(0);
            }
            
            // Vider le Map
            appliedRules.clear();
            
        } catch (e) {
            console.error('Erreur lors de la suppression de tous les styles:', e);
        }
    }

    // ============================================
    // GESTION DES COOKIES
    // ============================================

    const accCookies = {
        
        /**
         * Définit un cookie
         * @param {string} name - Nom du cookie
         * @param {string} value - Valeur du cookie
         * @param {number} days - Durée de vie en jours
         */
        set: function(name, value, days = 365) {
            const date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            const expires = "expires=" + date.toUTCString();
            document.cookie = name + "=" + encodeURIComponent(value) + ";" + expires + ";path=/;SameSite=Lax";
        },
        
        /**
         * Récupère un cookie
         * @param {string} name - Nom du cookie
         * @returns {string|null}
         */
        get: function(name) {
            const nameEQ = name + "=";
            const ca = document.cookie.split(';');
            
            for (let i = 0; i < ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) === ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) === 0) {
                    return decodeURIComponent(c.substring(nameEQ.length, c.length));
                }
            }
            return null;
        },
        
        /**
         * Supprime un cookie
         * @param {string} name - Nom du cookie
         */
        delete: function(name) {
            document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;";
        },
        
        /**
         * Vérifie si un cookie existe
         * @param {string} name - Nom du cookie
         * @returns {boolean}
         */
        exists: function(name) {
            return this.get(name) !== null;
        }
    };

    // ============================================
    // WIDGET D'ACCESSIBILITÉ
    // ============================================

    const accWidget = {
        
        // Préfixe pour tous les cookies
        cookiePrefix: 'acc_',
        
        /**
         * Initialisation du widget
         */
        init: function() {
            this.createLiveRegion();
            console.log('✓ Accessibility Widget initialized');
        },
        
        /**
         * Crée la région live pour les annonces ARIA
         */
        createLiveRegion: function() {
            if (!document.getElementById('acc-live-region')) {
                const liveRegion = document.createElement('div');
                liveRegion.id = 'acc-live-region';
                liveRegion.setAttribute('role', 'status');
                liveRegion.setAttribute('aria-live', 'polite');
                liveRegion.setAttribute('aria-atomic', 'true');
                liveRegion.className = 'acc-sr-only';
                liveRegion.style.cssText = 'position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden;';
                document.body.appendChild(liveRegion);
            }
        },
        
        /**
         * Annonce un message aux lecteurs d'écran
         * @param {string} message - Message à annoncer
         */
        announce: function(message) {
            const liveRegion = document.getElementById('acc-live-region');
            if (liveRegion) {
                liveRegion.textContent = '';
                setTimeout(() => {
                    liveRegion.textContent = message;
                }, 100);
            }
        },
        
        /**
         * Sauvegarde une préférence
         * @param {string} key - Clé de la préférence
         * @param {*} value - Valeur à sauvegarder
         */
        savePreference: function(key, value) {
            const cookieName = this.cookiePrefix + key;
            const cookieValue = typeof value === 'object' ? JSON.stringify(value) : String(value);
            accCookies.set(cookieName, cookieValue);
        },
        
        /**
         * Récupère une préférence
         * @param {string} key - Clé de la préférence
         * @param {*} defaultValue - Valeur par défaut
         * @returns {*}
         */
        getPreference: function(key, defaultValue = null) {
            const cookieName = this.cookiePrefix + key;
            const value = accCookies.get(cookieName);
            
            if (value === null) {
                return defaultValue;
            }
            
            // Tente de parser en JSON si c'est un objet
            try {
                return JSON.parse(value);
            } catch (e) {
                // Si ce n'est pas du JSON, retourne la valeur brute
                // Conversion en types appropriés
                if (value === 'true') return true;
                if (value === 'false') return false;
                if (!isNaN(value) && value !== '') return Number(value);
                return value;
            }
        },
        
        /**
         * Supprime une préférence
         * @param {string} key - Clé de la préférence
         */
        deletePreference: function(key) {
            const cookieName = this.cookiePrefix + key;
            accCookies.delete(cookieName);
        },
        
        /**
         * Supprime toutes les préférences
         */
        clearAllPreferences: function() {
            const cookies = document.cookie.split(';');
            
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                const cookieName = cookie.split('=')[0];
                
                if (cookieName.startsWith(this.cookiePrefix)) {
                    accCookies.delete(cookieName);
                }
            }
        },
        
        /**
         * Récupère toutes les préférences
         * @returns {Object}
         */
        getAllPreferences: function() {
            const preferences = {};
            const cookies = document.cookie.split(';');
            
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                const [name, value] = cookie.split('=');
                
                if (name.startsWith(this.cookiePrefix)) {
                    const key = name.substring(this.cookiePrefix.length);
                    preferences[key] = this.getPreference(key);
                }
            }
            
            return preferences;
        }
    };

    // ============================================
    // UTILITAIRES SUPPLÉMENTAIRES
    // ============================================

    const utils = {
        /**
         * Génère un ID unique
         * @returns {string}
         */
        generateId: function() {
            return 'acc-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        },
        
        /**
         * Débounce une fonction
         * @param {Function} func - Fonction à débouncer
         * @param {number} wait - Délai d'attente en ms
         * @returns {Function}
         */
        debounce: function(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },
        
        /**
         * Vérifie si un élément est visible
         * @param {Element} element
         * @returns {boolean}
         */
        isVisible: function(element) {
            return !!(element.offsetWidth || element.offsetHeight || element.getClientRects().length);
        },

        /**
         * Récupère toutes les règles appliquées
         * @returns {Array} Liste des règles [id, index]
         */
        getAppliedRules: function() {
            return Array.from(appliedRules.entries());
        },
        
        /**
         * Récupère une règle spécifique
         * @param {string} id - Identifiant de la règle
         * @returns {CSSRule|null}
         */
        getRule: function(id) {
            if (!styleSheet || !appliedRules.has(id)) {
                return null;
            }
            
            const index = appliedRules.get(id);
            return styleSheet.cssRules[index] || null;
        },
        
        /**
         * Vérifie si une règle existe
         * @param {string} id - Identifiant de la règle
         * @returns {boolean}
         */
        hasRule: function(id) {
            return appliedRules.has(id);
        },
        
        /**
         * Récupère le nombre de règles appliquées
         * @returns {number}
         */
        getRulesCount: function() {
            return appliedRules.size;
        },
        
        /**
         * Active/désactive toutes les règles
         * @param {boolean} enabled
         */
        toggleAll: function(enabled) {
            if (!styleSheet) {
                return;
            }
            
            const style = document.getElementById('acc-custom-styles');
            if (style) {
                style.disabled = !enabled;
            }
        },
        
        /**
         * Exporte toutes les règles en JSON
         * @returns {Object}
         */
        exportRules: function() {
            const rules = {};
            
            appliedRules.forEach((index, id) => {
                if (styleSheet.cssRules[index]) {
                    rules[id] = styleSheet.cssRules[index].cssText;
                }
            });
            
            return rules;
        },
        
        /**
         * Importe des règles depuis un objet
         * @param {Object} rules - Objet {id: cssText}
         */
        importRules: function(rules) {
            if (typeof rules !== 'object') {
                console.warn('accUtils.importRules: règles invalides');
                return;
            }
            
            Object.keys(rules).forEach(id => {
                applyCustomCSS(id, rules[id]);
            });
        }
    };

    // ============================================
    // EXPOSITION DE L'API PUBLIQUE
    // ============================================

    window.accUtils = {
        // Méthodes principales CSS
        applyCustomCSS: applyCustomCSS,
        removeCustomCSS: removeCustomCSS,
        removeAllCustomCSS: removeAllCustomCSS,
        
        // Méthodes utilitaires
        ...utils,
        
        // Version
        version: '2.0.0'
    };

    window.accCookies = accCookies;
    window.accWidget = accWidget;

    // Exposition globale pour debug
    window.acc = {
        utils: window.accUtils,
        cookies: window.accCookies,
        widget: window.accWidget
    };

    // ============================================
    // INITIALISATION
    // ============================================

    // Fonction d'initialisation
    function init() {
        // Créer la feuille de style immédiatement
        createStyleSheet();
        
        // Initialiser le widget
        accWidget.init();
        
        // Log de confirmation
        console.log('✓ accUtils v' + window.accUtils.version + ' chargé');
        
        // Event personnalisé pour notifier que accUtils est prêt
        if (typeof CustomEvent === 'function') {
            const event = new CustomEvent('accUtilsReady', {
                detail: { version: window.accUtils.version }
            });
            document.dispatchEvent(event);
        }
    }

    // Initialiser au chargement du DOM
    if (typeof $ !== 'undefined') {
        $(document).ready(init);
    } else {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
        } else {
            init();
        }
    }

})(typeof jQuery !== 'undefined' ? jQuery : undefined);