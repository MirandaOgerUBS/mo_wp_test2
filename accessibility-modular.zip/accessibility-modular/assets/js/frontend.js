/**
 * Accessibility Widget - Frontend JavaScript
 * Version: 1.0.0
 * Gère le widget d'accessibilité et les interactions
 */

(function($) {
    'use strict';

    /**
     * Classe principale du widget
     */
    class AccessibilityWidget {
        constructor() {
            this.widget = $('#acc-widget');
            this.trigger = $('#acc-widget-trigger');
            this.panel = $('#acc-widget-panel');
            this.closeBtn = $('#acc-widget-close');
            this.backBtn = $('#acc-widget-back');
            this.searchToggle = $('#acc-widget-search-toggle');
            this.searchBar = $('#acc-widget-search-bar');
            this.searchInput = $('#acc-widget-search-input');
            
            this.categoriesIcons = $('#acc-categories-icons');
            this.contentDetail = $('#acc-content-detail');
            
            this.currentCategory = null;
            this.isOpen = false;
            
            this.init();
        }

        /**
         * Initialisation
         */
        init() {
            this.bindEvents();
            this.loadPreferences();
            console.log('Accessibility Widget initialisé');
        }

        /**
         * Liaison des événements
         */
        bindEvents() {
            // Ouvrir/fermer le widget
            this.trigger.on('click', () => this.toggleWidget());
            this.closeBtn.on('click', () => this.closeWidget());
            
            // Navigation par catégorie
            $('.acc-category-icon').on('click', (e) => {
                const category = $(e.currentTarget).data('category');
                this.showCategory(category);
            });
            
            // Bouton retour
            this.backBtn.on('click', () => this.showMainView());
            
            // Recherche
            this.searchToggle.on('click', () => this.toggleSearch());
            this.searchInput.on('input', (e) => this.handleSearch(e.target.value));
            
            // Fermer en cliquant en dehors
            $(document).on('click', (e) => {
                if (this.isOpen && 
                    !$(e.target).closest('#acc-widget').length && 
                    !$(e.target).closest('#acc-widget-trigger').length) {
                    this.closeWidget();
                }
            });
            
            // Touches clavier (Escape pour fermer)
            $(document).on('keydown', (e) => {
                if (e.key === 'Escape' && this.isOpen) {
                    this.closeWidget();
                }
            });
        }

        /**
         * Ouvrir/fermer le widget
         */
        toggleWidget() {
            if (this.isOpen) {
                this.closeWidget();
            } else {
                this.openWidget();
            }
        }

        /**
         * Ouvrir le widget
         */
        openWidget() {
            this.isOpen = true;
            this.panel.slideDown(300);
            this.trigger.attr('aria-expanded', 'true');
            this.widget.attr('aria-hidden', 'false');
            this.announce('Widget d\'accessibilité ouvert');
        }

        /**
         * Fermer le widget
         */
        closeWidget() {
            this.isOpen = false;
            this.panel.slideUp(300);
            this.trigger.attr('aria-expanded', 'false');
            this.widget.attr('aria-hidden', 'true');
            this.showMainView(); // Retour à la vue principale
            this.announce('Widget d\'accessibilité fermé');
        }

        /**
         * Afficher une catégorie
         */
        showCategory(category) {
            this.currentCategory = category;
            
            // Masquer la vue principale
            this.categoriesIcons.hide();
            
            // Afficher la vue détaillée
            this.contentDetail.show();
            
            // Masquer toutes les sections
            $('.acc-category-section').hide();
            
            // Afficher la section demandée
            $(`#acc-section-${category}`).show();
            
            // Afficher le bouton retour
            this.backBtn.show();
            
            this.announce(`Catégorie ${category} ouverte`);
        }

        /**
         * Retour à la vue principale
         */
        showMainView() {
            this.currentCategory = null;
            
            // Afficher la vue principale
            this.categoriesIcons.show();
            
            // Masquer la vue détaillée
            this.contentDetail.hide();
            $('.acc-category-section').hide();
            
            // Masquer le bouton retour
            this.backBtn.hide();
            
            // Fermer la recherche si ouverte
            this.searchBar.hide();
        }

        /**
         * Toggle recherche
         */
        toggleSearch() {
            this.searchBar.slideToggle(200);
            if (this.searchBar.is(':visible')) {
                this.searchInput.focus();
            }
        }

        /**
         * Gérer la recherche
         */
        handleSearch(query) {
            // TODO: Implémenter la recherche
            console.log('Recherche:', query);
        }

        /**
         * Sauvegarder une préférence dans les cookies
         */
        savePreference(key, value) {
            const cookieName = `acc_${key}`;
            const cookieValue = JSON.stringify(value);
            const expiryDate = new Date();
            expiryDate.setFullYear(expiryDate.getFullYear() + 1); // 1 an
            
            document.cookie = `${cookieName}=${encodeURIComponent(cookieValue)}; expires=${expiryDate.toUTCString()}; path=/; SameSite=Lax`;
        }

        /**
         * Récupérer une préférence depuis les cookies
         */
        getPreference(key, defaultValue = null) {
            const cookieName = `acc_${key}`;
            const cookies = document.cookie.split(';');
            
            for (let cookie of cookies) {
                const [name, value] = cookie.trim().split('=');
                if (name === cookieName) {
                    try {
                        return JSON.parse(decodeURIComponent(value));
                    } catch (e) {
                        return decodeURIComponent(value);
                    }
                }
            }
            
            return defaultValue;
        }

        /**
         * Charger les préférences sauvegardées
         */
        loadPreferences() {
            // Les modules chargeront leurs propres préférences
        }

        /**
         * Annonce pour les lecteurs d'écran
         */
        announce(message) {
            // Créer ou récupérer la zone d'annonce
            let announcer = $('#acc-announcer');
            if (!announcer.length) {
                announcer = $('<div>', {
                    id: 'acc-announcer',
                    'aria-live': 'polite',
                    'aria-atomic': 'true',
                    'class': 'sr-only'
                }).appendTo('body');
            }
            
            // Effacer puis annoncer (pour forcer la lecture)
            announcer.text('');
            setTimeout(() => {
                announcer.text(message);
            }, 100);
        }
    }

    /**
     * Utilitaires globaux
     */
    window.accUtils = {
        /**
         * Appliquer un filtre CSS
         */
        applyFilter(filterCSS) {
            $('body').css('filter', filterCSS);
        },
        
        /**
         * Supprimer un filtre CSS
         */
        removeFilter() {
            $('body').css('filter', '');
        }
    };

    /**
     * Initialisation au chargement du DOM
     */
    $(document).ready(function() {
        if ($('#acc-widget').length) {
            window.accWidget = new AccessibilityWidget();
        } else {
            console.warn('Accessibility Widget: Widget HTML non trouvé dans la page');
        }
    });

})(jQuery);