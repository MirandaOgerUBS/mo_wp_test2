Plugin WordPress - Accessibilité Modulaire
Show Image
Show Image
Show Image
Description
Plugin WordPress modulaire offrant des fonctionnalités d'accessibilité conformes RGAA 4.1. Le système permet d'ajouter de nouveaux modules sans modifier les modules existants, garantissant ainsi la stabilité et la pérennité des configurations utilisateur.
✨ Caractéristiques Principales
🔒 Architecture Protégée

Système de modules verrouillés
Protection par marqueurs README
Isolation des fonctionnalités

🎯 Conformité et Accessibilité

✅ Conforme RGAA 4.1 (niveau AA/AAA)
✅ Navigation complète au clavier
✅ Support des lecteurs d'écran
✅ Focus visible et gestion du piège à focus
✅ Attributs ARIA complets

🔧 Extensibilité

📦 Ajout illimité de modules
🔌 Système de plugins sans modification du core
🎨 Interface cohérente et réutilisable
💾 Sauvegarde automatique des préférences

📦 Modules Inclus
📝 Module Texte
Personnalisation de la typographie :

Changement de police (Arial, Times, Verdana, OpenDyslexic...)
Taille du texte (12px - 24px)
Espacement des paragraphes
Interligne
Espacement des mots
Espacement des lettres

Critères RGAA : 10.4, 10.9, 10.12
💡 Module Luminosité
Modes d'affichage et filtres visuels :

Mode nuit (fond sombre)
Mode lumière bleue (filtre chaud)
Mode contraste élevé (AAA)
Mode contraste faible
Mode niveaux de gris
Réglages avancés (contraste, luminosité, saturation)

Critères RGAA : 3.2, 3.3, 10.11
🔘 Module Taille des Boutons
Ajustement pour accessibilité :

Tailles prédéfinies (petit, normal, grand)
Taille personnalisée (80% - 200%)
Espacement entre boutons
Zone minimale de clic (44x44px - WCAG 2.1)

Critères RGAA : 13.9, WCAG 2.5.5
🚀 Installation
Prérequis

WordPress 5.8+
PHP 7.4+
MySQL 5.7+
Clé API Google Translate (obligatoire)

Installation Rapide

Télécharger le plugin
Extraire dans wp-content/plugins/
Activer dans Plugins > Plugins installés
Configurer la clé API dans Réglages > Accessibilité

Obtenir une Clé API

Aller sur Google Cloud Console
Créer un projet
Activer l'API Cloud Translation
Créer des identifiants → Clé API
Copier la clé générée

📚 Documentation

INSTALLATION.md : Guide détaillé d'installation
QUICK_START.md : Démarrage rapide (10 min)
AI_INSTRUCTIONS.md : Instructions pour l'IA (IMPORTANT)
STRUCTURE.md : Architecture complète

🎓 Création de Modules
Structure Minimale
modules/mon-module/
├── README.md           # OBLIGATOIRE avec marqueurs
├── config.json         # Configuration
├── module.php          # Logique PHP (optionnel)
├── template.php        # Interface utilisateur
└── assets/
    ├── script.js       # JavaScript (optionnel)
    └── style.css       # CSS (optionnel)
Règles Importantes
✅ À FAIRE

Créer de nouveaux modules
Utiliser les classes CSS existantes
Sauvegarder dans les cookies (pas localStorage)
Maximum 3 éléments par ligne
Ajouter les attributs ARIA

❌ À NE PAS FAIRE

Modifier les modules existants
Utiliser localStorage/sessionStorage
Plus de 3 blocs par ligne
Modifier les fichiers principaux du plugin
Supprimer les marqueurs de README.md

🔐 Sécurité
Protection des Modules

Système de checksum dans README.md
Validation de l'intégrité au chargement
Modules rejetés si marqueurs manquants

Validation des Données

Sanitization de tous les inputs
Nonces WordPress
Échappement des sorties
Validation de la clé API

📈 Performance

Taille : ~50 KB (sans modules)
Chargement : < 100 ms
Requêtes HTTP : 2-3 fichiers
Compatible cache plugins

🤝 Contribution

Fork le projet
Créer une branche (git checkout -b feature/NouveauModule)
Commit (git commit -m 'Ajoute nouveau module X')
Push (git push origin feature/NouveauModule)
Ouvrir une Pull Request

Guidelines

Respecter les standards WordPress
Suivre les règles RGAA 4.1
Documenter les nouveaux modules
Ne JAMAIS modifier les modules existants

📜 Licence
GPL v2 or later
Ce plugin est un logiciel libre ; vous pouvez le redistribuer et/ou le modifier selon les termes de la GNU General Public License.
📞 Support

Email : support@example.com
GitHub : [Lien vers le repo]


Version : 1.0.0
Date : 15 janvier 2025
Statut : Production Ready
Made with ❤️ for accessibility