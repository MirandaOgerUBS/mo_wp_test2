<?php
/**
 * Plugin Name: Accessibilité Modulaire
 * Plugin URI: https://example.com/accessibility-plugin
 * Description: Module d'accessibilité extensible et configurable conforme RGAA
 * Version: 1.0.0
 * Author: Votre Nom
 * License: GPL v2 or later
 * Text Domain: accessibility-modular
 */

if (!defined('ABSPATH')) {
    exit;
}

// Constantes du plugin
define('ACC_PLUGIN_VERSION', '1.0.0');
define('ACC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ACC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ACC_MODULES_DIR', ACC_PLUGIN_DIR . 'modules/');

/**
 * Classe principale du plugin
 */
class Accessibility_Modular_Plugin {
    
    private static $instance = null;
    private $modules = [];
    private $active_modules = [];
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
        $this->load_modules();
    }
    
    /**
     * Charge les dépendances
     */
    private function load_dependencies() {
        require_once ACC_PLUGIN_DIR . 'includes/class-module-registry.php';
        require_once ACC_PLUGIN_DIR . 'includes/class-api-handler.php';
        require_once ACC_PLUGIN_DIR . 'admin/class-admin-settings.php';
    }
    
    /**
     * Initialise les hooks WordPress
     */
    private function init_hooks() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets'], 5);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('wp_footer', [$this, 'render_accessibility_widget']);
        
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
    }
    
    /**
     * Charge tous les modules disponibles
     */
    private function load_modules() {
        $module_registry = ACC_Module_Registry::get_instance();
        
        $module_dirs = glob(ACC_MODULES_DIR . '*', GLOB_ONLYDIR);
        
        foreach ($module_dirs as $module_dir) {
            $module_name = basename($module_dir);
            $module_file = $module_dir . '/module.php';
            $readme_file = $module_dir . '/README.md';
            
            if (file_exists($readme_file) && file_exists($module_file)) {
                require_once $module_file;
                $module_registry->register_module($module_name, $module_dir);
            }
        }
        
        $this->active_modules = $module_registry->get_active_modules();
    }
    
    /**
     * Enqueue les assets frontend
     */
    public function enqueue_frontend_assets() {
        // 1. Charger jQuery
        wp_enqueue_script('jquery');
        
        // 2. Charger acc-utils.js EN PREMIER
        wp_enqueue_script(
            'acc-utils',
            ACC_PLUGIN_URL . 'assets/js/acc-utils.js',
            ['jquery'],
            ACC_PLUGIN_VERSION,
            false // Dans le <head> pour être disponible avant tout
        );
        
        // 3. Charger le CSS de base
        wp_enqueue_style(
            'acc-base-style',
            ACC_PLUGIN_URL . 'assets/css/accessibility-base.css',
            [],
            ACC_PLUGIN_VERSION
        );
        
        // 4. Charger le CSS frontend
        wp_enqueue_style(
            'acc-frontend-style',
            ACC_PLUGIN_URL . 'assets/css/frontend.css',
            ['acc-base-style'],
            ACC_PLUGIN_VERSION
        );
        
        // 5. Charger le JS frontend
        wp_enqueue_script(
            'acc-frontend-script',
            ACC_PLUGIN_URL . 'assets/js/frontend.js',
            ['jquery', 'acc-utils'],
            ACC_PLUGIN_VERSION,
            true
        );
        
        // 6. Localisation des données
        wp_localize_script('acc-frontend-script', 'accData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('acc_nonce'),
            'activeModules' => $this->active_modules
        ]);
        
        // 7. Charger les assets des modules actifs
        foreach ($this->active_modules as $module_name) {
            $module_css = ACC_MODULES_DIR . $module_name . '/assets/style.css';
            $module_js = ACC_MODULES_DIR . $module_name . '/assets/script.js';
            
            // CSS du module (si existe)
            if (file_exists($module_css)) {
                wp_enqueue_style(
                    'acc-module-' . $module_name,
                    ACC_PLUGIN_URL . 'modules/' . $module_name . '/assets/style.css',
                    ['acc-base-style'],
                    ACC_PLUGIN_VERSION
                );
            }
            
            // JS du module (si existe)
            if (file_exists($module_js)) {
                wp_enqueue_script(
                    'acc-module-' . $module_name,
                    ACC_PLUGIN_URL . 'modules/' . $module_name . '/assets/script.js',
                    ['jquery', 'acc-utils'],
                    ACC_PLUGIN_VERSION,
                    true
                );
            }
        }
    }
    
    /**
     * Enqueue les assets admin
     */
    public function enqueue_admin_assets($hook) {
        if ('settings_page_accessibility-modular' !== $hook) {
            return;
        }
        
        wp_enqueue_style(
            'acc-admin-style',
            ACC_PLUGIN_URL . 'assets/css/admin.css',
            [],
            ACC_PLUGIN_VERSION
        );
        
        wp_enqueue_script(
            'acc-admin-script',
            ACC_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            ACC_PLUGIN_VERSION,
            true
        );
    }
    
    /**
     * Affiche le widget d'accessibilité
     */
    public function render_accessibility_widget() {
        $template_file = ACC_PLUGIN_DIR . 'templates/widget.php';
        
        if (file_exists($template_file)) {
            include $template_file;
        }
    }
    
    /**
     * Activation du plugin
     */
    public function activate() {
        add_option('acc_api_key', '');
        add_option('acc_active_modules', []);
        
        $module_registry = ACC_Module_Registry::get_instance();
        $all_modules = $module_registry->get_all_modules();
        update_option('acc_active_modules', array_keys($all_modules));
        
        flush_rewrite_rules();
    }
    
    /**
     * Désactivation du plugin
     */
    public function deactivate() {
        flush_rewrite_rules();
    }
}

// Initialise le plugin
function acc_plugin_init() {
    return Accessibility_Modular_Plugin::get_instance();
}
add_action('plugins_loaded', 'acc_plugin_init');